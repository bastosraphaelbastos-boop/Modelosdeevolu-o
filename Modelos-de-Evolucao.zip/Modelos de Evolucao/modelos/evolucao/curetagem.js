(window.MODELOS = window.MODELOS || []).push({
  categoria: "evolucao",
  id: "curetagem",
  nome: "Evolução – Curetagem uterina",
  calculos: [ { tipo: "dias", de: "datacur", para: "dpc" } ],
  repetir: { lab: "- LABORATÓRIO ({campo#@_data:data}): {campo#@_res:resultados}" },
  altas: ["curetagem"],
  texto: `
# {campo#dpc:nº}º DIA PÓS CURETAGEM UTERINA
# ABORTAMENTO {opcao:RETIDO|INCOMPLETO} DE GESTAÇÃO DE {campo#sem:sem} SEMANAS E {campo#dias:dias} DIAS
#G{campo:G}P{campo:P}A{campo:A}
.
#ALERGIAS: {opcao#alg:NEGA|REFERE}[[alg=REFERE: {campo:quais alergias}]]
#COMORBIDADES: {opcao#cmb:NEGA|REFERE}[[cmb=REFERE: {campo:quais comorbidades}]]
.
# RESUMO DA INTERNAÇÃO: PACIENTE ADMITIDA COM GESTAÇÃO DE {campo#sem:sem} SEMANAS E {campo#dias:dias} DIAS, COM QUEIXA DE {campo:queixa}. {opcao:APRESENTA|REALIZOU} ULTRASSONOGRAFIA EVIDENCIANDO {campo:achado da USG}. INTERNADA PARA {campo:motivo}. SUBMETIDA A CURETAGEM UTERINA NO DIA {campo#datacur:dd/mm/aaaa}, COM RETIRADA DE {opcao:PEQUENA|MODERADA|GRANDE} QUANTIDADE DE RESTOS OVULARES; PROCEDIMENTO {editavel:SEM INTERCORRÊNCIAS}.
#{hoje}: PACIENTE EVOLUI EM {editavel:LEITO DE ENFERMARIA} {editavel:CLÍNICA E HEMODINAMICAMENTE ESTÁVEL}. REFERE SANGRAMENTO VAGINAL {opcao:DISCRETO|MODERADO|AUMENTADO}; DIURESE, EVACUAÇÕES E FLATOS {opcao:PRESENTES|AUSENTES}. {editavel:CICLO SONO-VIGÍLIA PRESERVADO} E {editavel:APETITE SEM ALTERAÇÕES}. DURANTE VISITA MÉDICA {opcao#q:NEGA QUEIXAS|REFERE QUEIXAS}[[q=REFERE QUEIXAS: DE {campo:queixa}]].
.
#EXAME FÍSICO:
- {editavel:BOM ESTADO GERAL}, {editavel:LÚCIDA E ORIENTADA EM TEMPO E ESPAÇO}, {editavel:ACIANÓTICA, ANICTÉRICA, AFEBRIL, HIDRATADA, NORMOCORADA}
- ABDOME: {editavel:PLANO, DEPRESSÍVEL}, {opcao#dor:INDOLOR|COM DOR} À PALPAÇÃO[[dor=COM DOR: {opcao:SUPERFICIAL|PROFUNDA}]], RHA {opcao:PRESENTES|AUSENTES}
- ÚTERO: {opcao#ut:NÃO PALPÁVEL|PALPÁVEL}[[ut=PALPÁVEL: {campo:cm} CENTÍMETROS ACIMA DA SÍNFISE PÚBICA]]
- SANGRAMENTO VAGINAL: EM {opcao:PEQUENA|MODERADA} QUANTIDADE, {editavel:RUBROS}
- EXTREMIDADES: MEMBROS INFERIORES {opcao#ed:SEM EDEMA|COM EDEMA}[[ed=COM EDEMA: ({opcao:+/4+|++/4+|+++/4+|++++/4+})]], {editavel:SEM SINAIS FLOGÍSTICOS}, {editavel:SEM SINAIS DE TROMBOSE VENOSA PROFUNDA}; TEMPO DE ENCHIMENTO CAPILAR {editavel:MENOR QUE 3 SEGUNDOS}

#SINAIS VITAIS:
PA: {campo:___/___} mmHg
SPO2: {campo:__} %
FC: {campo:__} BPM

#EXAMES:
- TIPAGEM SANGUÍNEA: {campo:ex. O+}
- VDRL: {campo:resultado}
- HIV: {campo:resultado}
- LABORATÓRIO ({campo:data}): {campo:resultados}
{mais#lab:Adicionar laboratório}

#CONDUTA CONFORME DISCUTIDO E ORIENTADO PELA PRECEPTORIA/ EQUIPE OBSTÉTRICA:
{controle#alta:Alta hoje?NÃO|SIM}[[alta=:{aviso:responda “Alta hoje?” acima}]][[alta=NÃO:- MANTENHO VIGILÂNCIA CLÍNICA
- VIDE PRESCRIÇÃO MÉDICA]][[alta=SIM:- ALTA MÉDICA
- ORIENTAÇÕES (VIDE DOCUMENTO DE ALTA)
- {editavel:FORNEÇO RECEITA}
- {editavel:FORNEÇO ATESTADO}]]
`
});
