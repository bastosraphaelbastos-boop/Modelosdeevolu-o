(window.MODELOS = window.MODELOS || []).push({
  categoria: "evolucao",
  id: "puerpera",
  nome: "Evolução – Puérpera",
  calculos: [
    { tipo: "dias", de: "dataparto", para: "dpp" },
    { tipo: "ig", dum: "dum", usgData: "usgd", usgSem: "usgs", usgDias: "usgdd", ref: "dataparto", sem: "sem", dias: "dias", fonte: "fonte" },
    { tipo: "ig", dum: "dum", usgData: "usgd", usgSem: "usgs", usgDias: "usgdd", ref: "dataadm", para: "igadm", fonte: "fonte2" }
  ],
  repetir: { lab: "- LABORATÓRIO ({campo#@_data:data}): {campo#@_res:resultados}" },
  altas: { porOpcao: "via", "PARTO NORMAL": ["pn", "pn-induzido", "pn-transito", "pn-laqueadura", "pn-laceracao", "pn-sifilis", "pn-hpp", "pn-dmg", "pn-pe"], "CESARIANA": ["ces", "ces-pe", "ces-has", "ces-laqueadura", "ces-dmg"] },
  texto: `
{campo#dpp:nº}º DIA PÓS {opcao#via:PARTO NORMAL|CESARIANA}
G{campo:G}P{campo:P}A{campo:A}
# PUERPÉRIO DE GESTAÇÃO ÚNICA TÓPICA DE {campo#sem:sem} SEMANAS E {campo#dias:dias} DIAS ({opcao#fonte:DUM|USG})

# PRÉ-NATAL {opcao:RISCO HABITUAL|ALTO RISCO} - {opcao:COMPLETO|INCOMPLETO|NÃO REALIZADO} ({campo:nº} CONSULTAS)
- DUM: {campo#dum:dd/mm/aaaa}
- SOROLOGIAS: {campo:sorologias}
- NÍVEIS PRESSÓRICOS: {opcao:ADEQUADOS|ELEVADOS}
- PRIMEIRA ULTRASSONOGRAFIA: {campo#usgd:dd/mm/aaaa} COM {campo#usgs:sem}S{campo#usgdd:dias}D
- GLICEMIA DE JEJUM ({campo:data}): {campo:resultado}
- TOTG ({campo:data}): {campo:resultado}
- USO DE MEDICAÇÕES: {campo:medicações}
- INTERCORRÊNCIAS NA GESTAÇÃO: {opcao#intc:NÃO HOUVE|HOUVE}[[intc=HOUVE: ({campo:quais})]]
.
#ALERGIAS: {opcao#alg:NEGA|REFERE}[[alg=REFERE: {campo:quais alergias}]]
#COMORBIDADES: {opcao#cmb:NEGA|REFERE}[[cmb=REFERE: {campo:quais comorbidades}]]
.
# RESUMO DA INTERNAÇÃO: PACIENTE COMPARECE NO DIA {campo#dataadm:dd/mm/aaaa} COM GESTAÇÃO DE {campo#igadm:XXsXd} ({opcao#fonte2:USG|DUM}), COM QUADRO DE {campo:quadro}; ADMITIDA PARA {opcao:ASSISTÊNCIA MATERNO-FETAL|INTERRUPÇÃO DA GESTAÇÃO|INDUÇÃO DE PARTO|ASSISTÊNCIA AO PARTO NORMAL}. [[via=:{aviso:escolha PARTO NORMAL ou CESARIANA na 1ª linha}]][[via=PARTO NORMAL:EVOLUIU PARA PARTO NORMAL]][[via=CESARIANA:SUBMETIDA A CESARIANA POR {campo:indicação da cesariana}]] COM NASCIMENTO DE RN COM {opcao:BOA|MÁ} VITALIDADE, ÀS {campo:hh:mm} HORAS DO DIA {campo#dataparto:data do parto}; {editavel:SEM INTERCORRÊNCIAS MATERNAS}.
{dica:Não copie a nota de parto e a admissão completas. Faça o resumo, incluindo informações de outras evoluções se a paciente estiver internada há mais dias.}{texto:Complemento do resumo (opcional)}
#EVOLUÇÃO ({hoje}): PUÉRPERA EVOLUI EM {editavel:LEITO DE ALOJAMENTO CONJUNTO}, {editavel:CLÍNICA E HEMODINAMICAMENTE ESTÁVEL}, {opcao:COM|SEM} ACOMPANHANTE A BEIRA-LEITO. RELATA {opcao#amam:AMAMENTAÇÃO EM LIVRE DEMANDA COM PEGA ADEQUADA|DIFICULDADE NA AMAMENTAÇÃO}[[amam=DIFICULDADE NA AMAMENTAÇÃO: DEVIDO A {campo:motivo}]]. REFERE DIURESE {opcao:ESPONTÂNEA|PRESENTE POR SONDA VESICAL DE DEMORA|AUSENTE} E FLATOS {opcao:PRESENTES|AUSENTES}; EVACUAÇÕES {opcao:PRESENTES|AUSENTES ATÉ O MOMENTO}. {editavel:DEAMBULANDO SEM DIFICULDADE}. {editavel:CICLO SONO-VIGÍLIA E ESTADO EMOCIONAL PRESERVADOS} E {editavel:APETITE SEM ALTERAÇÕES, ACEITANDO BEM DIETA VIA ORAL}. DURANTE VISITA MÉDICA {opcao#q:NEGA QUEIXAS|QUEIXA-SE DE}[[q=QUEIXA-SE DE: {campo:queixa}]].
.
#EXAME FÍSICO:
- {editavel:BOM ESTADO GERAL}, {editavel:LÚCIDA E ORIENTADA EM TEMPO E ESPAÇO}, {editavel:ACIANÓTICA, ANICTÉRICA, AFEBRIL, HIDRATADA, NORMOCORADA}
- MAMAS: {editavel:SEM FISSURAS}, {editavel:SEM SINAIS FLOGÍSTICOS}, {editavel:COM COLOSTRO}
- ÚTERO: {editavel:TÔNICO E CONTRAÍDO}, INVOLUÍDO [[ut=ACIMA:{campo:cm} CM ]][[ut=ABAIXO:{campo:cm} CM ]]{opcao#ut:AO NÍVEL|ACIMA|ABAIXO} DA CICATRIZ UMBILICAL
- LÓQUIOS: {editavel:FISIOLÓGICOS}, {opcao:PEQUENA|MODERADA|GRANDE} QUANTIDADE, {editavel:RUBROS}
- ABDOME: {editavel:SEMI-GLOBOSO, DEPRESSÍVEL}, {opcao#dor:INDOLOR|COM DOR} À PALPAÇÃO[[dor=COM DOR: {opcao:SUPERFICIAL|PROFUNDA}]], {editavel:SEM SINAIS DE IRRITAÇÃO PERITONEAL}, RUÍDOS HIDROAÉREOS {opcao:PRESENTES|AUSENTES}
- EXTREMIDADES: MEMBROS INFERIORES {opcao#ed:SEM EDEMA|COM EDEMA}[[ed=COM EDEMA: ({opcao:+/4+|++/4+|+++/4+|++++/4+})]], {editavel:SEM SINAIS FLOGÍSTICOS}, {editavel:SEM SINAIS DE TROMBOSE VENOSA PROFUNDA}; TEMPO DE ENCHIMENTO CAPILAR {editavel:MENOR QUE 3 SEGUNDOS}
{controle#fo:Ferida/rafia?NÃO SE APLICA|FERIDA OPERATÓRIA|RAFIA}[[fo=FERIDA OPERATÓRIA:- FERIDA OPERATÓRIA: {editavel:BORDOS BEM COAPTADOS}, {editavel:LIMPA, SECA}, {editavel:SEM SINAIS FLOGÍSTICOS}]][[fo=RAFIA:- RAFIA: {editavel:BORDOS BEM COAPTADOS}, {editavel:LIMPA, SECA}, {editavel:SEM SINAIS FLOGÍSTICOS}]]
.
#SINAIS VITAIS:
PA: {campo:___/___} mmHg
SPO2: {campo:__} %
FC: {campo:__} BPM

#EXAMES:
- TIPAGEM SANGUÍNEA: {campo:ex. O+}
- VDRL: {campo:resultado}
- HIV: {campo:resultado}
- LABORATÓRIO ({campo:data}): {campo:resultados}
{mais#lab:Adicionar laboratório}
{controle#rh:Mãe Rh negativo?NÃO|SIM}[[rh=SIM:- TIPAGEM DO RN: {campo:tipagem do RN}
- IMUNOGLOBULINA ANTI-D APLICADA EM {campo:dd/mm/aaaa}]]
.
# CONDUTA CONFORME DISCUTIDO E ORIENTADO PELA PRECEPTORIA/ EQUIPE OBSTÉTRICA DE PLANTÃO:
{controle#alta:Alta hoje?NÃO|SIM|ALTA PARA LAQUEADURA}[[alta=:{aviso:responda “Alta hoje?” acima}]][[alta=NÃO:- {editavel:MANTENHO VIGILÂNCIA CLÍNICA PUERPERAL}
- {editavel:ORIENTAÇÕES GERAIS}
- VIDE PRESCRIÇÃO MÉDICA]][[alta=SIM:- ALTA MÉDICA
- ORIENTAÇÕES (VIDE DOCUMENTO DE ALTA)
- {editavel:FORNEÇO RECEITUÁRIO}
- {editavel:FORNEÇO ATESTADO MÉDICO PARA FINS DE LICENÇA MATERNIDADE}]][[alta=ALTA PARA LAQUEADURA:- ALTA PARA LAQUEADURA PÓS-PARTO]]
`
});
