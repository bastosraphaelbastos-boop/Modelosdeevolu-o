(window.MODELOS = window.MODELOS || []).push({
  categoria: "evolucao",
  id: "gestante-tto",
  nome: "Evolução – Gestante em tto clínico",
  calculos: [
    { tipo: "dias", de: "dataadm", para: "dih" },
    { tipo: "dias", de: "d0", para: "datb" },
    { tipo: "ig", dum: "dum", usgData: "usgd", usgSem: "usgs", usgDias: "usgdd", sem: "sem", dias: "dias" },
    { tipo: "ig", dum: "dum", usgData: "usgd", usgSem: "usgs", usgDias: "usgdd", ref: "dataadm", para: "igadm", fonte: "fonte2" }
  ],
  repetir: { lab: "- LABORATÓRIO ({campo#@_data:data}): {campo#@_res:resultados}" },
  altas: ["itu", "infeccao-fo", "cerclagem"],
  texto: `
{campo#dih:nº}º DIH PARA TRATAMENTO CLÍNICO DE {campo:diagnóstico (ex.: ITU, PIELONEFRITE)}
# GESTAÇÃO DE {campo#sem:sem} SEMANAS E {campo#dias:dias} DIAS
{dica:IG de hoje. Para calcular sozinho, preencha a DUM ou o 1º USG nos campos roxos abaixo (eles não vão para o texto).}{auxiliar#dum:DUM dd/mm/aaaa} {auxiliar#usgd:ou data do 1º USG} {auxiliar#usgs:sem. no USG} {auxiliar#usgdd:dias no USG}
#G{campo:G}P{campo:P}A{campo:A}
.
#ALERGIAS: {opcao#alg:NEGA|REFERE}[[alg=REFERE: {campo:quais alergias}]]
#COMORBIDADES: {opcao#cmb:NEGA|REFERE}[[cmb=REFERE: {campo:quais comorbidades}]]
.
# RESUMO DA INTERNAÇÃO: PACIENTE ADMITIDA NO DIA {campo#dataadm:dd/mm/aaaa} COM GESTAÇÃO DE {campo#igadm:IG} ({opcao#fonte2:USG|DUM}), COM QUEIXA DE {campo:informações da admissão}; ADMITIDA PARA {campo:motivo}.
{dica:Resuma brevemente a evolução do quadro – principalmente em internações mais longas.}{texto:Evolução do quadro (opcional)}
#{hoje}: GESTANTE EVOLUI EM LEITO DE ENFERMARIA ({opcao:COM ACOMPANHANTE|SEM ACOMPANHANTE} PRESENTE A BEIRA LEITO) {editavel:CLÍNICA E HEMODINAMICAMENTE ESTÁVEL}. {editavel:AFEBRIL NAS ÚLTIMAS 24HRS}. EM ANTIBIOTICOTERAPIA D{campo#datb:x}/D{campo:total} (D0 - {campo#d0:data do D0}). REFERE DIURESE, EVACUAÇÕES E FLATOS {opcao:PRESENTES|AUSENTES}. {editavel:CICLO SONO-VIGÍLIA PRESERVADO} E {editavel:APETITE SEM ALTERAÇÕES}. DURANTE VISITA MÉDICA {opcao#q:NEGA QUEIXAS|REFERE QUEIXAS}[[q=REFERE QUEIXAS: DE {campo:queixa}]]. {opcao:NEGA|REFERE} PERDAS VAGINAIS. REFERE MOVIMENTAÇÃO FETAL {opcao:PRESENTE|AUSENTE}.
#EM USO DE: {campo:antibiótico, D0 e plano (ex.: CEFTRIAXONA D0: 21/04 - PLANO 7 DIAS)}
.
#EXAME FÍSICO:
- {editavel:BOM ESTADO GERAL}, {editavel:LÚCIDA E ORIENTADA EM TEMPO E ESPAÇO}, {editavel:ACIANÓTICA, ANICTÉRICA, AFEBRIL, HIDRATADA, NORMOCORADA}
- ABDOME: {editavel:GRAVÍDICO, DEPRESSÍVEL}, {opcao:INDOLOR|DOLOROSO} À PALPAÇÃO, RUÍDOS HIDROAÉREOS {opcao:PRESENTES|AUSENTES}
- ÚTERO: {editavel:TÔNUS NORMAL}, ALTURA DE FUNDO UTERINO {campo:AU} CM, DINÂMICA UTERINA {opcao#du:AUSENTE|PRESENTE}[[du=PRESENTE: ({campo:nº} CONTRAÇÕES EM 10 MINUTOS)]]
- SANGRAMENTO VAGINAL: {editavel:AUSENTE}
- EXTREMIDADES: MEMBROS INFERIORES {opcao#ed:SEM EDEMA|COM EDEMA}[[ed=COM EDEMA: ({opcao:+/4+|++/4+|+++/4+|++++/4+})]], {editavel:SEM SINAIS FLOGÍSTICOS}, {editavel:SEM SINAIS DE TROMBOSE VENOSA PROFUNDA}; TEMPO DE ENCHIMENTO CAPILAR {editavel:MENOR QUE 3 SEGUNDOS}
- TOQUE VAGINAL: {editavel:EVITADO}

#SINAIS VITAIS:
BCF: {campo:__} BPM
PA: {campo:___/___} mmHg
SPO2: {campo:__} %
FC: {campo:__} BPM
TEMP: {campo:ex. 36,5} ºC
.
#EXAMES:
- TIPAGEM SANGUÍNEA: {campo:ex. O+}
- VDRL: {campo:resultado}
- USG OBSTÉTRICA ({campo:data}): {campo:apresentação fetal; BCF; PFE; LA; Doppler}
- LABORATÓRIO ({campo:data}): {campo:se houver}
{mais#lab:Adicionar laboratório}

#CONDUTA CONFORME DISCUTIDO E ORIENTADO PELA PRECEPTORIA/ EQUIPE OBSTÉTRICA:
{controle#alta:Alta hoje?NÃO|SIM}[[alta=:{aviso:responda “Alta hoje?” acima}]][[alta=NÃO:- MANTENHO VIGILÂNCIA CLÍNICA
- VIDE PRESCRIÇÃO MÉDICA]][[alta=SIM:- ALTA MÉDICA
- ORIENTAÇÕES (VIDE DOCUMENTO DE ALTA)
- {editavel:FORNEÇO RECEITA}]]
`
});
