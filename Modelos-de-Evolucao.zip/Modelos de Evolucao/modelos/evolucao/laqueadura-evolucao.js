(window.MODELOS = window.MODELOS || []).push({
  categoria: "evolucao",
  id: "laqueadura-evolucao",
  nome: "Evolução – Laqueadura pós-parto",
  calculos: [
    { tipo: "dias", de: "dataparto", para: "dpp" },
    { tipo: "dias", de: "datalaq", para: "dpo" }
  ],
  repetir: { lab: "- LABORATÓRIO ({campo#@_data:data}): {campo#@_res:resultados}" },
  altas: ["pn-laqueadura"],
  texto: `
#G{campo:G}P{campo:P}A{campo:A}
#{campo#dpp:nº}º DIA PÓS PARTO NORMAL + {campo#dpo:nº=1}º DIA PÓS OPERATÓRIO DE LAQUEADURA TUBÁRIA BILATERAL
#ALERGIAS: {opcao#alg:NEGA|REFERE}[[alg=REFERE: {campo:quais alergias}]]
#COMORBIDADES: {opcao#cmb:NEGA|REFERE}[[cmb=REFERE: {campo:quais comorbidades}]]
.
#RESUMO DA INTERNAÇÃO: PACIENTE COM ÚLTIMO PARTO EM {campo#dataparto:dd/mm/aaaa}, COM DESEJO DE CONTRACEPÇÃO DEFINITIVA, SUBMETIDA A LAQUEADURA TUBÁRIA BILATERAL {editavel:PERIUMBILICAL} EM {campo#datalaq:dd/mm/aaaa}, {editavel:SEM INTERCORRÊNCIAS APÓS PROCEDIMENTO CIRÚRGICO}.
#{hoje}: PUÉRPERA EVOLUI EM {editavel:LEITO DE ALOJAMENTO CONJUNTO}, {editavel:CLÍNICA E HEMODINAMICAMENTE ESTÁVEL}. REFERE {editavel:LÓQUIOS FISIOLÓGICOS} E {editavel:AMAMENTAÇÃO REGULAR}. REFERE DIURESE, EVACUAÇÃO E FLATOS {opcao:PRESENTES|AUSENTES}; {editavel:CICLO SONO-VIGÍLIA PRESERVADO} E {editavel:APETITE SEM ALTERAÇÕES}. DURANTE VISITA MÉDICA {opcao#q:NEGA QUEIXAS|QUEIXA-SE DE}[[q=QUEIXA-SE DE: {campo:queixa}]].

#EXAME FÍSICO:
- {editavel:BOM ESTADO GERAL}, {editavel:LÚCIDA E ORIENTADA EM TEMPO E ESPAÇO}, {editavel:ACIANÓTICA, ANICTÉRICA, AFEBRIL, HIDRATADA, NORMOCORADA}
- MAMAS: {editavel:SEM FISSURAS}, {editavel:SEM SINAIS FLOGÍSTICOS}, {editavel:COM COLOSTRO}
- ABDOME: {editavel:SEMI-GLOBOSO, DEPRESSÍVEL}, {opcao#dor:INDOLOR|COM DOR} À PALPAÇÃO[[dor=COM DOR: {opcao:SUPERFICIAL|PROFUNDA}]], RHA {opcao:PRESENTES|AUSENTES}
- ÚTERO: {editavel:TÔNICO}, INVOLUÍDO [[ut=ACIMA:{campo:cm} CM ]][[ut=ABAIXO:{campo:cm} CM ]]{opcao#ut:AO NÍVEL|ACIMA|ABAIXO} DA CICATRIZ UMBILICAL
- LÓQUIOS: {editavel:FISIOLÓGICOS}, EM {opcao:PEQUENA|MODERADA} QUANTIDADE, {editavel:RUBROS}
- EXTREMIDADES: MEMBROS INFERIORES {opcao#ed:SEM EDEMA|COM EDEMA}[[ed=COM EDEMA: ({opcao:+/4+|++/4+|+++/4+|++++/4+})]], {editavel:SEM SINAIS FLOGÍSTICOS}, {editavel:SEM SINAIS DE TROMBOSE VENOSA PROFUNDA}; TEMPO DE ENCHIMENTO CAPILAR {editavel:MENOR QUE 3 SEGUNDOS}
- FERIDA OPERATÓRIA: {editavel:LIMPA, SECA}, {editavel:SEM SINAIS FLOGÍSTICOS}

#SINAIS VITAIS:
PA: {campo:___/___} mmHg
SPO2: {campo:__} %
FC: {campo:__} BPM

#EXAMES:
- TIPAGEM SANGUÍNEA: {campo:ex. O+}
- VDRL: {campo:resultado}
- HIV: {campo:resultado}
- LABORATÓRIO ({campo:data}): {campo:resultados}
{mais#lab:Adicionar laboratório}

#CONDUTA CONFORME DISCUTIDO E ORIENTADO PELA PRECEPTORIA/ EQUIPE OBSTÉTRICA:
{controle#alta:Alta hoje?NÃO|SIM}[[alta=:{aviso:responda “Alta hoje?” acima}]][[alta=NÃO:- MANTENHO VIGILÂNCIA CLÍNICA
- VIDE PRESCRIÇÃO MÉDICA]][[alta=SIM:- ALTA MÉDICA
- ORIENTAÇÕES (VIDE DOCUMENTO DE ALTA)
- {editavel:FORNEÇO RECEITA}]]
`
});
