/*
 * Outras altas (curetagem, ITU, infecção de ferida operatória, cerclagem). Textos do documento do autor (ALTA.docx).
 * Campos: id, nome, grupo (agrupa a lista "Outras altas"), tratamento, recomendacoes (texto; linhas separadas por \n), cid (uma linha por código).
 * O CID é só uma sugestão do tipo de alta escolhido: o médico confere e edita na tela.
 */
(window.MODELOS = window.MODELOS || []).push({
  categoria: "alta",
  id: "curetagem",
  nome: "Curetagem uterina",
  grupo: "Outras",
  tratamento: "ASSISTÊNCIA MATERNA; CURETAGEM UTERINA",
  recomendacoes: "REALIZAR ACOMPANHAMENTO E PLANEJAMENTO FAMILIAR EM UNIDADE BÁSICA DE SAÚDE; RETORNAR A ESTA MATERNIDADE EM CASO DE SINAIS DE ALARME: DOR DE CABEÇA INTENSA, PRESSÃO ALTA, VISÃO TURVA, FEBRE >37,5 ºC, SECREÇÃO VAGINAL PURULENTA, SANGRAMENTO INTENSO, ETC).",
  cid: ["O06 – ABORTAMENTO NÃO ESPECIFICADO"]
});
(window.MODELOS = window.MODELOS || []).push({
  categoria: "alta",
  id: "itu",
  nome: "Gestante em tratamento de ITU",
  grupo: "Outras",
  tratamento: "ASSISTÊNCIA MATERNO-FETAL; ANTIBIOTICOTERAPIA.",
  recomendacoes: "REALIZAR ACOMPANHAMENTO DE PRÉ-NATAL EM UNIDADE DE SAÚDE. REALIZAR UROCULTURA DE CONTROLE E APRESENTÁ-LA A UM MÉDICO PARA AVALIAÇÃO. RETORNAR A ESTA MATERNIDADE EM CASO DE FEBRE, SINTOMAS URINÁRIOS, PICO PRESSÓRICO, DOR DE CABEÇA INTENSA OU CONTRAÇÕES RITMADAS.",
  cid: []
});
(window.MODELOS = window.MODELOS || []).push({
  categoria: "alta",
  id: "infeccao-fo",
  nome: "Infecção de ferida operatória",
  grupo: "Outras",
  tratamento: "VIGILÂNCIA CLÍNICA; ANTIBIOTICOTERAPIA; CUIDADOS DE FERIDA OPERATÓRIA.",
  recomendacoes: "FAZER USO DO ANTIBIÓTICO CONFORME PRESCRITO E RETORNAR EM 5 DIAS PARA REAVALIAÇÃO.",
  cid: ["T814 – INFECÇÃO SUBSEQUENTE A PROCEDIMENTO"]
});
(window.MODELOS = window.MODELOS || []).push({
  categoria: "alta",
  id: "cerclagem",
  nome: "Cerclagem",
  grupo: "Outras",
  tratamento: "",
  recomendacoes: "MANTER REPOUSO RELATIVO NOS PRIMEIROS DIAS, EVITANDO ESFORÇOS FÍSICOS INTENSOS, LEVANTAMENTO DE PESO E ATIVIDADES DE ALTO IMPACTO; MANTER USO DAS MEDICAÇÕES PRESCRITAS; RETORNAR ÀS CONSULTAS DE PRÉ-NATAL E SEGUIMENTO CONFORME AGENDAMENTO. PROCURAR ATENDIMENTO IMEDIATAMENTE EM CASO DE: PERDA DE LÍQUIDO VAGINAL, SANGRAMENTO VAGINAL IMPORTANTE, CONTRAÇÕES UTERINAS REGULARES OU DOR ABDOMINAL INTENSA; FEBRE >=38°, CORRIMENTO VAGINAL DE ODOR FÉTIDO, DIMINUIÇÃO DA MOVIMENTAÇÃO FETAL. RETIRADA DE PONTOS DA CERCLAGEM PROGRAMADA PARA 37 SEMANAS.",
  cid: []
});
