/*
 * Motor — cálculos automáticos definidos em "calculos" no modelo (parte do motor.js; carregue antes dele e depois de motor-campos.js).
 *   { tipo: "dias", de: idData, para: idCampo }            -> dias entre a data e hoje
 *   { tipo: "ig", dum, usgData, usgSem, usgDias,           -> idade gestacional na data
 *     ref (data de referência; vazio = hoje),                 "ref" (ou hoje), preferindo
 *     sem + dias  OU  para (formato 38S2D), fonte (opção) }   o USG quando preenchido
 * O que o cálculo escreve fica em "calculados" (para o desfazer só apagar o que ele mesmo escreveu, nunca o que a pessoa digitou por cima).
 * Os valores e o modelo aberto vêm de M.estado() (definido em motor.js). Peças compartilhadas em window.MotorPecas; esta fica em M.Calculos.
 */
(function () {
  "use strict";
  var M = window.MotorPecas = window.MotorPecas || {};
  var K = M.Calculos = {};

  function lerData(txt) {
    txt = (txt || "").trim();
    var m = txt.match(/^(\d{1,2})[\/.-](\d{1,2})(?:[\/.-](\d{2}|\d{4}))?$/) || txt.match(/^(\d{2})(\d{2})(\d{4}|\d{2})?$/);
    if (!m) return null;
    var d = +m[1], mes = +m[2], a = m[3] ? +m[3] : new Date().getFullYear();
    if (a < 100) a += 2000;
    var dt = new Date(a, mes - 1, d);
    return dt.getDate() === d && dt.getMonth() === mes - 1 ? dt : null;
  }
  function diasEntre(a, b) { return Math.round((b - a) / 864e5); }
  function hojeData() { var d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); }

  // Os espaços com o mesmo id (campos de #nome repetido) mostram o mesmo valor
  function naTela(id, fazer) {
    document.querySelectorAll('#editor [data-id="' + id + '"]').forEach(function (el) { if (M.Campos.ehEntrada(el)) fazer(el); });
  }

  function definir(id, valor) {
    if (!id) return;
    var E = M.estado();
    E.calculados[id] = valor;
    if (E.valores[id] === valor) return;
    E.valores[id] = valor;
    naTela(id, function (el) { M.Campos.escrever(el, valor); el.classList.add("calculado"); });
  }

  // Apaga o que o cálculo escreveu (só se a pessoa não tiver digitado outra coisa por cima)
  function desfazerCalculo(id) {
    var E = M.estado();
    if (!id || !(id in E.calculados) || E.valores[id] !== E.calculados[id]) return;
    delete E.calculados[id];
    E.valores[id] = "";
    naTela(id, function (el) { M.Campos.escrever(el, ""); el.classList.remove("calculado"); });
  }

  // idMudado = o campo que a pessoa acabou de mudar; refaz os cálculos que dependem dele
  K.calcular = function (idMudado) {
    var E = M.estado(), valores = E.valores, calculados = E.calculados;
    var num = function (id) { var n = parseInt(valores[id], 10); return isNaN(n) ? null : n; };
    (E.atual.calculos || []).forEach(function (c) {
      var fontes = c.tipo === "dias" ? [c.de] : [c.dum, c.usgData, c.usgSem, c.usgDias, c.ref];
      if (fontes.indexOf(idMudado) === -1) return;
      if (c.tipo === "dias") {
        var dt = lerData(valores[c.de]), n = dt ? diasEntre(dt, hojeData()) : -1;
        if (n >= 0 && n < 400) definir(c.para, String(n)); else desfazerCalculo(c.para);
        return;
      }
      var desfazer = function () {
        desfazerCalculo(c.para); desfazerCalculo(c.sem); desfazerCalculo(c.dias);
        if (c.fonte && valores[c.fonte] === calculados[c.fonte]) { valores[c.fonte] = ""; delete calculados[c.fonte]; }
      };
      var ref = c.ref ? lerData(valores[c.ref]) : hojeData();
      if (!ref) { desfazer(); return; }
      var total = null, fonte = "";
      var usg = lerData(valores[c.usgData]), s = num(c.usgSem);
      if (usg && s !== null) { total = s * 7 + (num(c.usgDias) || 0) + diasEntre(usg, ref); fonte = "USG"; }
      else { var dum = lerData(valores[c.dum]); if (dum) { total = diasEntre(dum, ref); fonte = "DUM"; } }
      if (total === null || total < 0 || total > 310) { desfazer(); return; }
      var sem = Math.floor(total / 7), dias = total % 7;
      if (c.para) definir(c.para, sem + "S" + dias + "D");
      else { definir(c.sem, String(sem)); definir(c.dias, String(dias)); }
      if (c.fonte) { valores[c.fonte] = fonte; calculados[c.fonte] = fonte; }
    });
  };
})();
