/*
 * Favoritar e ocultar modelos: os PRONTOS (clássicos) e os PRÓPRIOS ("Minhas evoluções"). Botão direito no modelo (P.MenuContexto):
 * ⭐ Favoritar / Tirar dos favoritos e Ocultar (no oculto: "Mostrar (deixar de ocultar)").
 * Favorito: ⭐ antes do nome e sobe para o alto DENTRO do grupo dele (a lista dos prontos; a pasta ou os soltos dos próprios), sem mexer na
 * ordem manual (Alt+↑/↓, arrastar): ao tirar dos favoritos volta a ordem de antes. Oculto: some do menu, da busca (Ctrl+K) e do Alt+1..9.
 * No fim de cada lista, "👁 Mostrar modelos ocultos (N)" (só com N > 0) mostra os ocultos esmaecidos, marcados "(oculto)", no lugar deles
 * (só na sessão); o mesmo link vira "Esconder os ocultos".
 * Guarda na preferência (P.salvarPref: `fav` e `oc`) só ids: o id do pronto ou "p:" + id do próprio (o mesmo do data-id do botão no menu e
 * do motor; nunca colide com o de um pronto). Ao apagar um próprio, F.limpar tira o id de lá. Duplicar, o arquivo .txt (Enviar, Abrir arquivo,
 * cópia de segurança) e receber/atualizar não levam nem mexem nesse estado. Menu dos próprios: personalizados-ui.js; Alt+↑/↓: personalizados-acoes.js.
 * Carregue antes de motor.js (o menu é montado por personalizados-ui.js, que chama P.Favoritos.desenhar e F.linkOcultos).
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var F = P.Favoritos = {};
  var mostrando = { c: false, p: false };      // c = prontos, p = Minhas evoluções: "Mostrar modelos ocultos" aberto (só na sessão)
  var recado = "", tRecado;                    // frase de confirmação da última ação nos prontos (nos próprios vai para P.mostrarStatus)
  var PAINEL = { c: "painel-classicos", p: "painel-personalizadas" };

  F.chave = function (rec) { return "p:" + rec.id; };        // chave de um modelo próprio

  // ids guardados que ainda são de modelos que existem (prontos pelo id, próprios por "p:" + id), sem repetidos
  function ids(campo) {
    var v = P.lerPref()[campo], vivos = {};
    P.classicos.forEach(function (m) { vivos[m.id] = true; });
    (P.lista || []).forEach(function (r) { vivos[F.chave(r)] = true; });
    return Array.isArray(v) ? v.filter(function (id, k) { return typeof id === "string" && vivos[id] === true && v.indexOf(id) === k; }) : [];
  }
  function estado() {                          // { fav: {chave: true}, oc: {chave: true} }; oculto nunca conta como favorito
    var e = { fav: {}, oc: {} };
    ids("oc").forEach(function (k) { e.oc[k] = true; });
    ids("fav").forEach(function (k) { if (!e.oc[k]) e.fav[k] = true; });
    return e;
  }
  F.ehFavorito = function (chave) { return estado().fav[chave] === true; };
  F.ehOculto = function (chave) { return estado().oc[chave] === true; };

  // Favoritos primeiro (na ordem em que já estavam), depois os outros; os ocultos só entram com comOcultos (no lugar deles, entre os outros)
  function ordenar(lista, chaveDe, comOcultos) {
    var e = estado(), l = lista.filter(function (x) { return comOcultos || !e.oc[chaveDe(x)]; });
    return l.filter(function (x) { return e.fav[chaveDe(x)]; }).concat(l.filter(function (x) { return !e.fav[chaveDe(x)]; }));
  }
  var idPronto = function (m) { return m.id; };
  F.visiveis = function (comOcultos) { return ordenar(P.classicos, idPronto, !!comOcultos); };      // prontos do menu e da busca
  F.ocultos = function () { var e = estado(); return P.classicos.filter(function (m) { return e.oc[m.id]; }); };
  F.meus = function (pasta, comOcultos) { return ordenar(P.modelosDaPasta(pasta), F.chave, !!comOcultos); };     // próprios de uma pasta ("" = soltos), como aparecem
  F.meusOcultos = function (pasta) {           // sem pasta = todos os próprios ocultos
    var e = estado();
    return (pasta === undefined ? P.lista : P.modelosDaPasta(pasta)).filter(function (r) { return e.oc[F.chave(r)]; });
  };
  F.mostrando = function (q) { return mostrando[q]; };

  // "alvo" = o que as ações recebem: { chave, nome, q ("c" prontos / "p" próprios), onde (frase) }
  F.alvoPronto = function (m) { return { chave: m.id, nome: m.nome, q: "c", onde: "da lista" }; };
  F.alvoMeu = function (rec) { return { chave: F.chave(rec), nome: rec.nome, q: "p", onde: P.pastaDe(rec) ? "da pasta" : "da lista" }; };

  function guardar(fav, oc) { P.salvarPref({ fav: fav, oc: oc }); }
  F.limpar = function () {         // depois de apagar um próprio: tira da preferência os ids que não existem mais
    var p = P.lerPref(), f = ids("fav"), o = ids("oc");
    if (JSON.stringify(p.fav || []) !== JSON.stringify(f) || JSON.stringify(p.oc || []) !== JSON.stringify(o)) guardar(f, o);
  };

  var buscar = function (chave) { return chave ? document.querySelector('#lista-modelos .item-modelo[data-id="' + chave + '"]') : null; };
  function vizinhoDe(a) {          // o modelo ao lado (para o foco não se perder ao ocultar)
    var bts = Array.prototype.filter.call(document.querySelectorAll("#" + PAINEL[a.q] + " .item-modelo"), function (b) { return b.getClientRects().length > 0; });
    var i = bts.map(function (b) { return b.dataset.id; }).indexOf(a.chave), v = bts[i + 1] || bts[i - 1];
    return v ? v.dataset.id : null;
  }
  function depois(a, frase, viz) {
    if (a.q === "p") P.mostrarStatus(frase);
    else {
      recado = frase; clearTimeout(tRecado);
      tRecado = setTimeout(function () { recado = ""; var p = document.querySelector("#lista-modelos .fav-aviso"); if (p) p.textContent = ""; }, 8000);
    }
    P.renderMenu();
    var b = buscar(a.chave) || buscar(viz) || document.querySelector('#lista-modelos .fav-ocultos[data-q="' + a.q + '"]') || document.querySelector("#" + PAINEL[a.q] + " .item-modelo");
    if (b) b.focus({ preventScroll: true });
  }

  F.alternarFavorito = function (a) {
    var fav = ids("fav"), k = fav.indexOf(a.chave);
    if (k === -1) fav.push(a.chave); else fav.splice(k, 1);
    guardar(fav, ids("oc"));
    depois(a, k === -1 ? "“" + a.nome + "” agora é favorito e fica no alto " + a.onde + "." : "“" + a.nome + "” saiu dos favoritos.");
  };
  F.ocultar = function (a) {
    var viz = vizinhoDe(a), oc = ids("oc");
    if (oc.indexOf(a.chave) === -1) oc.push(a.chave);
    guardar(ids("fav").filter(function (id) { return id !== a.chave; }), oc);
    depois(a, "“" + a.nome + "” foi ocultado. Para ver de novo, use “Mostrar modelos ocultos”, no fim da lista.", viz);
  };
  F.reexibir = function (a) {
    guardar(ids("fav"), ids("oc").filter(function (id) { return id !== a.chave; }));
    depois(a, "“" + a.nome + "” voltou para a lista.");
  };

  // Itens do menu do botão direito (depois de "Abrir"): Favoritar / Tirar dos favoritos + Ocultar, ou só "Mostrar (deixar de ocultar)"
  F.itensMenu = function (a) {
    if (F.ehOculto(a.chave)) return [{ icone: "👁", texto: "Mostrar (deixar de ocultar)", titulo: "Faz “" + a.nome + "” voltar para a lista e para a busca", aoClicar: function () { F.reexibir(a); } }];
    var fav = F.ehFavorito(a.chave);
    return [
      { icone: "⭐", texto: fav ? "Tirar dos favoritos" : "Favoritar", titulo: fav ? "“" + a.nome + "” deixa de ficar no alto" : "Põe “" + a.nome + "” no alto " + a.onde, aoClicar: function () { F.alternarFavorito(a); } },
      { icone: "🙈", texto: "Ocultar", titulo: "Esconde “" + a.nome + "” do menu e da busca (dá para mostrar de novo)", aoClicar: function () { F.ocultar(a); } }
    ];
  };

  // Põe no botão do modelo a ⭐ (favorito) ou a marca "(oculto)" + classe item-oculto (esmaecido; fora do Alt+n)
  F.marcar = function (b, chave, nome) {
    var e = estado();
    if (e.oc[chave]) {
      b.classList.add("item-oculto");
      var t = document.createElement("span"); t.className = "fav-tag"; t.textContent = " (oculto)"; b.appendChild(t);
    } else if (e.fav[chave]) {
      var s = document.createElement("span"); s.className = "fav-estrela"; s.textContent = "⭐"; s.setAttribute("aria-hidden", "true");
      b.insertBefore(s, b.firstChild); b.setAttribute("aria-label", "Favorito: " + nome);
    }
  };

  // Depois de mostrar/esconder, o link fica onde estava na tela (a lista cresce ou encolhe acima dele): rola o menu o tanto que ele andou
  function manter(el, antes) {
    var d = el.getBoundingClientRect().top - antes, p = el.parentElement;
    if (!d) return;
    while (p && p !== document.body) { var o = getComputedStyle(p).overflowY; if ((o === "auto" || o === "scroll") && p.scrollHeight > p.clientHeight) break; p = p.parentElement; }
    (p && p !== document.body ? p : window).scrollBy({ top: d, behavior: "instant" });
  }
  // O link do fim da lista (q: "c" prontos, "p" próprios); null se não há ocultos
  F.linkOcultos = function (q) {
    var n = q === "c" ? F.ocultos().length : F.meusOcultos().length;
    if (!n) { mostrando[q] = false; return null; }
    var lk = document.createElement("button"); lk.type = "button"; lk.className = "fav-ocultos"; lk.dataset.q = q;
    if (mostrando[q]) lk.textContent = "Esconder os ocultos";
    else {
      var ic = document.createElement("span"); ic.textContent = "👁 "; ic.setAttribute("aria-hidden", "true");
      lk.appendChild(ic); lk.appendChild(document.createTextNode("Mostrar modelos ocultos (" + n + ")"));
    }
    lk.setAttribute("aria-expanded", mostrando[q] ? "true" : "false");
    lk.addEventListener("click", function () {
      var antes = lk.getBoundingClientRect().top;
      mostrando[q] = !mostrando[q]; P.renderMenu();
      var novo = document.querySelector('#lista-modelos .fav-ocultos[data-q="' + q + '"]');
      if (novo) { novo.focus({ preventScroll: true }); manter(novo, antes); }
    });
    return lk;
  };

  // A busca (Ctrl+K) manda mostrar ocultos que combinam: abre os painéis/pastas e põe o foco no 1º (nada é "desocultado")
  F.revelar = function (chaves) {
    chaves.forEach(function (k) {
      var q = k.indexOf("p:") === 0 ? "p" : "c";
      mostrando[q] = true; document.getElementById(PAINEL[q]).open = true;
      if (q === "p") { P.filtroLista = ""; var f = P.pastaDe(P.lista.filter(function (r) { return F.chave(r) === k; })[0]); if (f) P.lembrarPasta(f.id, true); }
    });
    P.renderMenu();
    var b = buscar(chaves[0]);
    if (b) { b.focus({ preventScroll: true }); b.scrollIntoView({ block: "nearest" }); }
  };

  function linha(m) {
    var a = F.alvoPronto(m);
    var l = document.createElement("div"); l.className = "linha-modelo";
    var b = document.createElement("button"); b.type = "button"; b.className = "item-modelo"; b.dataset.id = m.id;
    b.appendChild(document.createTextNode(m.nome)); F.marcar(b, a.chave, m.nome);
    var abrir = function () { P.Motor.trocar(m); };
    b.addEventListener("click", abrir);
    l.appendChild(b);
    P.MenuContexto.ligar(l, b, function () { return [{ icone: "▶", texto: "Abrir", aoClicar: abrir }].concat(F.itensMenu(a)); });
    return l;
  }

  // Desenha a lista dos modelos prontos dentro de `corpo` (o miolo do painel "Evoluções clássicas")
  F.desenhar = function (corpo) {
    F.visiveis(mostrando.c).forEach(function (m) { corpo.appendChild(linha(m)); });
    var lk = F.linkOcultos("c"); if (lk) corpo.appendChild(lk);
    var d = document.createElement("p"); d.className = "fav-dica"; d.textContent = "Botão direito: favoritar ou ocultar"; corpo.appendChild(d);
    var av = document.createElement("p"); av.className = "fav-aviso"; av.setAttribute("role", "status"); corpo.appendChild(av);
    if (recado) setTimeout(function () { av.textContent = recado; }, 60);      // (a frase entra depois de a área existir: leitores de tela a anunciam)
  };
})();
