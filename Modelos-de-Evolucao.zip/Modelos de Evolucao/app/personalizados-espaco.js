/*
 * Evoluções personalizadas — "Espaço para preencher": com o cursor DENTRO de um espaço [ ... ] que já existe, o botão vira
 * "Mudar este espaço" e abre um diálogo (igual ao "Mudar esta escolha"): dica, já vem preenchido, ligar com outros espaços
 * ([@NOME: dica]) e caixa grande de texto livre ([...dica]). Ao confirmar, o colchete é reescrito.
 * Vale nos dois modos (no modo Blocos, dentro do bloco aberto). [hoje] e os dias contados sozinhos não abrem o diálogo.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var X = P.Espaco = {};
  var I = function () { return P._ed; };
  var el = function (tag, classe, texto) { return I().el(tag, classe, texto); };
  var RE_BARRA = /(^|\s)\/(\s|$)/;

  // Acha o que há sob o cursor (ou a seleção, se ela está toda dentro de um colchete) no texto t.
  // Devolve null (nada de especial: vale o comportamento normal do botão),
  // { ok: false, dica } (é outra coisa: só mostra a dica) ou { ok: true, s, e, grande, dica, valor, ligado, nome, travado } (espaço simples).
  X.achar = function (t, a, b) {
    var alvo = null;
    I().marcadores(t).forEach(function (m) {
      if (m.s <= a && b <= m.e && a < m.e && (!alvo || m.e - m.s < alvo.e - alvo.s)) alvo = m;
    });
    if (!alvo) return null;
    if (alvo.k === "dias") return { ok: false, dica: "Os dias são contados sozinhos: não há o que ajustar aqui. Para mudar a data, mude o espaço [@NOME] dela." };
    if (alvo.k === "nativo") return { ok: false, dica: "Este espaço usa marcações avançadas ({ }) e não abre aqui. Use ↺ Desfazer marcação para voltar ao texto simples e marque de novo." };
    if (alvo.k !== "colchete") return null;
    var c = I().semBarras(t.slice(alvo.s + 1, alvo.e - 1)).trim();
    if (/^hoje$/i.test(c)) return { ok: false, dica: "[hoje] já é a data de hoje: não há o que ajustar aqui. Para outra coisa, use ↺ Desfazer marcação." };
    if (c.charAt(0) !== "@" && (/^\?\s/.test(c) || RE_BARRA.test(c))) return { ok: false, dica: "Isto é uma escolha: use o botão “Mudar esta escolha”." };
    var r = { ok: true, s: alvo.s, e: alvo.e, grande: false, dica: "", valor: "", ligado: false, nome: "", travado: false }, k, resto;
    if (/^(\.\.\.|…)/.test(c)) { r.grande = true; r.dica = c.replace(/^(\.\.\.|…)\s*/, ""); return r; }
    if (c.charAt(0) === "@") {
      var cA = c.slice(1); k = cA.search(/[:=]/);
      r.ligado = true; r.nome = (k === -1 ? cA : cA.slice(0, k)).trim();
      resto = k === -1 ? "" : cA.slice(k);
      if (k === -1) r.dica = r.nome;
      else if (resto.charAt(0) === ":") resto = resto.slice(1).trim();
      else resto = resto.trim();
      var id = P.normalizarNome(r.nome), mestre = I().estado().master.value;
      mestre.replace(/\(\(\s*DIAS\s+DESDE\s+@([^()\n]*?)\s*\)\)/gi, function (x, nm) { if (P.normalizarNome(nm) === id) r.travado = true; return x; });
    } else resto = c;
    if (k !== -1 || !r.ligado) {
      var q = resto.indexOf("=");
      if (q === -1) r.dica = resto; else { r.dica = resto.slice(0, q).trim(); r.valor = resto.slice(q + 1).trim(); }
    }
    return r;
  };

  function limparDica(s) {
    var d = String(s).replace(/[\[\]{}\\|]/g, " ").replace(/\s+/g, " ").replace(/\s+\/\s+/g, "/").replace(/=/g, ":").replace(/^(\.\.\.|…)\s*/, "");
    d = d.replace(/^[\s\/*]+|[\s\/*]+$/g, "").replace(/^[@?]+\s*/, "").trim();
    return /^hoje$/i.test(d) ? "ex. " + d : d;
  }
  var limparValor = function (s) { return String(s).replace(/\s+/g, " ").replace(/\s+\/\s+/g, "/").trim(); };
  var limparNome = function (s) { return String(s).replace(/[\[\]{}()|:=\\*]/g, " ").replace(/\s+/g, " ").trim().toUpperCase(); };

  X.dialogo = function (sp) {
    var e = I().estado();
    I().limparTextarea();
    I().dica("");
    var j = I().janelinha("dlg-esp-titulo", "Espaço para preencher", true), caixa = j.corpo, fecharJ = j.fechar;
    caixa.appendChild(el("p", "dlg-ajuda", "Escolha como este espaço se comporta quando o médico for preencher."));

    var lbD = el("label", "dlg-extra-rot", "Dica (o que escrever):"); lbD.htmlFor = "dlg-esp-dica";
    var dica = el("input", "dlg-campo"); dica.type = "text"; dica.id = "dlg-esp-dica"; dica.maxLength = 80; dica.value = sp.dica;
    caixa.appendChild(lbD); caixa.appendChild(dica);

    var ck = function (id, texto) {
      var c = el("input"); c.type = "checkbox"; c.id = id;
      var l = el("label", "dlg-ck"); l.htmlFor = id; l.appendChild(c); l.appendChild(el("span", "", " " + texto));
      return { c: c, l: l };
    };
    var campo = function (id, rot, max, valor) {
      var sub = el("div", "dlg-sub"), lb = el("label", "", rot); lb.htmlFor = id;
      var i = el("input", "dlg-campo"); i.type = "text"; i.id = id; i.maxLength = max; i.value = valor;
      sub.appendChild(lb); sub.appendChild(i);
      return { sub: sub, i: i };
    };
    var c1 = ck("dlg-esp-ck-val", "Já vem preenchido com:"), f1 = campo("dlg-esp-val", "O que já vem escrito (o médico pode mudar):", 120, sp.valor);
    var c2 = ck("dlg-esp-ck-lig", "Ligar com outros espaços (preencher um preenche os outros) — nome:"), f2 = campo("dlg-esp-nome", "Nome do espaço ligado:", 60, sp.nome);
    var c3 = ck("dlg-esp-ck-grande", "Caixa grande de texto livre (opcional)");
    var datas = I().compilarCache(e.master.value).estrutura.datas;
    var hintNome = el("p", "dlg-hint", datas.length ? "Espaços com o mesmo nome são preenchidos juntos. Nomes já usados: " + datas.map(function (d) { return "@" + d.nome; }).join(", ") + "."
      : "Espaços com o mesmo nome são preenchidos juntos.");
    f2.sub.appendChild(hintNome);
    var hintGrande = el("p", "dlg-hint", "A caixa grande não combina com as outras opções.");
    var hintTrava = el("p", "dlg-hint", "Este nome é usado por um contador de dias: para trocar o nome, mude também o ((DIAS DESDE @…)).");
    hintTrava.hidden = !sp.travado;
    caixa.appendChild(c1.l); caixa.appendChild(f1.sub); caixa.appendChild(c2.l); caixa.appendChild(f2.sub); caixa.appendChild(hintTrava);
    caixa.appendChild(c3.l); caixa.appendChild(hintGrande);

    c1.c.checked = !!sp.valor && !sp.grande; c2.c.checked = sp.ligado; c3.c.checked = sp.grande;
    function atualizar() {
      var g = c3.c.checked;
      if (g) { c1.c.checked = false; c2.c.checked = false; }
      c1.c.disabled = g; c2.c.disabled = g || sp.travado; c3.c.disabled = sp.travado;
      if (sp.travado) c2.c.checked = true;
      f1.sub.hidden = !c1.c.checked; f2.sub.hidden = !c2.c.checked;
      f2.i.disabled = sp.travado;
      c1.l.classList.toggle("dlg-ck-off", g); c2.l.classList.toggle("dlg-ck-off", g);
    }
    [c1.c, c2.c, c3.c].forEach(function (c) { c.addEventListener("change", atualizar); });
    atualizar();

    var msg = el("p", "dlg-erro");
    caixa.appendChild(msg);
    function salvar() {
      msg.textContent = "";
      var d = limparDica(dica.value), novo;
      if (!d) { msg.textContent = "Escreva a dica: o que o médico deve escrever neste espaço."; dica.focus(); return; }
      if (c3.c.checked) novo = "[..." + d + "]";
      else {
        var v = c1.c.checked ? limparValor(f1.i.value) : "";
        if (c1.c.checked && !v) { msg.textContent = "Escreva o que já vem preenchido, ou desmarque essa opção."; f1.i.focus(); return; }
        var inner = d + (v ? "=" + P.escapar(v) : "");
        if (c2.c.checked) {
          var nm = sp.travado ? sp.nome : limparNome(f2.i.value);
          if (!P.normalizarNome(nm)) { msg.textContent = "Dê um nome ao espaço ligado, com letras ou números (ex.: INTERNAÇÃO)."; f2.i.focus(); return; }
          inner = "@" + nm + ": " + inner;
        }
        novo = "[" + inner + "]";
      }
      // Confere se o resultado não criou problemas novos no modelo inteiro (ex.: um nome que já é de uma escolha)
      var mestre = e.master.value, off = P.Blocos && P.Blocos.deslocamento ? P.Blocos.deslocamento() : 0, antes = {}, novoErro = null;
      I().compilarCache(mestre).erros.forEach(function (x) { antes[x.msg] = true; });
      P.compilar(mestre.slice(0, off + sp.s) + novo + mestre.slice(off + sp.e)).erros.forEach(function (x) { if (!antes[x.msg] && !novoErro) novoErro = x; });
      if (novoErro) { msg.textContent = "Não deu certo: " + novoErro.msg.charAt(0).toUpperCase() + novoErro.msg.slice(1) + "."; return; }
      fecharJ();
      I().substituir(sp.s, sp.e, novo);
      I().dica("Espaço atualizado.");
    }
    [dica, f1.i, f2.i].forEach(function (i) { i.addEventListener("keydown", function (ev) { if (ev.key === "Enter") { ev.preventDefault(); salvar(); } }); });
    var acoes = el("div", "dlg-acoes");
    acoes.appendChild(I().botao("dlg-cancelar", "", "Cancelar", j.fechar));
    acoes.appendChild(I().botao("dlg-ok", "", "✓ Salvar mudanças", salvar));
    j.caixa.appendChild(acoes);
    j.abrir();
    dica.focus(); dica.select();
  };
})();
