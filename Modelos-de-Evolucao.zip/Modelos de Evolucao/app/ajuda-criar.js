/*
 * Ajuda — aba "Criar meu modelo" (o texto; a janela está em ajuda.js). Reaproveita a tabela de regras do criador (P._ed.REGRAS, em
 * personalizados-ajuda.js) e os textos de cópia de segurança (P.TEXTOS_COPIA, em personalizados-arquivo.js): nada é escrito duas vezes.
 */
(function () {
  "use strict";
  var P = window.Personalizados, A = window.Ajuda;

  A.registrar("criar", function (p) {
    A.titulo(p, "Como começar");
    A.lista(p, [
      "Em **Minhas evoluções**, clique em **＋ Criar modelo**. Há três jeitos de começar: **📋 Começar de um modelo pronto** (você ganha uma cópia para mudar; o original não muda), **📝 Colar uma evolução que já uso** ou **✨ Montar do zero**.",
      "Dê um nome ao modelo, marque o que muda de paciente para paciente e clique em **✓ Salvar e usar**.",
      "**Nunca escreva dados de pacientes** (nome, CPF, número de prontuário) dentro de um modelo."
    ]);

    A.titulo(p, "As regras simples");
    A.p(p, "Você pode usar os botões do criador ou digitar estes símbolos direto no texto. O que vai entre colchetes é o que o médico preenche ou escolhe: `[dica]` vira um espaço para preencher (a palavra aparece como dica dentro do espaço) e `[A / B]` vira uma escolha. Cada linha da tabela mostra o que digitar, no que vira e um exemplo.");
    var env = P.el("div", "ajuda-tab-rol"), tab = P.el("table", "ajuda-tab"), cab = P.el("tr");
    ["Digite", "Vira", "Exemplo"].forEach(function (c) { cab.appendChild(P.el("th", "", c)); });
    tab.appendChild(cab);
    ((P._ed && P._ed.REGRAS) || []).forEach(function (r) {
      var tr = P.el("tr"), a = P.el("td"), c = P.el("td");
      a.appendChild(P.el("code", "", r[0])); c.appendChild(P.el("code", "", r[2]));
      tr.appendChild(a); tr.appendChild(P.el("td", "", r[1])); tr.appendChild(c);
      tab.appendChild(tr);
    });
    env.appendChild(tab); p.appendChild(env);

    A.titulo(p, "Os dois modos do editor");
    A.lista(p, [
      "**▦ Com blocos**: cada linha é um bloco. Clique num bloco para escrever nele; <<Enter>> cria um bloco novo; arraste pela alça ⋮⋮ ou use ↑ ↓ para mudar a ordem; 🗑 apaga; **↶ Desfazer** volta a última mudança; **＋ Adicionar bloco** traz peças prontas (título, escolha, sinais vitais, alergias...).",
      "**✎ Escrevendo o texto**: o modelo aparece como vai ficar (espaços amarelos, opções como botões) e você escreve direto nele. Clique num pedaço marcado para mudá-lo; <<Ctrl>>+<<Z>> desfaz.",
      "Dá para trocar de modo a qualquer hora, no alto do criador."
    ]);

    A.titulo(p, "Marcar sem decorar os símbolos");
    A.lista(p, [
      "Selecione um trecho e clique no botão do que ele vira: ▭ espaço para preencher, ◉ escolha entre opções, ✎ texto que pode ser corrigido, 💡 lembrete, T título, 📅 data de hoje, 🔢 contar dias.",
      "Clique com o **botão direito** sobre o trecho: aparecem os mesmos comandos.",
      "Digite **!** no começo da linha (ou depois de um espaço): abre a lista de comandos e de peças prontas. Continue digitando para filtrar e aperte <<Enter>>."
    ]);

    A.titulo(p, "Testar antes de salvar");
    A.p(p, "**▶ Testar o modelo** abre o seu modelo na tela principal, do jeito que o médico vai usar. Nada é salvo. **← Voltar a editar** (ou <<Esc>>) devolve o criador como estava. Se houver algo em vermelho para corrigir, o teste não abre.");

    A.titulo(p, "Rascunho automático");
    A.p(p, "Enquanto você monta um modelo, o texto dele é guardado neste computador. Se a janela fechar sem querer, o app mostra em **Minhas evoluções** o aviso **“Você tem um modelo não terminado”**, com o botão **Continuar**. O rascunho some ao salvar ou ao sair de propósito.");

    A.titulo(p, "Pastas e ordem");
    A.lista(p, [
      "**＋ Nova pasta** (em Minhas evoluções) cria uma pasta. Botão direito no nome da pasta: novo modelo ali, renomear, enviar a pasta ou apagar (apagar a pasta nunca apaga os modelos).",
      "Para organizar, **arraste** os modelos (ou use <<Alt>>+<<↑>> e <<Alt>>+<<↓>>). <<Alt>>+<<1>> até <<Alt>>+<<9>> seguem a ordem da lista.",
      "Botão direito num modelo: Abrir, Favoritar, Ocultar, Editar, Duplicar, Mover para pasta, Enviar a um colega e Apagar.",
      "**⭐ Favoritar** põe o modelo no alto da lista (ou da pasta dele), sem mudar a ordem que você escolheu. **Ocultar** esconde o modelo da lista, da busca e dos atalhos <<Alt>>+número. Para ver os ocultos, clique em **👁 Mostrar modelos ocultos**, no fim da lista (nos ocultos, o botão direito oferece **Mostrar (deixar de ocultar)**). Favorito e oculto valem só neste computador: não vão no arquivo que você envia nem na cópia de segurança."
    ]);

    A.titulo(p, "Enviar a um colega e Abrir arquivo de modelo");
    A.lista(p, [
      "Botão direito no modelo > **Enviar a um colega** salva um arquivo de texto (**📤 Salvar todos em arquivo** salva todos de uma vez). Mande o arquivo por pendrive, e-mail ou mensagem.",
      "Quem recebe usa **📥 Abrir arquivo de modelo** e escolhe o arquivo (ou cola o texto recebido por mensagem).",
      "Se o modelo recebido já existe no computador e o texto é diferente, o app pergunta: **Atualizar o meu** (troca só o texto; o nome e a pasta ficam), **Ficar com os dois** ou **Pular**. Você pode marcar “fazer o mesmo para os próximos”. Antes de atualizar, o app guarda uma cópia de segurança. Se o texto for idêntico, o modelo é pulado sem perguntar. No fim, o app mostra quantos são novos, quantos foram atualizados e quantos eram iguais."
    ]);

    A.titulo(p, "Cópia de segurança e outros computadores");
    (P.TEXTOS_COPIA || []).forEach(function (t) { A.p(p, t); });

    A.titulo(p, "Sem tempo? Peça para uma IA");
    A.p(p, "No criador há a seção **🤖 Sem tempo? Peça para uma IA montar o modelo (opcional)**, com um pedido pronto para copiar e colar numa inteligência artificial de sua preferência. **Nunca cole dados de pacientes** e confira o resultado antes de salvar.");
  });
})();
