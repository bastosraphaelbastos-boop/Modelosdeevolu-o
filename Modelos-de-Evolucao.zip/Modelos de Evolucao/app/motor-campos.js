/*
 * Motor — os espaços para preencher ({campo:dica}, {hoje}) (parte do motor.js; carregue antes dele).
 *
 * O espaço é um <span contenteditable="plaintext-only"> (como os trechos corrigíveis {editavel}), não um <input>: assim o texto QUEBRA A LINHA
 * junto com a frase e cresce em altura quando é longo, sem nunca passar da largura do painel. A dica aparece por CSS (:empty::before, lida do
 * data-dica) e também em aria-label. Regras que valem para todo espaço:
 *   - Enter nunca cria quebra de linha: vai ao próximo pendente (quem chama passa hooks.enter);
 *   - só texto puro entra (colar usa o texto simples, sem formatação; quebras de linha viram espaço);
 *   - datas e horas digitadas só com números ganham as barras e os dois-pontos ao sair do campo (27092026 -> 27/09/2026);
 *   - curto = compacto, com largura mínima pela dica (inline-block); passou da dica, vira texto corrido que quebra a linha (".longo").
 * Os campos "auxiliar" (só na tela, roxos) continuam sendo <input> de uma linha. Peças compartilhadas em window.MotorPecas; esta fica em M.Campos.
 */
(function () {
  "use strict";
  var M = window.MotorPecas = window.MotorPecas || {};
  var C = M.Campos = {};

  // Atalhos de digitação, sempre pela dica do campo (nunca muda o que já está escrito com sinais):
  // 27092026 -> 27/09/2026 · 270926 -> 27/09/2026 · 2709 -> 27/09 · 1430 -> 14:30 (data ou hora)
  // 1/9/26 -> 01/09/2026 (dica com "aaaa") · PA (ou dica ___/___) 12080 -> 120/80 · temperatura (ou dica "ex. 36,5") 365 -> 36,5 · Apgar 89 -> 8/9, 910 -> 9/10
  var RE_PA = /\bPA\b|press[aã]o|\d{2,3}\/\d{2,3}\s*mmHg|^_+\/_+$/i, RE_TEMP = /\btemp(\.|eratura|\b)|\btax\b|°\s*C|axilar|\b3\d,\d\b/i, RE_APGAR = /apgar|\b\d\/\d\b/i;
  function formatarNumeros(v, dica) {
    var d = v.trim(), m;
    if (/aaaa/i.test(dica) && (m = d.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2}|\d{4})$/)))
      return m[1].padStart(2, "0") + "/" + m[2].padStart(2, "0") + "/" + (m[3].length === 2 ? "20" + m[3] : m[3]);
    if (/dd\/mm|data/i.test(dica) && /hh:mm|\bhora\b/i.test(dica) && (m = d.match(/^(\d{2})\/?(\d{2})\/?(\d{4}) ?(\d{1,2})(\d{2})$/)))
      return m[1] + "/" + m[2] + "/" + m[3] + " " + m[4].padStart(2, "0") + ":" + m[5];
    if (!/^\d+$/.test(d)) return v;
    var ehData = /dd\/mm|data/i.test(dica), ehHora = /hh:mm|\bhora\b/i.test(dica);
    // dica com data E hora ("data e hora"): 12 dígitos = os dois; 3 ou 4 dígitos = hora
    if (ehData && ehHora && d.length === 12) return d.slice(0, 2) + "/" + d.slice(2, 4) + "/" + d.slice(4, 8) + " " + d.slice(8, 10) + ":" + d.slice(10);
    if (ehData && !(ehHora && d.length <= 4)) {
      if (d.length === 8) return d.slice(0, 2) + "/" + d.slice(2, 4) + "/" + d.slice(4);
      if (d.length === 6) return d.slice(0, 2) + "/" + d.slice(2, 4) + "/20" + d.slice(4);
      if (d.length === 4) return d.slice(0, 2) + "/" + d.slice(2);
    }
    if (ehHora && (d.length === 3 || d.length === 4)) return d.slice(0, d.length - 2).padStart(2, "0") + ":" + d.slice(-2);
    if (RE_PA.test(dica) && d.length >= 4 && d.length <= 6) { var c = d.length === 4 ? 2 : 3; return d.slice(0, c) + "/" + d.slice(c); }
    if (RE_TEMP.test(dica) && /^(3[0-9]|4[0-3])\d$/.test(d)) return d.slice(0, 2) + "," + d.slice(2);
    if (RE_APGAR.test(dica)) {
      if (d.length === 2) return d[0] + "/" + d[1];
      if (d.length === 3 && /10$/.test(d)) return d[0] + "/10";
      if (d === "1010") return "10/10";
    }
    return v;
  }

  // Enquanto digita (devolve o texto novo, ou null para deixar como está): 8 dígitos de data e 4 de hora formatam na hora;
  // hora completa ignora dígito a mais. Dica com data E hora só formata ao sair do campo (a data seria cortada no meio).
  function aoDigitar(d, dica) {
    var ehData = /dd\/mm|data/i.test(dica), ehHora = /hh:mm|\bhora\b/i.test(dica);
    if (ehData && ehHora) return null;
    if (/^\d{8}$/.test(d) || (/^\d{4}$/.test(d) && ehHora)) { var v = formatarNumeros(d, dica); return v !== d ? v : null; }
    if (ehHora && /^\d{2}:\d{3,}$/.test(d)) return d.slice(0, 5);
    return null;
  }

  // Quem é espaço de preencher (span.campo) ou campo de uma linha (input.auxiliar)
  // Aplica agora os atalhos de digitação do campo com o cursor (o copiar chama, para não sair "12080" sem sair do campo)
  C.formatar = function (el) {
    if (!el || !el.classList || !(el.classList.contains("campo") || el.classList.contains("auxiliar"))) return;
    var input = el.tagName === "INPUT", atual = input ? el.value : el.textContent, v = formatarNumeros(atual, C.dica(el));
    if (v === atual) return;
    if (input) el.value = v; else { C.escrever(el, v); if (document.activeElement === el) cursorNoFim(el); }
    el.dispatchEvent(new Event("input"));
  };
  C.ehEntrada = function (el) { return el.tagName === "INPUT" || el.classList.contains("campo"); };
  C.ler = function (el) { return el.tagName === "INPUT" ? el.value : C.espacos(el.textContent); };

  // Espaços "invisíveis" que vêm de outros sistemas ou que o navegador põe sozinho (espaço não separável, tab, espaços
  // Unicode) viram espaço comum, e os de largura zero somem — assim não chegam ao prontuário. Só na LEITURA e ao colar:
  // mexer no texto durante a digitação tiraria o cursor do lugar.
  var Fc = String.fromCharCode;
  var ESPACOS = new RegExp("[\\t" + Fc(0xA0) + Fc(0x2000) + "-" + Fc(0x200A) + Fc(0x202F) + Fc(0x205F) + Fc(0x3000) + "]", "g");
  var LARGURA_ZERO = new RegExp("[" + Fc(0x200B) + "-" + Fc(0x200D) + Fc(0x2060) + Fc(0xFEFF) + "]", "g");
  C.espacos = function (t) { return String(t).replace(ESPACOS, " ").replace(LARGURA_ZERO, ""); };
  C.dica = function (el) { return el.tagName === "INPUT" ? el.placeholder : el.dataset.dica || ""; };

  // Compacto enquanto cabe na largura da dica; depois vira texto corrido (quebra a linha). O <input> ajusta a largura pelo size.
  C.ajustar = function (el) {
    if (el.tagName === "INPUT") { el.size = Math.max(el.placeholder.length, el.value.length, 3) + 1; return; }
    el.classList.toggle("longo", el.textContent.length > Math.max(C.dica(el).length, 3));
  };
  C.escrever = function (el, v) {
    if (el.tagName === "INPUT") el.value = v; else el.textContent = v;
    C.ajustar(el);
  };

  function cursorNoFim(el) {
    var sel = window.getSelection(), r = document.createRange();
    r.selectNodeContents(el); r.collapse(false); sel.removeAllRanges(); sel.addRange(r);
  }
  // quebras de linha (inclusive U+2028/U+2029) e caracteres de controle (inclusive as marcas internas U+E000 a U+E003 do motor) viram espaço
  var F = String.fromCharCode;
  var UMA_LINHA = new RegExp("\\s*[\\r\\n" + F(0x2028) + F(0x2029) + "]+\\s*", "g");
  var CONTROLES = new RegExp("[" + F(0) + "-" + F(8) + F(11) + F(12) + F(14) + "-" + F(31) + F(127) + F(0xE000) + "-" + F(0xE003) + "]", "g");
  var umaLinha = function (t) { return t.replace(CONTROLES, " ").replace(UMA_LINHA, " "); };      // sem quebras de linha nem caracteres de controle

  // Espaço para preencher. s = { id, rotulo }, valor = texto inicial. hooks = { enter(el), digitou(el) }
  C.criar = function (s, valor, hooks) {
    var el = document.createElement("span"), dica = s.rotulo || "";
    el.className = "campo"; el.dataset.id = s.id; el.dataset.dica = dica;
    el.style.setProperty("--n", String(Math.max(dica.length, 3)));
    try { el.contentEditable = "plaintext-only"; } catch (e) { el.contentEditable = "true"; }
    el.tabIndex = 0;                                                                // entra na ordem do Tab, como o <input> entrava
    el.setAttribute("role", "textbox"); el.setAttribute("aria-multiline", "false"); el.setAttribute("aria-label", dica || "Espaço para preencher");
    if (valor) el.textContent = valor;
    C.ajustar(el);

    // Enter pula para o próximo item sem preencher (nunca cria quebra de linha)
    el.addEventListener("keydown", function (e) {
      if (e.key === "Enter") { e.preventDefault(); if (!e.ctrlKey && !e.altKey && !e.metaKey) hooks.enter(el); }
    });
    el.addEventListener("beforeinput", function (e) { if (e.inputType === "insertParagraph" || e.inputType === "insertLineBreak") e.preventDefault(); });

    // Colar: só o texto simples, em uma linha só (nunca HTML)
    el.addEventListener("paste", function (e) {
      e.preventDefault();
      var t = C.espacos(umaLinha((e.clipboardData && e.clipboardData.getData("text/plain")) || ""));
      if (!t.trim()) return;                                                          // só espaços ou linhas em branco: nada entra (a dica continua)
      var ok = false;
      try { ok = document.execCommand("insertText", false, t); } catch (x) { ok = false; }      // (mantém o Ctrl+Z)
      if (!ok) {
        var sel = window.getSelection();
        if (sel.rangeCount) { var r = sel.getRangeAt(0); r.deleteContents(); r.insertNode(document.createTextNode(t)); r.collapse(false); sel.removeAllRanges(); sel.addRange(r); }
        el.dispatchEvent(new Event("input"));
      }
    });

    // Ao sair do campo, completa datas e horas digitadas só com números
    el.addEventListener("blur", function () {
      var v = formatarNumeros(el.textContent, dica);
      if (v !== el.textContent) { C.escrever(el, v); el.dispatchEvent(new Event("input")); }
    });

    el.addEventListener("input", function () {
      if (!el.textContent && el.innerHTML !== "") el.innerHTML = "";                 // tira o <br> que o navegador deixa ao apagar tudo
      var t = el.textContent, u = umaLinha(t);
      if (u !== t) { el.textContent = u; cursorNoFim(el); }                           // texto solto com quebras de linha (arrastado, por exemplo): vira uma linha só
      var d = el.textContent.trim();
      var nv = aoDigitar(d, dica);
      if (nv !== null) { el.textContent = nv; cursorNoFim(el); }
      C.ajustar(el); el.classList.remove("calculado");
      hooks.digitou(el);
    });
    return el;
  };

  // Campo auxiliar (só na tela): uma linha, como sempre foi
  C.criarAuxiliar = function (s, valor, hooks) {
    var el = document.createElement("input");
    el.className = "auxiliar"; el.placeholder = s.rotulo; el.value = valor; el.dataset.id = s.id;
    C.ajustar(el);
    el.addEventListener("keydown", function (e) { if (e.key === "Enter" && !e.ctrlKey && !e.altKey && !e.metaKey) { e.preventDefault(); hooks.enter(el); } });
    el.addEventListener("blur", function () {
      var v = formatarNumeros(el.value, el.placeholder);
      if (v !== el.value) { el.value = v; el.dispatchEvent(new Event("input")); }
    });
    el.addEventListener("input", function () {
      var d = el.value.trim();
      var nv = aoDigitar(d, el.placeholder);
      if (nv !== null) el.value = nv;
      C.ajustar(el); el.classList.remove("calculado");
      hooks.digitou(el);
    });
    return el;
  };
})();
