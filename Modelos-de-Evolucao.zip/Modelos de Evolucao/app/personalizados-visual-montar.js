/*
 * Editor visual do modo Texto — clicar num pedaço (abre o que muda ele), montar o editor (V.criar) e a "ponte" que os comandos (botão direito e "!")
 * usam. Parte de personalizados-visual.js; carregue depois de personalizados-visual-edicao.js.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var V = P.Visual;
  var I = function () { return P._ed; };
  var ed = function () { return I().estado(); };
  var st = null; V.aoMudarEstado(function (x) { st = x; });
  var desenhar = function () { return V._f.desenhar(); }, colocarCursor = function (a, b) { return V._f.colocarCursor(a, b); },
      selecaoModelo = function () { return V._f.selecaoModelo(); }, linhaDe = function (n) { return V._f.linhaDe(n); }, espelhar = function () { return V._f.espelhar(); },
      trocar = function (a, b, n, t, ca, cb) { return V._f.trocar(a, b, n, t, ca, cb); }, desfazer = function (v) { return V._f.desfazer(v); },
      aoBeforeInput = function (e) { return V._f.aoBeforeInput(e); }, acertarComposicao = function () { return V._f.acertarComposicao(); };

  var el = P.el;

  // ---------- clicar num pedaço ----------
  function abrirPedaco(chip) {
    var L = linhaDe(chip), i = st.linhas.indexOf(L), ini = st.bases[i] + L._pref + chip._ri, fim = st.bases[i] + L._pref + chip._rf;
    var m = ed().master;
    m.setSelectionRange(ini + 1, ini + 1);
    st.voltar = true; st.fimPedaco = fim;
    var tp = chip._tipo;
    if (tp === "escolha" || tp === "se") I().dialogoOpcoes();
    else if (tp === "espaco") I().acaoEspaco();
    else if (tp === "corrigivel") editarTexto("Texto já escrito (o médico pode corrigir na hora)", chip._cru.slice(1, -1), ini, fim, function (v) { return "*" + v + "*"; });
    else if (tp === "dica" || tp === "aviso") {
      var corpo = chip._cru.replace(/^\(\(\s*(DICA|AVISO)\s*:\s*/i, "").replace(/\)\)$/, "");
      editarTexto(tp === "dica" ? "Lembrete (aparece só na tela)" : "Aviso (aparece na tela; no texto fica ___ até resolver)", corpo, ini, fim,
        function (v) { return "((" + (tp === "dica" ? "DICA" : "AVISO") + ": " + v + "))"; });
    }
    else if (tp === "dias") I().dica("Este número de dias é contado sozinho a partir da data. Para mudar, apague (Backspace) e use “Contar dias”.");
    else editarTexto("Marcação avançada (escreva com cuidado)", chip._cru, ini, fim, function (v) { return v; }, true);
  }
  V.abrirPedaco = abrirPedaco;

  // Janelinha simples para mudar um texto. montar(valor) -> texto novo do pedaço. cru: sem limpar símbolos.
  function editarTexto(titulo, valor, ini, fim, montar, cru) {
    var j = I().janelinha("dlg-wy-titulo", titulo, true);
    var cx = el("textarea", "dlg-extra-ta"); cx.rows = 3; cx.value = valor; cx.maxLength = 3000;
    var msg = el("p", "dlg-erro");
    j.corpo.appendChild(cx); j.corpo.appendChild(msg);
    var acoes = el("div", "dlg-acoes");
    var ok = function () {
      var v = cru ? cx.value : cx.value.replace(/\s*\n\s*/g, " ").trim();
      if (!cru && /[*()\[\]{}]/.test(v)) { msg.textContent = "Não use * ( ) [ ] { } aqui."; cx.focus(); return; }
      if (!v.trim()) { msg.textContent = "Escreva o texto (ou feche e apague o pedaço com Backspace)."; cx.focus(); return; }
      j.fechar();
      I().substituir(ini, fim, montar(v));
    };
    acoes.appendChild(I().botao("dlg-cancelar", "", "Cancelar", j.fechar));
    acoes.appendChild(I().botao("dlg-ok", "", "✓ Salvar", ok));
    j.caixa.appendChild(acoes);
    cx.addEventListener("keydown", function (e) { if (e.key === "Enter" && !e.shiftKey && !cru) { e.preventDefault(); ok(); } });
    j.abrir(); cx.focus(); cx.select();
  }
  V.editarTexto = editarTexto;

  // Seleção para copiar/recortar: se começa no início do texto de um título, leva também o "#" (na tela o "#" não aparece)
  function selecaoParaCopiar() {
    var x = selecaoModelo(); if (!x || x.a === x.b) return x;
    for (var i = 0; i < st.linhas.length; i++) {
      if (st.linhas[i]._pref > 0 && st.bases[i] + st.linhas[i]._pref === x.a) return { a: st.bases[i], b: x.b };
    }
    return x;
  }

  // ---------- montar ----------
  V.criar = function () {
    var r = el("div", "wy-editor ep-previa");
    r.contentEditable = "true"; r.spellcheck = true; r.lang = "pt-BR";
    r.setAttribute("role", "textbox"); r.setAttribute("aria-multiline", "true");
    r.setAttribute("aria-label", "Texto do modelo (como vai ficar). Digite ! para ver os comandos");
    r.dataset.ph = "Escreva ou cole aqui a evolução. Depois selecione o que muda de paciente para paciente e escolha o que vira (botões acima, botão direito ou digite ! para ver os comandos).";
    V.definirEstado({ raiz: r, linhas: [], unidades: [], bases: [], hist: [], refazer: [], ultimo: null, ultTipo: "", ultHora: 0, voltar: false, busca: null });
    r.addEventListener("beforeinput", aoBeforeInput);
    r.addEventListener("compositionend", function () { setTimeout(acertarComposicao, 0); });
    r.addEventListener("input", function (e) { if (e.inputType === "insertCompositionText" || e.isComposing) return; acertarComposicao(); });
    r.addEventListener("keydown", function (e) {
      if (st.busca && st.busca.aberta() && st.busca.tecla(e)) return;
      var k = e.key.toLowerCase();
      if ((e.ctrlKey || e.metaKey) && !e.altKey && k === "z") { e.preventDefault(); desfazer(e.shiftKey); }
      else if ((e.ctrlKey || e.metaKey) && !e.altKey && k === "y") { e.preventDefault(); desfazer(true); }
      else if ((e.ctrlKey || e.metaKey) && !e.altKey && (k === "b" || k === "i" || k === "u")) e.preventDefault();
    });
    r.addEventListener("copy", function (e) { var x = selecaoParaCopiar(); if (!x || x.a === x.b) return; e.preventDefault(); e.clipboardData.setData("text/plain", ed().master.value.slice(x.a, x.b)); });
    r.addEventListener("cut", function (e) {
      var x = selecaoParaCopiar(); if (!x || x.a === x.b) return;
      e.preventDefault(); e.clipboardData.setData("text/plain", ed().master.value.slice(x.a, x.b)); trocar(x.a, x.b, "", "apagar");
    });
    r.addEventListener("dragstart", function (e) { e.preventDefault(); });
    r.addEventListener("drop", function (e) { e.preventDefault(); I().dica("Para mover texto aqui, use copiar e colar (Ctrl+C / Ctrl+V)."); });
    r.addEventListener("click", function (e) {
      var chip = e.target.closest && e.target.closest(".wy-chip");
      if (chip && r.contains(chip)) { e.preventDefault(); abrirPedaco(chip); }
    });
    r.addEventListener("focusin", function () { st.voltar = true; });
    document.addEventListener("selectionchange", function () { if (st && document.activeElement === r) espelhar(); });
    if (P.Comandos) {
      st.ponte = V.ponte(); st.ponte.busca = function () { return st.busca; };
      st.busca = P.Comandos.busca(st.ponte); P.Comandos.menuVisual(r, st.ponte);
      r.addEventListener("blur", function () { setTimeout(function () { if (st && st.busca && document.activeElement !== r) st.busca.fechar(); }, 0); });
    }
    return r;
  };

  // ed.master mudou por fora (botões, janelinhas, peças prontas): redesenha e devolve o cursor ao editor visual
  V.aoMudarMestre = function () {
    if (!st || ed().modo !== "texto") return;
    if (st.ultimo != null && st.ultimo !== ed().master.value) {
      st.hist.push({ t: st.ultimo, a: ed().master.selectionStart, b: ed().master.selectionStart });
      st.refazer = []; st.ultTipo = "";
    }
    desenhar();
    if (st.voltar) setTimeout(function () {
      if (!st || ed() == null || ed().modo !== "texto" || document.querySelector(".dlg-pers")) return;
      var m = ed().master; st.raiz.focus({ preventScroll: true }); colocarCursor(m.selectionStart, m.selectionEnd);
    }, 0);
  };
  // Janelinha fechada (Cancelar, Esc ou OK): o foco volta ao editor visual (nunca ao texto invisível), logo depois do pedaço aberto
  V.voltarDoDialogo = function () {
    if (!st || ed() == null || ed().modo !== "texto") return false;
    var m = ed().master, pos = st.fimPedaco != null && st.fimPedaco <= m.value.length ? st.fimPedaco : null;
    st.fimPedaco = null; st.raiz.focus({ preventScroll: true });
    if (pos != null) colocarCursor(pos); else colocarCursor(m.selectionStart, m.selectionEnd);
    return true;
  };
  V.recarregar = function () { if (!st) return; st.unidades = []; st.linhas = []; st.hist = []; st.refazer = []; desenhar(); };
  V.focar = function (pos) { if (!st) return; st.raiz.focus({ preventScroll: true }); colocarCursor(pos == null ? ed().master.value.length : pos); };
  V.irPara = function (a, b) { if (!st) return; st.raiz.focus(); colocarCursor(a, b); };
  V.raiz = function () { return st && st.raiz; };
  V.fechar = function () { V.definirEstado(null); };

  // O que os comandos (botão direito e "!") precisam deste editor
  V.ponte = function () {
    return {
      tipo: "visual",
      raiz: function () { return st.raiz; },
      selecao: function () { return selecaoModelo(); },
      sincronizar: espelhar,
      retangulo: function () { var s = window.getSelection(); if (!s.rangeCount) return st.raiz.getBoundingClientRect(); var rr = s.getRangeAt(0).getClientRects(); return rr.length ? rr[rr.length - 1] : st.raiz.getBoundingClientRect(); },
      texto: function () { return ed().master.value; },
      trocar: function (a, b, novo) { trocar(a, b, novo, "comando"); },
      pedacoEm: function (no) { var c = no && no.closest && no.closest(".wy-chip"); return c && st.raiz.contains(c) ? c : null; },
      abrirPedaco: abrirPedaco,
      posPedaco: function (c) { var L = linhaDe(c), i = st.linhas.indexOf(L), b0 = st.bases[i] + L._pref; return { a: b0 + c._ri, b: b0 + c._rf }; },
      focar: function () { st.raiz.focus({ preventScroll: true }); },
      marcarVoltar: function () { st.voltar = true; }
    };
  };
})();
