/*
 * Evoluções personalizadas — comandos do criador por BOTÃO DIREITO e por "!" (como o "/" do Notion).
 *   - Botão direito sobre o texto (modo Texto visual) ou dentro de um bloco aberto (modo Blocos): os mesmos comandos da barra
 *     (espaço, escolha, corrigível, lembrete, título, data, dias, desfazer marcação), além de copiar/recortar e "Mais comandos".
 *     Sobre um pedaço já marcado (modo Texto): mudar, desfazer a marcação, editar como texto, apagar.
 *     Shift + botão direito abre o menu normal do navegador (corretor ortográfico).
 *   - "!" no começo da linha ou depois de um espaço abre a lista de comandos; o que se digita depois filtra ("!esc" -> Escolha).
 *     Enter escolhe, Esc fecha. O "!" e o que foi digitado somem quando o comando é escolhido.
 *     (Não é "/" porque o médico digita barra o tempo todo: datas 27/09, "8/9".)
 * Cada lugar onde se escreve entrega uma "ponte" (personalizados-visual.js ou ponteTextarea, abaixo) com o que o comando precisa.
 * Os comandos em si são os do criador (P._ed): a seleção é levada para ed.ta antes de rodar.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var C = P.Comandos = {};
  var I = function () { return P._ed; };
  var ed = function () { return I().estado(); };
  var el = P.el;
  var semAcento = function (t) { return String(t).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); };

  // Põe o cursor/seleção em ed.ta (onde os comandos do criador trabalham)
  function selecionarEmTa(a, b) { try { ed().ta.setSelectionRange(a, b == null ? a : b); } catch (e) { /* sem problema */ } }
  function blocos() { return ed().modo === "blocos"; }

  // ---------- lista de comandos para "!" (inserem algo onde está o cursor) ----------
  // fazer(pos): pos = onde o cursor está (no texto de ed.ta)
  function inserirAqui(ponte, pos, texto, cursorDentro) {
    ponte.trocar(pos, pos, texto);
    selecionarEmTa(cursorDentro != null ? pos + cursorDentro : pos + texto.length);
  }
  function comandosBusca(ponte) {
    var lista = [
      { ic: "▭", nome: "Espaço para preencher", chaves: "campo espaco preencher em branco", fazer: function (p) { inserirAqui(ponte, p, "[preencher]", 1); I().acaoEspaco(); } },
      { ic: "◉", nome: "Escolha entre opções", chaves: "escolha opcao opcoes botoes", fazer: function () { I().dialogoOpcoes({ nova: true }); } },
      { ic: "❓", nome: "Pergunta só na tela", chaves: "pergunta tela alta", fazer: function () { I().dialogoOpcoes({ nova: true, pergunta: true }); } },
      { ic: "✎", nome: "Texto que pode ser corrigido", chaves: "corrigivel texto escrito corrigir", fazer: function (p) {
        P.Visual.editarTexto("Texto já escrito (o médico pode corrigir na hora)", "", p, p, function (v) { return "*" + v + "*"; }); } },
      { ic: "💡", nome: "Lembrete (só na tela)", chaves: "lembrete dica nota", fazer: function (p) {
        P.Visual.editarTexto("Lembrete (aparece só na tela)", "", p, p, function (v) { return "((DICA: " + v + "))"; }); } },
      { ic: "T", nome: "Título", chaves: "titulo secao parte cabecalho", fazer: function () { I().acaoTitulo(); } },
      { ic: "📅", nome: "Data de hoje", chaves: "data hoje dia", fazer: function () { I().acaoHoje(); } },
      { ic: "🔢", nome: "Contar dias", chaves: "dias contar internacao antibiotico", fazer: function () { I().dialogoDias(); } },
      { ic: "✍", nome: "Caixa de texto livre (opcional)", chaves: "livre observacoes caixa texto", fazer: function (p) { inserirAqui(ponte, p, "[...observações]"); } }
    ];
    P.Prontos.ITENS[1].itens.forEach(function (item) {      // as peças prontas (sinais vitais, alergias...)
      lista.push({ ic: item.ic, nome: item.nome, chaves: item.desc, pronto: true, fazer: function () {
        if (blocos()) P.Blocos.adicionarPronto(item); else P.Prontos.inserirNoTexto(item);
      } });
    });
    return lista;
  }

  // ---------- a lista "!" ----------
  // ponte: { selecao(), texto(), trocar(a,b,novo), retangulo(), focar(), sincronizar(), marcarVoltar() }
  C.busca = function (ponte) {
    var caixa = null, itens = [], ativo = 0, ini = -1, porMenu = false;
    var b = {
      aberta: function () { return !!caixa; },
      abrir: function (deMenu) {
        var x = ponte.selecao(); if (!x) return;
        porMenu = !!deMenu; ini = porMenu ? x.a : x.a - 1;
        if (!caixa) {
          caixa = el("div", "cmd-busca"); caixa.setAttribute("role", "listbox"); caixa.setAttribute("aria-label", "Comandos");
          caixa.addEventListener("mousedown", function (e) { e.preventDefault(); });        // o cursor continua no texto
          document.body.appendChild(caixa);
          document.addEventListener("mousedown", fora, true);
          window.addEventListener("resize", b.fechar);
        }
        desenhar("");
      },
      fechar: function () {
        if (!caixa) return;
        caixa.remove(); caixa = null; ini = -1;
        document.removeEventListener("mousedown", fora, true);
        window.removeEventListener("resize", b.fechar);
      },
      // depois de cada mudança do texto: refaz o filtro (ou fecha se o "!" sumiu ou o cursor saiu de perto)
      depoisDeMudar: function () {
        if (!caixa) return;
        var x = ponte.selecao(), t = ponte.texto();
        if (!x || x.a !== x.b || x.a < ini + (porMenu ? 0 : 1) || (!porMenu && t.charAt(ini) !== "!")) { b.fechar(); return; }
        var q = t.slice(ini + (porMenu ? 0 : 1), x.a);
        if (/\n/.test(q) || q.length > 30) { b.fechar(); return; }
        desenhar(q);
        if (!itens.length && /\s$/.test(q)) b.fechar();
      },
      tecla: function (e) {                 // devolve true se tratou a tecla
        if (!caixa) return false;
        var parar = function () { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); };      // o bloco não trata a mesma tecla
        if (e.key === "ArrowDown" || e.key === "ArrowUp") { parar(); if (itens.length) { ativo = (ativo + (e.key === "ArrowDown" ? 1 : itens.length - 1)) % itens.length; marcar(); } return true; }
        if (e.key === "Enter" || e.key === "Tab") { if (!itens.length) { b.fechar(); return false; } parar(); escolher(itens[ativo]); return true; }
        if (e.key === "Escape") { parar(); b.fechar(); return true; }
        return false;
      }
    };
    function fora(e) { if (caixa && !caixa.contains(e.target)) b.fechar(); }
    function desenhar(q) {
      var nq = semAcento(q).trim();
      itens = comandosBusca(ponte).filter(function (c) { return !nq || semAcento(c.nome + " " + c.chaves).indexOf(nq) !== -1; });
      caixa.textContent = "";
      caixa.appendChild(el("p", "cmd-tit", q ? "Comandos com “" + q + "”" : "Comandos (continue digitando para filtrar)"));
      if (!itens.length) caixa.appendChild(el("p", "cmd-vazio", "Nenhum comando com esse nome. Esc fecha."));
      var ultPronto = false;
      itens.forEach(function (c, k) {
        if (c.pronto && !ultPronto) { caixa.appendChild(el("p", "cmd-grupo", "Peças prontas")); ultPronto = true; }
        var bt = el("button", "cmd-item"); bt.type = "button"; bt.tabIndex = -1; bt.setAttribute("role", "option");
        var ic = el("span", "cmd-ic", c.ic); ic.setAttribute("aria-hidden", "true");
        bt.appendChild(ic); bt.appendChild(el("span", "", c.nome));
        bt.addEventListener("click", function () { escolher(c); });
        bt.addEventListener("mousemove", function () { if (ativo !== k) { ativo = k; marcar(); } });
        caixa.appendChild(bt);
      });
      caixa.appendChild(el("p", "cmd-rodape", "↑ ↓ escolhem · Enter usa · Esc fecha"));
      ativo = Math.min(ativo, Math.max(0, itens.length - 1));
      marcar(); posicionar();
    }
    function marcar() {
      Array.prototype.forEach.call(caixa.querySelectorAll(".cmd-item"), function (x, k) { x.classList.toggle("ativo", k === ativo); x.setAttribute("aria-selected", k === ativo ? "true" : "false"); });
      var a = caixa.querySelectorAll(".cmd-item")[ativo]; if (a) a.scrollIntoView({ block: "nearest" });
    }
    function posicionar() {
      var r = ponte.retangulo(), vw = document.documentElement.clientWidth, vh = document.documentElement.clientHeight;
      var w = caixa.offsetWidth, h = caixa.offsetHeight, x = Math.min(r.left, vw - w - 8), y = r.bottom + 6;
      if (y + h > vh - 8) y = Math.max(8, r.top - h - 6);
      caixa.style.left = Math.max(8, x) + "px"; caixa.style.top = y + "px";
    }
    function escolher(c) {
      var x = ponte.selecao(), fim = x ? x.a : ini, de = ini;
      b.fechar();
      ponte.marcarVoltar();
      if (fim > de) ponte.trocar(de, fim, "");            // tira o "!" e o que foi digitado depois dele
      ponte.sincronizar();
      c.fazer(de);
    }
    return b;
  };

  // O "!" acabou de ser digitado no começo da linha ou depois de um espaço?
  function prontoParaBang(ponte) {
    var x = ponte.selecao(); if (!x || x.a !== x.b) return false;
    var t = ponte.texto(), i = x.a - 1;
    return t.charAt(i) === "!" && (i === 0 || /\s/.test(t.charAt(i - 1)));
  }

  // ---------- menu do botão direito ----------
  function aguarda(b) { return !b || b.classList.contains("aguarda"); }
  function itensMenu(ponte, busca, x) {
    var e = ed(), t = ponte.texto(), temSel = x && x.a !== x.b;
    var correr = function (f) { return function () { ponte.marcarVoltar(); ponte.sincronizar(); f(); }; };
    var copiarTexto = function (s) {
      if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(s).catch(function () { reserva(s); }); else reserva(s);
    };
    var lista = [
      { icone: "▭", texto: e.bEspaco.querySelector(".tx").textContent, desativado: aguarda(e.bEspaco), titulo: "Selecione um trecho (ou clique dentro de um espaço)", aoClicar: correr(I().acaoEspaco) },
      { icone: "◉", texto: e.bOpcoes.querySelector(".tx").textContent, desativado: aguarda(e.bOpcoes), titulo: "Selecione o trecho que será a 1ª opção", aoClicar: correr(function () { I().dialogoOpcoes(); }) },
      { icone: "✎", texto: "Texto que pode ser corrigido", desativado: !temSel, titulo: "Selecione um trecho", aoClicar: correr(I().acaoCorrigivel) },
      { icone: "💡", texto: "Lembrete (só na tela)", aoClicar: correr(I().acaoLembrete) },
      { icone: "T", texto: "Título (liga/desliga)", separar: true, aoClicar: correr(I().acaoTitulo) },
      { icone: "📅", texto: "Data de hoje", aoClicar: correr(I().acaoHoje) },
      { icone: "🔢", texto: "Contar dias", aoClicar: correr(function () { I().dialogoDias(); }) },
      { icone: "↺", texto: "Desfazer marcação", aoClicar: correr(I().acaoDesfazer) },
      { icone: "＋", texto: "Mais comandos e peças prontas…", separar: true, aoClicar: function () { ponte.focar(); busca.abrir(true); } }
    ];
    if (temSel) {
      lista.push({ icone: "📋", texto: "Copiar", separar: true, aoClicar: function () { copiarTexto(t.slice(x.a, x.b)); ponte.focar(); } });
      lista.push({ icone: "✂", texto: "Recortar", aoClicar: function () { copiarTexto(t.slice(x.a, x.b)); ponte.trocar(x.a, x.b, ""); ponte.focar(); } });
    }
    lista.push({ nota: "Colar: Ctrl+V. Digite ! no texto para ver os comandos. Shift + botão direito abre o menu normal (corretor ortográfico)." });
    return lista;
  }
  function reserva(s) {
    var ta = el("textarea"); ta.value = s; ta.style.position = "fixed"; ta.style.opacity = "0"; document.body.appendChild(ta);
    ta.select(); try { document.execCommand("copy"); } catch (e) { /* sem problema */ } ta.remove();
  }
  function itensPedaco(ponte, chip) {
    var pos = ponte.posPedaco(chip);
    var correr = function (f) { return function () { ponte.marcarVoltar(); selecionarEmTa(pos.a + 1); f(); }; };
    return [
      { icone: "✏️", texto: "Mudar…", aoClicar: function () { ponte.abrirPedaco(chip); } },
      { icone: "↺", texto: "Desfazer marcação (voltar a texto)", aoClicar: correr(I().acaoDesfazer) },
      { icone: "📝", texto: "Editar como texto", aoClicar: function () {
        ponte.marcarVoltar();
        P.Visual.editarTexto("Editar como texto (com as marcações)", ponte.texto().slice(pos.a, pos.b), pos.a, pos.b, function (v) { return v; }, true); } },
      { icone: "🗑", texto: "Apagar", perigo: true, aoClicar: function () { ponte.trocar(pos.a, pos.b, ""); ponte.focar(); } },
      { nota: "Dica: clicar no pedaço também abre “Mudar”." }
    ];
  }

  // Editor visual (modo Texto)
  C.menuVisual = function (raiz, ponte) {
    raiz.addEventListener("contextmenu", function (e) {
      if (e.shiftKey) return;                       // menu normal do navegador
      e.preventDefault();
      var chip = ponte.pedacoEm(e.target), busca = ponte.busca();
      if (chip) { P.MenuContexto.abrir(e.clientX, e.clientY, itensPedaco(ponte, chip), raiz); return; }
      ponte.sincronizar();
      P.MenuContexto.abrir(e.clientX, e.clientY, itensMenu(ponte, busca, ponte.selecao()), raiz);
    });
  };

  // ---------- caixa de texto (bloco aberto no modo Blocos) ----------
  // Posição do cursor na tela, numa caixa de texto (cópia invisível com o mesmo estilo)
  function retanguloCursor(ta) {
    var cs = getComputedStyle(ta), d = el("div"), r = ta.getBoundingClientRect();
    ["fontFamily", "fontSize", "fontWeight", "lineHeight", "letterSpacing", "paddingTop", "paddingRight", "paddingBottom", "paddingLeft", "borderTopWidth", "borderLeftWidth", "boxSizing"].forEach(function (k) { d.style[k] = cs[k]; });
    d.style.position = "fixed"; d.style.visibility = "hidden"; d.style.whiteSpace = "pre-wrap"; d.style.overflowWrap = "break-word";
    d.style.width = r.width + "px"; d.style.left = r.left + "px"; d.style.top = r.top + "px";
    d.textContent = ta.value.slice(0, ta.selectionEnd);
    var m = el("span", "", "​"); d.appendChild(m); document.body.appendChild(d);
    var mr = m.getBoundingClientRect(); d.remove();
    var top = mr.top - ta.scrollTop;
    return { left: mr.left, top: top, bottom: top + (parseFloat(cs.lineHeight) || 22), right: mr.left };
  }
  C.ponteTextarea = function (ta) {
    return {
      tipo: "caixa",
      selecao: function () { return { a: ta.selectionStart, b: ta.selectionEnd }; },
      texto: function () { return ta.value; },
      trocar: function (a, b, novo) { I().substituir(a, b, novo); },
      retangulo: function () { return retanguloCursor(ta); },
      focar: function () { ta.focus(); },
      sincronizar: function () { I().atualizarBotoes(); },
      marcarVoltar: function () { /* a caixa do bloco continua com o foco */ }
    };
  };
  // Liga "!" e o botão direito numa caixa de texto (o bloco aberto). Devolve a busca.
  C.ligarTextarea = function (ta) {
    var ponte = C.ponteTextarea(ta), busca = C.busca(ponte);
    ponte.busca = function () { return busca; };
    ta.addEventListener("keydown", function (e) { if (busca.aberta()) busca.tecla(e); }, true);
    ta.addEventListener("input", function (e) {
      if (busca.aberta()) busca.depoisDeMudar();
      else if (e.data === "!" && prontoParaBang(ponte)) busca.abrir(false);
    });
    ta.addEventListener("blur", function () { setTimeout(function () { if (document.activeElement !== ta) busca.fechar(); }, 0); });
    ta.addEventListener("contextmenu", function (e) {
      if (e.shiftKey) return;
      e.preventDefault();
      I().atualizarBotoes();
      P.MenuContexto.abrir(e.clientX, e.clientY, itensMenu(ponte, busca, ponte.selecao()), ta);
    });
    return busca;
  };

  // Usado pelo editor visual: abre a lista quando o "!" foi digitado no lugar certo
  C.bangVisual = function (busca, ponte) { if (!busca.aberta() && prontoParaBang(ponte)) busca.abrir(false); };
})();
