/*
 * Evoluções personalizadas — paleta de peças prontas ("＋ Adicionar bloco" no modo Blocos e "＋ Inserir pronto" no modo Texto).
 * É um componente só: a lista de peças e a paleta são as mesmas nos dois modos; muda apenas onde a peça entra.
 *  - modo Blocos: cada peça vira um ou mais blocos (personalizados-blocos.js chama pecas() e cuida da inserção);
 *  - modo Texto:  as linhas da peça entram numa linha nova logo depois da linha do cursor (inserirNoTexto).
 * As peças "Escolha entre opções", "Pergunta só na tela" e "Contar dias" abrem o diálogo já em modo "nova"
 * e, se a pessoa cancelar, o espaço vazio criado para elas some.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var X = P.Prontos = {};
  var I = function () { return P._ed; };
  var el = function (tag, classe, texto) { return I().el(tag, classe, texto); };

  // texto: uma ou mais linhas. sel: o que fica selecionado na 1ª linha ([início, fim] ou posição).
  // depois: "opcoes" | "pergunta" | "dias" (abre o diálogo correspondente, em modo "nova")
  X.ITENS = [
    { grupo: "Para montar", itens: [
      { ic: "📝", nome: "Linha de texto", desc: "Uma linha para escrever o que quiser", texto: [""] },
      { ic: "T", nome: "Título", desc: "Nome de uma parte (ex.: EXAME FÍSICO)", texto: ["#NOME DA PARTE"], sel: [1, 14] },
      { ic: "◉", nome: "Escolha entre opções", desc: "O médico clica numa das opções", texto: [""], depois: "opcoes" },
      { ic: "❓", nome: "Pergunta só na tela", desc: "Decide quais textos entram (ex.: Alta hoje?)", texto: [""], depois: "pergunta" },
      { ic: "📅", nome: "Data de hoje", desc: "Já vem com a data do dia", texto: ["DATA: [hoje]"] },
      { ic: "🔢", nome: "Contar dias", desc: "Dias desde uma data (ex.: internação)", texto: [""], depois: "dias" },
      { ic: "✎", nome: "Observações", desc: "Caixa de texto livre, opcional", texto: ["OBSERVAÇÕES: [...observações]"] },
      { ic: "💡", nome: "Lembrete (só na tela)", desc: "Aparece só na tela, não vai para o texto", texto: ["((DICA: escreva aqui o lembrete))"], sel: [8, 31] },
      { ic: "⎯", nome: "Linha em branco", desc: "Espaço entre partes do texto", texto: [""], fechado: true }
    ] },
    { grupo: "Prontos (dá para mudar tudo depois)", itens: [
      { ic: "❤", nome: "Sinais vitais", desc: "PA, FC, FR, temperatura e saturação", texto: ["SINAIS VITAIS: PA [ex. 120X80] MMHG, FC [ex. 80] BPM, FR [ex. 18] IRPM, TAX [ex. 36,5] °C, SATO2 [ex. 98]%"] },
      { ic: "🩺", nome: "Estado geral", desc: "BEG/REG/MEG e achados habituais", texto: ["[BEG / REG / MEG], *CORADA, HIDRATADA, ACIANÓTICA, ANICTÉRICA, AFEBRIL*"] },
      { ic: "⚠", nome: "Alergias", desc: "Nega / refere, com espaço para quais", texto: ["ALERGIAS: [NEGA / REFERE]((SE REFERE: A [quais]))"] },
      { ic: "📋", nome: "Comorbidades", desc: "Nega / refere, com espaço para quais", texto: ["COMORBIDADES: [NEGA / REFERE]((SE REFERE: [quais]))"] },
      { ic: "💊", nome: "Antibiótico com dias", desc: "Nome, data de início e o dia contado sozinho", texto: ["[antibiótico] DESDE [@{ATB}: dd/mm/aaaa] (D((DIAS DESDE @{ATB})))"] },
      { ic: "🛏", nome: "Dias de internação", desc: "Data da internação e o dia contado sozinho", texto: ["DIH: [@{INTERNAÇÃO}: dd/mm/aaaa] (D((DIAS DESDE @{INTERNAÇÃO})))"] },
      { ic: "🏠", nome: "Alta hoje?", desc: "Pergunta com o texto de cada resposta e aviso", texto: ["[? Alta hoje? NÃO / SIM]((SE NÃO: *MANTENHO VIGILÂNCIA CLÍNICA*))((SE SIM: *ALTA HOSPITALAR COM ORIENTAÇÕES*))((SE SEM RESPOSTA: ((AVISO: responda Alta hoje?))))"] },
      { ic: "🧾", nome: "Conduta", desc: "Título CONDUTA e uma linha corrigível", texto: ["#CONDUTA", "*VIDE PRESCRIÇÃO MÉDICA*"] }
    ] }
  ];

  // [@{NOME}] vira um nome que ainda não existe no modelo (ATB, ATB2...), para não ligar sem querer com outro espaço
  function nomesLivres(texto) {
    var usados = {}, ids = {};
    I().estado().master.value.replace(/\[@\s*([^\]:=\n]+)/g, function (x, nm) { ids[P.normalizarNome(nm.trim())] = true; });
    return texto.replace(/\{([^}]+)\}/g, function (x, base) {
      if (usados[base]) return usados[base];
      var n = 1, nome = base;
      var existe = function (nm) { return !!ids[P.normalizarNome(nm)]; };
      while (existe(nome)) nome = base + (++n);
      usados[base] = nome;
      return nome;
    });
  }
  X.pecas = function (item) { return item.texto.map(nomesLivres); };

  // Abre o diálogo da peça (se ela tem um). aoCancelar desfaz o espaço vazio criado para ela.
  X.abrirDialogo = function (item, aoCancelar) {
    if (item.depois === "opcoes") I().dialogoOpcoes({ nova: true, aoCancelar: aoCancelar });
    else if (item.depois === "pergunta") I().dialogoOpcoes({ nova: true, pergunta: true, aoCancelar: aoCancelar });
    else if (item.depois === "dias") I().dialogoDias({ nova: true, aoCancelar: aoCancelar });
  };

  // A paleta em si. aoEscolher(item) é chamado ao clicar numa peça. Devolve { el, abrir, fechar, aberto }.
  X.criar = function (aoEscolher) {
    var pal = el("div", "bl-paleta"); pal.hidden = true;
    pal.setAttribute("role", "group"); pal.setAttribute("aria-label", "Peças prontas para acrescentar");
    X.ITENS.forEach(function (g) {
      pal.appendChild(el("p", "bl-paleta-tit", g.grupo));
      var grade = el("div", "bl-paleta-grade");
      g.itens.forEach(function (item) {
        var b = el("button", "bl-peca"); b.type = "button";
        var ic = el("span", "bl-peca-ic", item.ic); ic.setAttribute("aria-hidden", "true");
        var tx = el("span", "bl-peca-tx");
        tx.appendChild(el("strong", "", item.nome)); tx.appendChild(el("span", "", item.desc));
        b.appendChild(ic); b.appendChild(tx);
        b.addEventListener("click", function () { aoEscolher(item); });
        grade.appendChild(b);
      });
      pal.appendChild(grade);
    });
    return {
      el: pal,
      abrir: function () { pal.hidden = false; },
      fechar: function () { pal.hidden = true; },
      aberto: function () { return !pal.hidden; },
      focarPrimeira: function () { var b = pal.querySelector(".bl-peca"); if (b) b.focus({ preventScroll: true }); }
    };
  };

  // ---------- modo Texto: a peça entra numa linha nova, logo depois da linha do cursor ----------
  // (uma marcação de várias linhas, como um ((SE …)) quebrado em linhas, conta como uma linha só)
  function fimDaLinha(t, pos) {
    var us = P.Blocos.dividir(t), ini = 0;
    for (var k = 0; k < us.length; k++) {
      var f = ini + us[k].length;
      if (pos <= f) return f;
      ini = f + 1;
    }
    return t.length;
  }

  X.inserirNoTexto = function (item) {
    var e = I().estado(), ta = e.master;
    e.paletaTexto.fechar(); e.bPronto.setAttribute("aria-expanded", "false");
    I().limparTextarea();
    var t = ta.value, pecas = X.pecas(item), vazio = !t.trim();
    var fim = vazio ? 0 : fimDaLinha(t, ta.selectionEnd);
    var iniLinha = t.lastIndexOf("\n", ta.selectionEnd - 1) + 1;
    if (!vazio && !t.slice(iniLinha, fim).trim() && !item.depois) {      // linha do cursor vazia: a peça entra nela mesma
      I().substituir(iniLinha, fim, pecas.join("\n"));
      if (item.sel != null) ta.setSelectionRange(iniLinha + (Array.isArray(item.sel) ? item.sel[0] : item.sel), iniLinha + (Array.isArray(item.sel) ? item.sel[1] : item.sel));
      I().atualizarBotoes();
      return;
    }
    var ins = (vazio ? "" : "\n") + pecas.join("\n"), ini = vazio ? 0 : fim + 1;
    I().substituir(vazio ? 0 : fim, vazio ? t.length : fim, ins);
    if (item.depois) {
      X.abrirDialogo(item, function () {          // cancelou: tira a linha vazia que foi criada
        if (!vazio && ta.value.length === t.length + 1 && ta.value.charAt(fim) === "\n") I().substituir(fim, fim + 1, "");
      });
      return;
    }
    if (item.sel != null) {
      var a = ini + (Array.isArray(item.sel) ? item.sel[0] : item.sel), b = ini + (Array.isArray(item.sel) ? item.sel[1] : item.sel);
      ta.setSelectionRange(a, b);
    }
    I().atualizarBotoes();
    ta.scrollIntoView({ block: "nearest" });
  };
})();
