/*
 * Ajuda — aba "Sobre" (a janela está em ajuda.js). A versão vem das constantes de app/versao.js (window.APP_VERSAO, window.APP_DATA):
 * é o único lugar onde ela é escrita. O botão dos Termos de Uso abre a tela de termos que já existe (o link #link-termos do rodapé).
 */
(function () {
  "use strict";
  var P = window.Personalizados, A = window.Ajuda;

  A.registrar("sobre", function (p, ctx) {
    var topo = P.el("div", "ajuda-sobre-topo");
    topo.appendChild(P.el("h3", "", "Modelos de Evolução"));
    topo.appendChild(P.el("p", "ajuda-versao", "Versão " + (window.APP_VERSAO || "?") + " · " + (window.APP_DATA || "")));
    p.appendChild(topo);
    A.p(p, "Ajuda os médicos a escrever evoluções e altas: você preenche os campos, escolhe as opções e copia o texto pronto para o prontuário.");

    // Autor antes das novidades; contato numa linha só (e-mail · perfil) para não alongar a rolagem. Sem nome de rede social (regra do app).
    A.titulo(p, "Autor");
    A.p(p, "Criado por **Raphael Bastos Palitot de Brito** · Contato: **brito_raphael@hotmail.com** · **@raphael.palitot**");

    // Histórico (app/versao.js): a primeira é a atual, aberta; as anteriores ficam recolhidas, cada uma com o que trouxe
    var hist = window.APP_HISTORICO || [];
    if (hist.length) {
      A.titulo(p, "O que há de novo nesta versão (" + hist[0].versao + ")");
      A.lista(p, hist[0].novidades);
    }
    if (hist.length > 1) {
      A.titulo(p, "Versões anteriores");
      hist.slice(1).forEach(function (v) {
        var d = P.el("details", "ajuda-qa");
        d.appendChild(P.el("summary", "", "Versão " + v.versao + " · " + v.data));
        A.lista(d, v.novidades);
        p.appendChild(d);
      });
    }

    A.titulo(p, "Termos de Uso");
    if (ctx.criador) A.p(p, "Os Termos de Uso estão no rodapé da tela principal (link “Termos de Uso”).");
    else {
      var v = window.TERMOS ? window.TERMOS.versao : "";
      var b = P.el("button", "ajuda-termos", "Ler os Termos de Uso" + (v ? " (versão " + v + ")" : "")); b.type = "button";
      b.addEventListener("click", function () {
        ctx.fechar();
        var link = document.getElementById("link-termos");
        if (link) link.click();
      });
      p.appendChild(b);
    }

    var aviso = P.el("p", "ajuda-aviso");
    aviso.appendChild(A.rico(P.el("span"), "**Ferramenta de apoio à escrita.** Não armazena dados de pacientes. Confira sempre o texto antes de colar no prontuário: o que é registrado é de responsabilidade do profissional que assina."));
    p.appendChild(aviso);
  });
})();
