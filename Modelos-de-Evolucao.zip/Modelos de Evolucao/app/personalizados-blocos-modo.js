/*
 * Modo "Blocos" do criador — trocar de modo (Blocos | Texto), o seletor, a área da lista, ao abrir/fechar e o que o diálogo de opções usa
 * (paraMestre, deslocamento) (parte de personalizados-blocos.js; carregue por último).
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var B = P.Blocos = P.Blocos || {};
  var I = function () { return P._ed; };            // peças do criador (personalizados-editor.js)
  var st = null; B.aoMudarEstado(function (x) { st = x; });
  var Sec = P.BlocosSecoes, dividir = P.BlocosBase.dividir;
  var ehTitulo = Sec.ehTitulo, fimSecao = Sec.fimSecao;
  var desativar = function () { return B._f.desativar(); }, ativar = function (i, c) { return B._f.ativar(i, c); }, guardar = function () { return B._f.guardar(); },
      desenhar = function (f, c) { return B._f.desenhar(f, c); }, refazer = function (t, m) { return B._f.refazer(t, m); }, desfazer = function () { return B._f.desfazer(); },
      adicionar = function (item) { return B._f.adicionar(item); }, fecharPaleta = function () { return B._f.fecharPaleta(); },
      moverTrecho = function (ini, n, p, f) { return B._f.moverTrecho(ini, n, p, f); },
      destinoSolta = function (e) { return B._f.destinoSolta(e); }, limparSolta = function () { return B._f.limparSolta(); };

  function el(tag, classe, texto) { return I().el(tag, classe, texto); }
  function ed() { return I().estado(); }

  // ---------- trocar de modo ----------
  function aplicarModo(modo, guardarPref) {
    var e = ed();
    if (modo === "blocos") {
      e.modo = "blocos";
      refazer(e.master.value, false); st.hist = []; st.ultimo = null;
      e.master.hidden = true; st.area.hidden = false;
      if (e.visual) e.visual.hidden = true;
      if (e.paletaTexto) e.paletaTexto.fechar();
      desenhar();
    } else {
      desativar();
      e.modo = "texto"; e.ta = e.master;
      // modo Texto: escreve-se no editor visual; ed.master fica invisível, mas focável (os botões do criador trabalham nele)
      e.master.hidden = !e.visual; e.master.classList.toggle("wy-oculto", !!e.visual); st.area.hidden = true;
      if (e.visual) { e.visual.hidden = false; P.Visual.recarregar(); }
      fecharPaleta();
    }
    e.bPronto.hidden = modo === "blocos";               // "＋ Inserir pronto" só existe no modo Texto
    if (modo === "blocos") e.bPronto.setAttribute("aria-expanded", "false");
    I().definirPassos(modo);
    st.bBlocos.setAttribute("aria-pressed", modo === "blocos" ? "true" : "false");
    st.bTexto.setAttribute("aria-pressed", modo === "texto" ? "true" : "false");
    if (guardarPref) P.salvarPref({ modoEditor: modo });
    I().atualizarBotoes();
  }
  B.definirModo = function (modo) { aplicarModo(modo, false); };

  // Seletor "Blocos | Texto" (fica acima da barra de botões)
  B.seletor = function () {
    B.definirEstado({ unidades: [""], fecha: [false], hist: [], ativo: -1, cta: null, ultimo: null, arrastando: null, arrN: 1, erros: null });
    var caixa = el("div", "ep-modo");
    caixa.appendChild(el("span", "ep-modo-rot", "Como prefere montar?"));
    var bb = I().botao("ep-modo-bt", "▦", "Com blocos", function () { if (ed().modo !== "blocos") aplicarModo("blocos", true); });
    var bt = I().botao("ep-modo-bt", "✎", "Escrevendo o texto", function () { if (ed().modo !== "texto") aplicarModo("texto", true); });
    bb.title = "Cada linha vira um bloco: clique para escrever, arraste para mudar a ordem e adicione blocos prontos";
    bt.title = "Tudo numa caixa de texto só, para quem prefere escrever ou colar";
    caixa.appendChild(bb); caixa.appendChild(bt);
    st.bBlocos = bb; st.bTexto = bt;
    return caixa;
  };

  // Área dos blocos (fica no lugar da caixa de texto)
  B.area = function () {
    var area = el("div", "bl-area"); area.hidden = true;
    area.appendChild(el("p", "bl-ajuda", "Clique num bloco para escrever · Enter cria outro bloco · arraste ⋮⋮ (ou ↑ ↓) para mudar a ordem · num título, as setas movem a seção inteira (Shift: só o título)."));
    var lista = el("div", "bl-lista");
    lista.addEventListener("click", function (e) { if (e.target === lista) desativar(); });
    var ehBloco = function (e) { return st.arrastando != null && e.dataTransfer && Array.prototype.indexOf.call(e.dataTransfer.types || [], "application/x-bloco") !== -1; };
    lista.addEventListener("dragover", function (e) {
      if (!ehBloco(e)) return;
      e.preventDefault();
      limparSolta();
      var d = destinoSolta(e); if (d) d.cartao.classList.add(d.depois ? "bl-solta-depois" : "bl-solta-antes");
    });
    lista.addEventListener("dragleave", function (e) { if (!lista.contains(e.relatedTarget)) limparSolta(); });
    lista.addEventListener("drop", function (e) {
      if (!ehBloco(e)) return;
      e.preventDefault();
      var d = destinoSolta(e), de = st.arrastando, n = st.arrN; limparSolta(); st.arrastando = null;
      if (!d) return;
      var idx = +d.cartao.dataset.i, p = idx + (d.depois ? 1 : 0);
      if (d.depois && ehTitulo(idx) && st.fecha[idx]) p = fimSecao(idx);      // depois de uma seção escondida = depois dos blocos dela
      moverTrecho(de, n, p, "");
    });
    var rodape = el("div", "bl-rodape");
    var bAdd = I().botao("bl-add", "＋", "Adicionar bloco", function () {
      var abrir = !st.paleta.aberto();
      st.ultimo = st.ativo >= 0 ? st.ativo : st.ultimo;
      if (abrir) st.paleta.abrir(); else st.paleta.fechar();
      bAdd.setAttribute("aria-expanded", abrir ? "true" : "false");
      if (abrir) bAdd.scrollIntoView({ block: "start" });
    });
    bAdd.setAttribute("aria-expanded", "false");
    bAdd.addEventListener("mousedown", function (e) { e.preventDefault(); });        // não fecha o bloco aberto antes de saber onde inserir
    var bDesf = I().botao("bl-desf", "↶", "Desfazer", desfazer);
    bDesf.title = "Desfaz a última mudança nos blocos (adicionar, mover, apagar ou o que foi escrito num bloco)";
    rodape.appendChild(bAdd); rodape.appendChild(bDesf);
    var paleta = P.Prontos.criar(adicionar);
    area.appendChild(lista); area.appendChild(rodape); area.appendChild(paleta.el);
    st.area = area; st.lista = lista; st.paleta = paleta; st.bAdd = bAdd;
    return area;
  };

  // Ao abrir o criador: último modo usado (Blocos na primeira vez)
  B.iniciar = function () {
    var pref = P.lerPref();
    aplicarModo(pref && pref.modoEditor === "texto" ? "texto" : "blocos", false);
  };
  // O texto inteiro mudou por fora (ex.: ponto de partida): refaz os blocos
  B.recarregar = function () {
    if (!st || ed().modo !== "blocos") return;
    refazer(ed().master.value, false); st.hist = []; st.ultimo = null;
    desenhar();
  };
  B.fechar = function () { B.definirEstado(null); };

  // O diálogo de opções precisa do texto inteiro (os ((SE ...)) de uma escolha podem estar no bloco de baixo):
  // fecha o bloco, põe a seleção no texto inteiro e devolve voltar(), que refaz os blocos e reabre onde ficou o cursor.
  B.paraMestre = function () {
    var e = ed();
    if (!st || e.modo !== "blocos" || st.ativo < 0 || !st.cta) return null;
    var i = st.ativo, ta = st.cta, off = 0;
    for (var k = 0; k < i; k++) off += st.unidades[k].length + 1;
    var a = off + ta.selectionStart, b = off + ta.selectionEnd;
    guardar(); desativar();
    e.ta = e.master; e.master.setSelectionRange(a, b);
    return { voltar: function () {
      if (!st || ed() !== e) return;
      var p = e.master.selectionEnd, acc = 0;
      refazer(e.master.value, true); desenhar();
      for (var k2 = 0; k2 < st.unidades.length; k2++) {
        var L = st.unidades[k2].length;
        if (p <= acc + L) { ativar(k2, p - acc); return; }
        acc += L + 1;
      }
    } };
  };
  // Posição (no texto inteiro) onde começa o bloco aberto; 0 se não há bloco aberto (modo Texto)
  B.deslocamento = function () {
    if (!st || ed().modo !== "blocos" || st.ativo < 0) return 0;
    var off = 0;
    for (var k = 0; k < st.ativo; k++) off += st.unidades[k].length + 1;
    return off;
  };
  B.dividir = dividir;        // usado pelo modo Texto (peças prontas) e nos testes
})();
