/*
 * Motor — montar a tela de um modelo (peça de motor.js; carregue antes dele, depois de motor-campos.js e motor-pendencias.js).
 * Transforma o modelo já interpretado (segmentos) nos elementos da tela: texto fixo (com títulos "#" destacados), dicas, avisos, espaços de preencher,
 * achados editáveis, caixas livres, opções/controles e blocos condicionais. Quem guarda o estado (valores) é motor.js, que entrega ao iniciar() o que
 * as peças daqui precisam: valores(), irParaPendente(), sincronizar(), mudou().
 * M.Tela = { iniciar(ctx), reiniciar(), montar(segmentos, pai) }.
 */
(function () {
  "use strict";
  var M = window.MotorPecas, Campos = M.Campos, Calculos = M.Calculos;
  var ctx = null;
  var $ = function (id) { return document.getElementById(id); };
  var valores = function () { return ctx.valores(); }, irParaPendente = function (a, b) { return ctx.irParaPendente(a, b); },
      sincronizar = function (id, origem) { return ctx.sincronizar(id, origem); }, mudou = function () { return ctx.mudou(); };
  var visivel = M.Pendencias.visivel;

  function montar(segs, pai) {
    segs.forEach(function (s) {
      var el;
      if (s.tipo === "texto_fixo") el = textoComTitulos(s.texto);
      else if (s.tipo === "dica") { el = document.createElement("span"); el.className = "dica"; el.textContent = "💡 " + s.texto; }
      else if (s.tipo === "aviso") { el = document.createElement("span"); el.className = "aviso-inline"; el.textContent = "⚠ " + s.texto; }
      else if (s.tipo === "campo" || s.tipo === "auxiliar") {
        // Espaço para preencher: texto que quebra a linha junto com a frase (motor-campos.js). O auxiliar (só na tela) é um campo de uma linha.
        var hooks = {
          enter: function (e2) { irParaPendente(e2); },       // Enter pula para o próximo item sem preencher
          digitou: function (e2) { valores()[s.id] = Campos.ler(e2); sincronizar(s.id, e2); Calculos.calcular(s.id); mudou(); }
        };
        el = s.tipo === "campo" ? Campos.criar(s, valores()[s.id], hooks) : Campos.criarAuxiliar(s, valores()[s.id], hooks);
      } else if (s.tipo === "editavel") {
        // Achado pré-escrito que parece texto normal, mas pode ser editado clicando nele
        el = document.createElement("span");
        el.className = "editavel"; el.dataset.id = s.id; el.textContent = valores()[s.id];
        el.contentEditable = "plaintext-only"; el.spellcheck = false;
        el.title = "Clique para editar";
        el.addEventListener("input", function () {
          if (!el.textContent.trim() && el.innerHTML !== "") el.innerHTML = ""; // tira <br> que o navegador deixa ao apagar tudo
          if (/[\r\n]/.test(el.textContent)) { // texto colado com quebras de linha: vira uma linha só
            el.textContent = el.textContent.replace(/\s*[\r\n]+\s*/g, " ");
            var sel = window.getSelection(), r = document.createRange();
            r.selectNodeContents(el); r.collapse(false); sel.removeAllRanges(); sel.addRange(r);
          }
          valores()[s.id] = Campos.espacos(el.textContent); mudou();      // sem espaço não separável/tab no texto final
        });
        el.addEventListener("keydown", function (e) {
          if (e.key === "Enter") { e.preventDefault(); if (!e.ctrlKey && !e.altKey && !e.metaKey) irParaPendente(el); }
        });
      } else if (s.tipo === "texto") {
        el = document.createElement("textarea");
        el.className = "texto"; el.placeholder = s.rotulo; el.value = valores()[s.id]; el.dataset.id = s.id;
        el.addEventListener("input", function () { valores()[s.id] = el.value; mudou(); });
      } else if (s.tipo === "opcao" || s.tipo === "controle") {
        el = document.createElement("span");
        el.className = "opcoes" + (s.tipo === "controle" ? " controle" : "");
        if (s.rotulo) el.dataset.rotulo = s.rotulo;
        el.dataset.id = s.id;
        s.opcoes.forEach(function (op, i) {
          var b = document.createElement("button");
          b.type = "button"; b.textContent = op; b.dataset.valor = op; b.dataset.n = i + 1;
          b.addEventListener("click", function () {
            valores()[s.id] = valores()[s.id] === op ? "" : op;
            mudou();
          });
          el.appendChild(b);
        });
        // Teclado: 1, 2, 3... escolhe a opção; Enter/Espaço escolhe a que está em foco;
        // setas trocam de opção. Depois de escolher, pula para o próximo item pendente.
        el.addEventListener("keydown", function (e) {
          if (e.ctrlKey || e.altKey || e.metaKey) return; // atalhos globais (Alt+n, Ctrl+Enter) não escolhem opção
          var botoes = Array.prototype.slice.call(el.querySelectorAll("button"));
          var atualIdx = botoes.indexOf(document.activeElement), alvo = null;
          if (/^[1-9]$/.test(e.key) && botoes[+e.key - 1]) alvo = botoes[+e.key - 1];
          else if ((e.key === "Enter" || e.key === " ") && atualIdx !== -1) alvo = botoes[atualIdx];
          else if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
            e.preventDefault();
            var prox = botoes[(atualIdx + (e.key === "ArrowRight" ? 1 : botoes.length - 1)) % botoes.length];
            if (prox) prox.focus();
            return;
          } else return;
          e.preventDefault();
          valores()[s.id] = alvo.dataset.valor;
          mudou();
          // se a escolha revelou um campo (ex.: "QUEIXA-SE DE" -> queixa), vai direto para ele, esteja antes ou depois
          var revelado = Array.prototype.find.call(
            $("editor").querySelectorAll('.bloco[data-chave="' + s.id + '"]:not(.oculto) .campo'),
            function (c) { return visivel(c) && !Campos.ler(c).trim(); });
          if (revelado) revelado.focus(); else irParaPendente(el);
        });
      } else if (s.tipo === "mais") {
        el = montarMais(s);
      } else if (s.tipo === "bloco") {
        el = document.createElement("span");
        el.className = "bloco"; el.dataset.chave = s.chave; el.dataset.valor = s.valor;
        montar(s.filhos, el);
      }
      pai.appendChild(el);
    });
  }

  // {mais#chave:Rótulo} (motor-repetir.js): botão "＋ Rótulo" e, acima dele, as linhas acrescentadas (cada uma com ✕). Só mexe na tela e nos segmentos;
  // o texto final vem de gerar() (que lê s.copias). Nada de remontar a tela: os campos já preenchidos não são tocados.
  function montarMais(s) {
    var el = document.createElement("span"), botao = document.createElement("button");
    el.className = "mais"; el.dataset.chave = s.chave;
    botao.type = "button"; botao.className = "mais-add"; botao.textContent = "＋ " + (s.rotulo || "Adicionar linha");
    botao.title = "Acrescenta mais uma linha igual a de cima";
    var atualizarBotao = function () { botao.disabled = s.copias.length >= M.Repetir.MAX; botao.title = botao.disabled ? "Já tem o máximo de linhas" : "Acrescenta mais uma linha igual a de cima"; rotular(); };
    // Nomes para leitor de tela: "Laboratório 2: data", "Laboratório 2: resultados", "Tirar o laboratório 2" (a linha do modelo é a 1; renumera ao tirar)
    var substantivo = (s.rotulo || "Linha").replace(/^\s*adicionar\s+/i, "").toLowerCase();
    var rotular = function () {
      el.querySelectorAll(".mais-copia").forEach(function (linha, i) {
        var num = i + 2, x = linha.querySelector(".mais-x");
        linha.querySelectorAll(".campo").forEach(function (c) { c.setAttribute("aria-label", substantivo.charAt(0).toUpperCase() + substantivo.slice(1) + " " + num + ": " + (c.dataset.dica || "espaço para preencher")); });
        if (x) { x.setAttribute("aria-label", "Tirar o " + substantivo + " " + num); x.title = "Tirar esta linha"; }
      });
    };
    var desenharCopia = function (c) {
      var linha = document.createElement("span"), x = document.createElement("button");
      linha.className = "mais-copia"; linha.dataset.n = c.n;
      montar(c.filhos, linha);
      x.type = "button"; x.className = "mais-x"; x.textContent = "✕";
      x.title = "Tirar esta linha";
      x.addEventListener("click", function () {
        var seguinte = linha.nextElementSibling;
        M.Repetir.remover(s, c, valores());
        linha.remove(); atualizarBotao(); mudou();
        var alvo = seguinte && seguinte.classList.contains("mais-copia") ? seguinte.querySelector(".campo") : botao;
        (alvo || botao).focus();
      });
      linha.appendChild(x);
      linha.appendChild(document.createTextNode("\n"));
      return linha;
    };
    s.copias.forEach(function (c) { el.appendChild(desenharCopia(c)); });
    el.appendChild(botao);
    atualizarBotao();
    botao.addEventListener("click", function () {
      var c = M.Repetir.adicionar(s, M.estado().atual, valores());
      if (!c) return;
      var linha = desenharCopia(c);
      el.insertBefore(linha, botao);
      atualizarBotao(); mudou();
      var primeiro = linha.querySelector(".campo");
      if (primeiro) primeiro.focus();
    });
    return el;
  }

  // Na tela, linhas que começam com "#" (títulos de seção) ficam destacadas; o texto final não muda
  var primeiroTrecho = true; // o 1º trecho do modelo também é início de linha

  function textoComTitulos(texto) {
    var frag = document.createDocumentFragment(), inicioDoModelo = primeiroTrecho;
    primeiroTrecho = false;
    texto.split(/(\n)/).forEach(function (parte, i, partes) {
      var inicioDeLinha = i === 0 ? inicioDoModelo : partes[i - 1] === "\n";
      var m = inicioDeLinha && parte.match(/^(#[^:(\n]*:?)([\s\S]*)$/);
      if (m && m[1].replace(/[#\s]/g, "")) { // ignora um "#" sozinho (ex.: "#{hoje}")
        var b = document.createElement("span"); b.className = "titulo-secao"; b.textContent = m[1];
        frag.appendChild(b);
        if (m[2]) frag.appendChild(document.createTextNode(m[2]));
      } else if (parte) frag.appendChild(document.createTextNode(parte));
    });
    return frag;
  }

  M.Tela = { iniciar: function (c) { ctx = c; }, reiniciar: function () { primeiroTrecho = true; }, montar: montar };
})();
