/*
 * Evoluções personalizadas — tela de início do criador (só em "＋ Criar modelo" novo).
 * No lugar do corpo do criador aparecem 3 botões grandes: começar de um modelo pronto, colar uma evolução que já se usa
 * ou montar do zero com blocos; e um link menor para pedir a uma inteligência artificial.
 * O que cada botão faz (comecar, recomecar, acoes) fica no fim deste arquivo; o criador está em personalizados-editor.js. Teclado: Tab/Enter nos botões,
 * Esc volta (numa tela interna) ou fecha o criador (na tela principal).
 * Todo texto entra por textContent.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var X = P.Inicio = {};
  var el = P.el;
  var botao = function (classe, texto, aoClicar) { var b = el("button", classe, texto); b.type = "button"; b.addEventListener("click", aoClicar); return b; };

  // acoes: { classicos(): lista, classico(idx), colar(texto), blocos(), ia() }
  X.criar = function (acoes) {
    var sec = el("section", "ep-inicio");
    sec.setAttribute("aria-label", "Como começar o modelo");
    var principal = el("div", "ep-ini-vista"), listaV = el("div", "ep-ini-vista"), colarV = el("div", "ep-ini-vista");
    listaV.hidden = true; colarV.hidden = true;

    // ----- vista principal: 3 botões grandes -----
    principal.appendChild(el("h3", "ep-ini-tit", "Como você quer começar?"));
    var grade = el("div", "ep-ini-grade");
    var grande = function (icone, titulo, frase, aoClicar) {
      var b = el("button", "ep-ini-bt"); b.type = "button";
      var ic = el("span", "ep-ini-ic", icone); ic.setAttribute("aria-hidden", "true");
      b.appendChild(ic); b.appendChild(el("strong", "", titulo)); b.appendChild(el("span", "ep-ini-frase", frase));
      b.addEventListener("click", aoClicar);
      grade.appendChild(b);
      return b;
    };
    var bPronto = grande("📋", "Começar de um modelo pronto", "Escolha um dos modelos clássicos e adapte do seu jeito. O original não muda.", function () { ver(listaV); });
    var bColar = grande("📝", "Colar uma evolução que já uso", "Cole o texto de uma evolução sua e marque o que muda de paciente para paciente.", function () { ver(colarV); });
    grande("✨", "Montar do zero", "Comece com uma página em branco e vá acrescentando peças prontas e espaços para preencher.", function () { acoes.blocos(); });
    principal.appendChild(grade);
    var bIA = botao("ep-ini-link", "🤖 Pedir para uma inteligência artificial montar", function () { acoes.ia(); });
    var linhaIA = el("p", "ep-ini-ia"); linhaIA.appendChild(bIA);
    principal.appendChild(linhaIA);

    // ----- lista dos modelos clássicos -----
    var voltar1 = botao("ep-ini-volta", "← Voltar", function () { ver(principal, bPronto); });
    listaV.appendChild(voltar1);
    listaV.appendChild(el("h3", "ep-ini-tit", "Qual modelo pronto você quer adaptar?"));
    listaV.appendChild(el("p", "ep-ini-sub", "Ele é copiado para você mudar à vontade. O modelo original continua como está."));
    var cartoes = el("div", "ep-ini-cartoes");
    acoes.classicos().forEach(function (m, n) {
      var c = el("button", "ep-ini-cartao"); c.type = "button";
      c.appendChild(el("strong", "", m.nome)); c.appendChild(el("span", "", "Copiar e adaptar"));
      c.addEventListener("click", function () { acoes.classico(n); });
      cartoes.appendChild(c);
    });
    listaV.appendChild(cartoes);

    // ----- colar -----
    var voltar2 = botao("ep-ini-volta", "← Voltar", function () { ver(principal, bColar); });
    colarV.appendChild(voltar2);
    colarV.appendChild(el("h3", "ep-ini-tit", "Cole aqui uma evolução que você já usa"));
    colarV.appendChild(el("p", "ep-ini-sub", "Não cole dados de pacientes (nome, prontuário, CPF). Depois você marca o que muda de paciente para paciente."));
    var rot = el("label", "ep-rotulo", "Cole aqui"); rot.htmlFor = "ep-ini-cola";
    var ta = el("textarea", "ep-ini-ta"); ta.id = "ep-ini-cola"; ta.rows = 12; ta.maxLength = P.MAX_MODELO; ta.spellcheck = true; ta.lang = "pt-BR";
    ta.placeholder = "Cole aqui a evolução...";
    var msg = el("p", "dlg-erro"); msg.setAttribute("aria-live", "polite");
    var continuar = function () {
      if (!ta.value.trim()) { msg.textContent = "Cole o texto da evolução antes de continuar."; ta.focus(); return; }
      msg.textContent = "";
      acoes.colar(ta.value);
    };
    ta.addEventListener("keydown", function (e) { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); continuar(); } });
    var bCont = botao("ep-ini-continuar", "Continuar", continuar);
    colarV.appendChild(rot); colarV.appendChild(ta); colarV.appendChild(msg); colarV.appendChild(bCont);

    function ver(vista, foco) {
      [principal, listaV, colarV].forEach(function (v) { v.hidden = v !== vista; });
      msg.textContent = "";
      var alvo = foco || (vista === listaV ? cartoes.querySelector("button") : vista === colarV ? ta : null);
      if (alvo) alvo.focus();
    }
    // Esc numa tela interna volta para as 3 opções; na principal, o Esc segue para o criador (que fecha)
    sec.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && principal.hidden) {
        e.preventDefault(); e.stopPropagation();
        ver(principal, listaV.hidden ? bColar : bPronto);
      }
    });
    sec.appendChild(principal); sec.appendChild(listaV); sec.appendChild(colarV);
    sec.vista = { principal: principal, listaV: listaV, colarV: colarV, primeiro: bPronto, ta: ta, ver: ver };
    return sec;
  };

  // Volta às 3 opções (ao "Recomeçar")
  X.mostrar = function (sec) {
    var v = sec.vista;
    v.ta.value = "";
    [v.principal, v.listaV, v.colarV].forEach(function (x) { x.hidden = x !== v.principal; });
    v.primeiro.focus();
  };
  X.focar = function (sec) { sec.vista.primeiro.focus(); };

  // ---------- ponto de partida: o que cada botão da tela de início faz ----------
  var PE = P._ed, dica = PE.dica, aoMudar = PE.aoMudar, definirPassos = PE.definirPassos;

  // ---------- ponto de partida (tela de início do criador) ----------
  function textoAvisoCalculo(restantes) {
    var tipos = [];
    if (restantes.some(function (c) { return c.tipo === "ig"; })) tipos.push("idade gestacional");
    if (restantes.some(function (c) { return c.tipo === "dias"; })) tipos.push("dias");
    return "Atenção: neste modelo clássico, os cálculos automáticos (" + tipos.join(", ") + ") não acompanham a cópia. Esses números serão digitados à mão.";
  }

  // Sai da tela de início e põe o texto no criador.
  // op: { texto, modo ("texto" | "blocos"; vazio = o último usado), nome (nome sugerido), nomeFixo (nome que veio de um rascunho),
  //       calc (cálculos de um clássico que não acompanham a cópia), dica }
  function comecar(op) {
    var ed = PE.estado();
    ed.fase = "edicao";
    ed.inicio.hidden = true; ed.corpo.hidden = false; ed.passos.hidden = false;
    if (ed.recomecar) ed.recomecar.hidden = false;
    ed.bSalvar.disabled = false; ed.bSalvar.title = "";
    ed.master.value = op.texto || ""; ed.simul = {};
    if (op.nomeFixo != null) ed.nome.value = op.nomeFixo;
    else if (op.nome != null) {
      if (!ed.nome.value.trim() || ed.nome.value === ed.nomeAuto) ed.nome.value = op.nome;
      ed.nomeAuto = op.nome;
    }
    var restantes = op.calc || [], avisos = [];
    if (restantes.length) avisos.push(textoAvisoCalculo(restantes));
    if (op.semMais) avisos.push("Atenção: o botão “＋ Adicionar laboratório” do modelo pronto não acompanha a cópia (só os modelos prontos têm essa função, por enquanto).");
    ed.calc.hidden = !avisos.length;
    if (avisos.length) ed.calc.textContent = avisos.join(" ");
    ed.master.setSelectionRange(0, 0); ed.master.scrollTop = 0;
    var pref = P.lerPref(), modo = op.modo || (pref && pref.modoEditor === "texto" ? "texto" : "blocos");
    if (P.Blocos) P.Blocos.definirModo(modo); else definirPassos("texto");
    aoMudar();
    if (op.dica) dica(op.dica);
  }
  function focarCorpo() {
    var ed = PE.estado();
    if (ed.modo === "texto" && P.Visual && ed.visual) P.Visual.focar(0);
    else if (!ed.master.hidden) ed.master.focus();
    else if (P.Blocos) P.Blocos.focarInicio();
  }

  // "↺ Recomeçar": volta à tela de início (pergunta antes se já há texto)
  function recomecar() {
    var ed = PE.estado();
    var ir = function () {
      ed.master.value = ""; ed.simul = {}; ed.calc.hidden = true;
      if (ed.nome.value === ed.nomeAuto) ed.nome.value = "";
      ed.nomeAuto = "";
      if (P.Blocos) P.Blocos.recarregar();
      if (P.Visual && ed.modo === "texto") P.Visual.recarregar();
      ed.fase = "inicio"; ed.inicio.hidden = false; ed.corpo.hidden = true; ed.passos.hidden = true; ed.recomecar.hidden = true;
      ed.bSalvar.disabled = true; ed.bSalvar.title = "Escolha primeiro como começar";
      ed.problemas.hidden = true;
      aoMudar();
      P.Inicio.mostrar(ed.inicio);
    };
    if (ed.master.value.trim()) {
      P.Motor.perguntar("Recomeçar apaga o que você escreveu nesta tela. Continuar?", "Sim, recomeçar", "Manter o meu texto", true)
        .then(function (sim) { if (sim) ir(); });
    } else ir();
  }

  // O que cada botão da tela de início faz (a tela em si está em personalizados-inicio.js)
  var partida = {
    classicos: function () { return P.classicos; },
    classico: function (idx) {            // descompila como o antigo "Começar com": o original não muda
      var m = P.classicos[idx], d = P.descompilarModelo(m.texto.replace(/^\n/, ""), m.calculos);
      comecar({ texto: d.texto.replace(/\s+$/, ""), nome: m.nome + " (meu)", calc: d.restantes, semMais: d.semMais });
      focarCorpo();
    },
    colar: function (bruto) {
      var t = P.limpar(P.limparColado(bruto)).replace(/^(?:[ \t]*\n)+/, "").replace(/\s+$/, ""), cortou = t.length > P.MAX_MODELO;
      if (cortou) t = t.slice(0, P.MAX_MODELO);
      var muitas = t.split("\n").filter(function (l) { return l.trim(); }).length >= 8;
      comecar({ texto: t, modo: "texto", dica: cortou ? "O texto colado é grande demais: só coube parte dele (máximo " + P.MAX_MODELO + " caracteres)."
        : muitas ? "Dica: no modo Blocos você pode reorganizar as linhas." : "" });
      focarCorpo();
    },
    blocos: function () { comecar({ texto: "", modo: "blocos" }); P.Blocos.abrirPaleta(); },
    ia: function () {
      var ed = PE.estado();
      comecar({ texto: "", modo: "texto" });
      ed.ia.open = true; ed.ia.scrollIntoView({ block: "start" });
      var cp = ed.ia.querySelector(".ep-ia-copiar"); if (cp) cp.focus({ preventScroll: true });
    }
  };

  X.acoes = partida;
  PE.comecar = comecar; PE.focarCorpo = focarCorpo; PE.recomecar = recomecar;
})();
