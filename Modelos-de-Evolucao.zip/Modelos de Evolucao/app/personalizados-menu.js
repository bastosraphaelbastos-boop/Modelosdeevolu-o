/*
 * Evoluções personalizadas — menu do BOTÃO DIREITO (lista de ações de um modelo ou de uma pasta).
 * P.MenuContexto.abrir(x, y, itens, origem): itens = [{ icone, texto, titulo?, perigo?, desativado?, separar?, aoClicar }]
 *   ou { nota: "texto" } (linha de explicação no fim, sem clique).
 * Teclado: tecla Menu ou Shift+F10 abrem (quem chama liga isso); ↑ ↓ andam, Enter escolhe, Esc fecha e devolve o foco.
 * Fecha ao clicar fora, rolar a página, trocar de janela ou redimensionar. Textos entram por textContent.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var C = P.MenuContexto = {};
  var aberto = null;       // { el, origem }

  function fechar(devolverFoco) {
    if (!aberto) return;
    var a = aberto; aberto = null;
    a.el.remove();
    document.removeEventListener("mousedown", foraClique, true);
    window.removeEventListener("blur", fecharSemFoco);
    window.removeEventListener("resize", fecharSemFoco);
    window.removeEventListener("scroll", fecharSemFoco, true);
    if (devolverFoco && a.origem && a.origem.isConnected) a.origem.focus({ preventScroll: true });
  }
  var fecharSemFoco = function () { fechar(false); };
  function foraClique(e) { if (aberto && !aberto.el.contains(e.target)) fechar(false); }
  C.fechar = fechar;

  C.abrir = function (x, y, itens, origem) {
    fechar(false);
    var menu = document.createElement("div");
    menu.className = "menu-contexto"; menu.setAttribute("role", "menu");
    var bts = [];
    itens.forEach(function (it) {
      if (it.nota) { menu.appendChild(Object.assign(document.createElement("div"), { className: "mc-sep" })); menu.appendChild(Object.assign(document.createElement("p"), { className: "mc-nota", textContent: it.nota })); return; }
      var b = document.createElement("button");
      b.type = "button"; b.className = "mc-item" + (it.perigo ? " perigo" : ""); b.setAttribute("role", "menuitem"); b.tabIndex = -1;
      if (it.titulo) b.title = it.titulo;
      if (it.desativado) { b.disabled = true; b.setAttribute("aria-disabled", "true"); }
      var ic = document.createElement("span"); ic.className = "mc-ic"; ic.textContent = it.icone || ""; ic.setAttribute("aria-hidden", "true");
      var tx = document.createElement("span"); tx.className = "mc-tx"; tx.textContent = it.texto;
      b.appendChild(ic); b.appendChild(tx);
      b.addEventListener("click", function () { fechar(false); it.aoClicar(); });
      if ((it.perigo || it.separar) && bts.length) menu.appendChild(Object.assign(document.createElement("div"), { className: "mc-sep" }));
      menu.appendChild(b); bts.push(b);
    });
    bts = bts.filter(function (b) { return !b.disabled; });      // o teclado só anda pelos que funcionam
    if (!bts.length) { menu.remove(); return; }
    menu.addEventListener("keydown", function (e) {
      var p = bts.indexOf(document.activeElement);
      if (e.key === "ArrowDown") { e.preventDefault(); bts[(p + 1) % bts.length].focus(); }
      else if (e.key === "ArrowUp") { e.preventDefault(); bts[(p - 1 + bts.length) % bts.length].focus(); }
      else if (e.key === "Home") { e.preventDefault(); bts[0].focus(); }
      else if (e.key === "End") { e.preventDefault(); bts[bts.length - 1].focus(); }
      else if (e.key === "Escape" || e.key === "Tab") { e.preventDefault(); e.stopPropagation(); fechar(true); }
    });
    menu.addEventListener("contextmenu", function (e) { e.preventDefault(); });
    document.body.appendChild(menu);
    // Posição: no ponto do clique, sem sair da janela
    var r = menu.getBoundingClientRect(), vw = document.documentElement.clientWidth, vh = document.documentElement.clientHeight;
    menu.style.left = Math.max(4, Math.min(x, vw - r.width - 4)) + "px";
    menu.style.top = Math.max(4, Math.min(y, vh - r.height - 4)) + "px";
    aberto = { el: menu, origem: origem };
    document.addEventListener("mousedown", foraClique, true);
    window.addEventListener("blur", fecharSemFoco);
    window.addEventListener("resize", fecharSemFoco);
    window.addEventListener("scroll", fecharSemFoco, true);
    bts[0].focus({ preventScroll: true });
  };

  // Liga o menu a um elemento: botão direito sobre "area" e tecla Menu / Shift+F10 em "foco"
  C.ligar = function (area, foco, itensFn) {
    area.addEventListener("contextmenu", function (e) { e.preventDefault(); C.abrir(e.clientX, e.clientY, itensFn(), foco); });
    foco.addEventListener("keydown", function (e) {
      if (e.key === "ContextMenu" || (e.key === "F10" && e.shiftKey)) {
        e.preventDefault();
        var r = foco.getBoundingClientRect();
        C.abrir(r.left + 12, r.bottom - 4, itensFn(), foco);
      }
    });
  };
})();
