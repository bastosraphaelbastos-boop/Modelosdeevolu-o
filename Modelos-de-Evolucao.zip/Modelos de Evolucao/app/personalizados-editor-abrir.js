/*
 * Evoluções personalizadas — o criador: abrir, fechar e salvar (parte de personalizados-editor.js; carregue logo depois dele).
 * P.abrirEditor monta a tela cheia do criador (topo, barra de botões, corpo, rodapé, atalhos) e guarda o estado em `ed`.
 * O estado vive nos dois arquivos: aqui `ed` é uma cópia do de personalizados-editor.js, e estadoNovo() mantém as duas iguais
 * (é a ÚNICA forma de abrir/fechar o estado). As funções do outro arquivo vêm de P._ed (PE).
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var PE = P._ed;
  var el = PE.el, botao = PE.botao, dica = PE.dica, substituir = PE.substituir, atualizarBotoes = PE.atualizarBotoes, agendar = PE.agendar,
      aoMudar = PE.aoMudar, definirPassos = PE.definirPassos, sujo = PE.sujo, semAlvo = PE.semAlvo;
  var ed = null;   // estado do criador aberto (null = fechado)
  function estadoNovo(x) { ed = x; PE.definirEstado(x); return x; }

  function fechar() {
    if (!ed) return;
    PE.cancelarAgenda(); clearTimeout(ed.tDica);
    document.removeEventListener("keydown", ed.teclaEsc);
    if (P.Rascunho) P.Rascunho.aoFechar(sujo(), ed.rec);      // salvou ou saiu de propósito: o rascunho some
    if (P.Blocos) P.Blocos.fechar();
    if (P.Visual) P.Visual.fechar();
    var voltar = ed.anterior;
    ed.raiz.remove(); P.travarFundo(false); estadoNovo(null);
    if (P.renderMenu && P.Rascunho) P.renderMenu();            // o aviso de "modelo não terminado" do painel acompanha o rascunho
    if (voltar && voltar.isConnected && voltar.focus) voltar.focus({ preventScroll: true });
  }

  function pedirFechar() {
    if (!sujo()) { fechar(); return; }
    P.Motor.perguntar("Você fez mudanças que ainda não foram salvas. Sair mesmo assim?", "Sair sem salvar", "Continuar editando")
      .then(function (sim) { if (sim) fechar(); else if (ed) ed.ta.focus(); });
  }

  function salvar() {
    if (ed.fase === "inicio") return;
    ed.tentou = true;
    var v = PE.atualizarProblemas();
    if (v.nomeErro) { ed.nome.focus(); return; }
    if (v.erros.length) { ed.problemas.scrollIntoView({ block: "nearest" }); return; }
    var nome = P.nomeLivre(v.nome, P.nomesUsados(ed.rec && ed.rec.id)), texto = P.normTexto(ed.master.value), agora = Date.now(), rec = ed.rec;
    if (rec) {       // outra janela pode ter trocado ou apagado o modelo enquanto esta estava aberta
      var naLista = P.lista.filter(function (r) { return r.id === rec.id; })[0];
      if (naLista) rec = naLista; else { delete P.apagados[rec.id]; P.lista.push(rec); }
      rec.nome = nome; rec.texto = texto; rec.alterado = agora;
    }
    else {
      rec = { id: P.novoId(), nome: nome, texto: texto, criado: agora, alterado: agora };
      rec.origem = rec.id;      // origem = o próprio id: quem receber este modelo o reconhece quando ele for enviado de novo (personalizados-recebidos.js)
      if (ed.pasta && P.pastaPorId(ed.pasta)) rec.pasta = ed.pasta;      // criado "de dentro" de uma pasta: nasce nela
      P.lista.push(rec);
    }
    var renomeado = nome !== v.nome;
    fechar();
    var gravou = P.gravar();
    P.copiaSeguranca();      // ainda dentro do clique em "Salvar": o download é permitido
    P.mostrarStatus(!gravou ? "Este computador não deixou guardar. O modelo vale só até fechar. A cópia de segurança foi salva em arquivo."
      : renomeado ? "Já existia um modelo com esse nome. Este ficou como “" + nome + "”. Uma cópia de segurança foi guardada no computador."
      : "✓ Modelo salvo. Uma cópia de segurança foi guardada no computador.");
    if (rec.pasta) P.lembrarPasta(rec.pasta, true);      // a pasta do modelo novo aparece aberta
    P.aposGravar(rec, true);
  }

  function exigirBloco(f) {
    return function () { if (semAlvo()) { dica("Primeiro clique num bloco para escrever nele."); return; } f(); };
  }

  // opcoes: {} novo | {rec} editar | {nome, texto} texto ainda sem nome (veio de uma importação) | {rec|null, rascunho} continuar um rascunho
  //   | {pasta: id} modelo novo criado de dentro de uma pasta (o rascunho também guarda a pasta)
  P.abrirEditor = function (opcoes) {
    if (ed) return;
    opcoes = opcoes || {};
    var rec = opcoes.rec || null, ehNovo = !rec;
    var comInicio = ehNovo && !opcoes.texto && !opcoes.rascunho;      // só o "＋ Criar modelo" novo passa pela tela de início
    var raiz = el("div", "modal-pers editor-pers");
    raiz.setAttribute("role", "dialog"); raiz.setAttribute("aria-modal", "true"); raiz.setAttribute("aria-labelledby", "ep-titulo");
    ed = estadoNovo({ raiz: raiz, rec: rec, anterior: document.activeElement, tentou: false, nomeAuto: "", precisaSel: [], simul: {}, fase: comInicio ? "inicio" : "edicao" });
    var idPasta = ehNovo ? opcoes.pasta || (opcoes.rascunho && opcoes.rascunho.pasta) || "" : "";
    ed.pasta = P.pastaPorId(idPasta) ? idPasta : "";      // pasta onde o modelo NOVO nasce ("" = Sem pasta)

    // topo: nome (e, no modelo novo, o link para recomeçar)
    var topo = el("div", "ep-topo");
    var h = el("h2", "", rec ? "Editar modelo" : "Criar modelo"); h.id = "ep-titulo";
    var cabTopo = el("div", "ep-topo-cab"), bAjuda = botao("ep-ajuda", "", "❓ Ajuda", function () { if (window.Ajuda) window.Ajuda.abrir("criar"); });
    bAjuda.title = "Abrir a ajuda, já em “Criar meu modelo” (o que você escreveu aqui não se perde)";
    cabTopo.appendChild(h); cabTopo.appendChild(bAjuda); topo.appendChild(cabTopo);
    if (ed.pasta) topo.appendChild(el("p", "ep-pasta", "📁 Este modelo vai ficar na pasta “" + P.pastaPorId(ed.pasta).nome + "”."));
    var linhaNome = el("div", "ep-linha");
    var lblNome = el("label", "ep-rotulo", "Nome do modelo"); lblNome.htmlFor = "ep-nome";
    var nome = el("input", "ep-nome"); nome.id = "ep-nome"; nome.type = "text"; nome.maxLength = P.MAX_NOME; nome.placeholder = "Ex.: Evolução de alta";
    nome.value = rec ? rec.nome : (opcoes.nome || "");
    linhaNome.appendChild(lblNome); linhaNome.appendChild(nome);
    if (comInicio) {
      ed.recomecar = botao("ep-recomecar", "", "↺ Recomeçar (escolher outro ponto de partida)", PE.recomecar);
      ed.recomecar.hidden = true;
      linhaNome.appendChild(ed.recomecar);
    }
    topo.appendChild(linhaNome);
    var calc = el("p", "ep-calc", "Atenção: neste modelo clássico, os cálculos automáticos (idade gestacional) não acompanham a cópia. Esses números serão digitados à mão."); calc.hidden = true;
    topo.appendChild(calc);
    var passos = el("ol", "ep-passos"); ed.passos = passos; topo.appendChild(passos);
    definirPassos("texto");
    passos.hidden = comInicio;

    // corpo: esquerda (texto) e direita (prévia)
    var corpo = el("div", "ep-corpo"), esq = el("section", "ep-esq"), dir = el("section", "ep-dir");
    var barra = el("div", "ep-barra"); barra.setAttribute("role", "toolbar"); barra.setAttribute("aria-label", "Marcar o texto selecionado");
    var bEspaco = botao("ep-bt", "▭", "Espaço para preencher", exigirBloco(PE.acaoEspaco));
    var bOpcoes = botao("ep-bt", "◉", "Escolha entre opções", exigirBloco(function () { PE.dialogoOpcoes(); }));
    var bCorrig = botao("ep-bt", "✎", "Texto que pode ser corrigido", exigirBloco(PE.acaoCorrigivel));
    var bLembrete = botao("ep-bt", "💡", "Lembrete (só na tela)", exigirBloco(PE.acaoLembrete));
    var bTitulo = botao("ep-bt", "T", "Título", exigirBloco(PE.acaoTitulo));
    var bHoje = botao("ep-bt", "📅", "Data de hoje", exigirBloco(PE.acaoHoje));
    var bDias = botao("ep-bt", "🔢", "Contar dias", exigirBloco(function () { PE.dialogoDias(); }));
    var bDesf = botao("ep-bt sec", "↺", "Desfazer marcação", exigirBloco(PE.acaoDesfazer));
    var bPronto = botao("ep-bt", "＋", "Inserir pronto", function () {      // só no modo Texto (no Blocos há o "＋ Adicionar bloco")
      var pal = ed.paletaTexto, abrir = pal.el.hidden;
      pal.el.hidden = !abrir; bPronto.setAttribute("aria-expanded", abrir ? "true" : "false");
      if (abrir) pal.el.scrollIntoView({ block: "nearest" });
    });
    bPronto.setAttribute("aria-expanded", "false");
    // Barra compacta: uma linha de botões e uma linha de dica (os mesmos comandos também estão no botão direito e no "!")
    var bts = el("div", "ep-bts");
    [bEspaco, bOpcoes, bCorrig, bLembrete, bTitulo, bHoje, bDias, bDesf, bPronto].forEach(function (b) {
      b.addEventListener("mousedown", function (e) { e.preventDefault(); });      // a seleção do texto continua visível
      bts.appendChild(b);
    });
    barra.appendChild(bts);
    var dicaBarra = el("p", "ep-barra-dica");   // texto fixo (sem dado do usuário): pode ir como HTML
    dicaBarra.innerHTML = '<span class="ep-dica-ico" aria-hidden="true">💡</span><span><b>Como marcar:</b> selecione um trecho do texto e clique no botão do que ele vira' +
      ' <span class="ep-dica-sep">·</span> ou clique com o <b>botão direito</b> <span class="ep-dica-sep">·</span> ou digite <kbd>!</kbd> para ver todos os comandos.</span>';
    barra.appendChild(dicaBarra);
    barra.appendChild(el("p", "ep-barra-msg", "Clique num bloco para escrever nele, ou em ＋ Adicionar bloco."));   // modo Blocos sem bloco aberto (ocupa o lugar dos botões)
    ed.precisaSel = [bEspaco, bCorrig];
    ed.todosBts = [bEspaco, bOpcoes, bCorrig, bLembrete, bTitulo, bHoje, bDias, bDesf];
    ed.bOpcoes = bOpcoes; ed.bEspaco = bEspaco; ed.bPronto = bPronto; ed.barra = barra;
    bEspaco.title = "Transforma o trecho selecionado num espaço em branco para preencher. Com o cursor dentro de um espaço que já existe, muda esse espaço";
    bOpcoes.title = "O trecho selecionado vira uma das opções; você acrescenta as outras. Com o cursor dentro de uma escolha já feita, muda essa escolha";
    bCorrig.title = "O texto já vem escrito, mas o médico pode corrigir na hora";
    bLembrete.title = "O trecho selecionado vira um lembrete que aparece só na tela (não vai para o texto). Sem seleção, abre um lembrete para escrever";
    bTitulo.title = "Transforma a linha do cursor em título (clique de novo para desfazer)";
    bHoje.title = "Coloca a data de hoje onde está o cursor";
    bDias.title = "Coloca um número de dias, contado sozinho a partir de uma data que o médico digita";
    bDesf.title = "Com o cursor dentro de um trecho marcado, volta ao texto simples";
    bPronto.title = "Abre as peças prontas (título, escolha, sinais vitais, alergias...) e coloca a escolhida numa linha nova, logo depois da linha do cursor";
    var dicaEl = el("p", "ep-dica"); dicaEl.setAttribute("aria-live", "polite");
    var ta = el("textarea", "ep-texto"); ta.spellcheck = true; ta.lang = "pt-BR";
    ta.setAttribute("aria-label", "Texto do modelo"); ta.placeholder = "Cole ou escreva aqui a evolução...";
    var visual = P.Visual ? P.Visual.criar() : null;          // modo Texto: editor visual (como vai ficar); ta fica invisível
    if (visual) { visual.hidden = true; ta.tabIndex = -1; }
    var regras = PE.secaoRegras();
    var ia = PE.secaoIA(); ed.ia = ia;
    var problemas = el("div", "ep-problemas"); problemas.hidden = true; problemas.setAttribute("aria-live", "polite");
    var modoEl = P.Blocos ? P.Blocos.seletor() : null, blocosEl = P.Blocos ? P.Blocos.area() : null;
    ed.paletaTexto = P.Prontos.criar(function (item) { P.Prontos.inserirNoTexto(item); });
    if (modoEl) esq.appendChild(modoEl);
    esq.appendChild(barra); esq.appendChild(dicaEl); esq.appendChild(ed.paletaTexto.el); esq.appendChild(ta);
    if (visual) esq.appendChild(visual);
    if (blocosEl) esq.appendChild(blocosEl);
    esq.appendChild(regras); esq.appendChild(ia); esq.appendChild(problemas);

    var teste = P.Teste ? P.Teste.botao() : null;           // "▶ Testar o modelo", acima da prévia
    if (teste) dir.appendChild(teste);
    dir.appendChild(el("h3", "", "Texto final (como vai para o prontuário)"));
    var ajudaPrevia = el("p", "ep-previa-ajuda", "É este texto que o médico copia e cola. ___ = espaço ainda vazio · A / B = escolha ainda não feita."); dir.appendChild(ajudaPrevia);
    var previa = el("div", "ep-final"); previa.setAttribute("aria-live", "polite"); dir.appendChild(previa);
    corpo.appendChild(esq); corpo.appendChild(dir);
    corpo.hidden = comInicio;

    // rodapé
    var rodape = el("div", "ep-rodape");
    rodape.appendChild(el("p", "ep-lembrete", "Não escreva dados de pacientes no modelo. Ele fica salvo neste computador."));
    var acoes = el("div", "ep-acoes");
    acoes.appendChild(botao("ep-cancelar", "", "Cancelar", pedirFechar));
    ed.bSalvar = botao("ep-salvar", "", "✓ Salvar e usar", salvar);
    if (comInicio) { ed.bSalvar.disabled = true; ed.bSalvar.title = "Escolha primeiro como começar"; }
    acoes.appendChild(ed.bSalvar);
    rodape.appendChild(acoes);

    var inicio = P.Inicio.criar(P.Inicio.acoes);            // tela de início: 3 jeitos de começar
    ed.inicio = inicio; inicio.hidden = !comInicio;
    var faixa = P.Rascunho ? P.Rascunho.faixa(opcoes, function (d) {
      if (!ed.rec && d.pasta && P.pastaPorId(d.pasta)) ed.pasta = d.pasta;
      PE.comecar({ texto: d.texto, modo: d.modo, nomeFixo: d.nome }); PE.focarCorpo();
    }) : null;
    if (faixa) raiz.appendChild(faixa);
    raiz.appendChild(topo); raiz.appendChild(inicio); raiz.appendChild(corpo); raiz.appendChild(rodape);
    Object.assign(ed, { nome: nome, ta: ta, master: ta, visual: visual, modo: "texto", dica: dicaEl, previa: previa, ajudaPrevia: ajudaPrevia, problemas: problemas, calc: calc, corpo: corpo });

    ta.value = rec ? rec.texto : (opcoes.texto ? P.limpar(opcoes.texto) : "");
    ed.nome0 = rec ? nome.value : ""; ed.texto0 = rec ? ta.value : "";     // texto vindo de importação conta como "não salvo"

    ta.addEventListener("input", agendar);
    ta.addEventListener("input", function () { if (P.Visual) P.Visual.aoMudarMestre(); });     // botões e janelinhas mudaram o texto: o editor visual se redesenha
    ta.maxLength = P.MAX_MODELO;       // o navegador corta o que passar do limite; o aviso vem ao colar
    ta.addEventListener("paste", function (e) {
      var colado = (e.clipboardData && e.clipboardData.getData("text")) || "";
      var limpo = P.limparColado(colado), tam = ta.value.length - (ta.selectionEnd - ta.selectionStart);
      if (limpo !== colado.replace(/\r\n?/g, "\n")) {        // veio de uma IA com marcas de formatação: ajusta antes de colar
        e.preventDefault();
        var corte = tam + limpo.length > P.MAX_MODELO;
        if (corte) limpo = limpo.slice(0, Math.max(0, P.MAX_MODELO - tam));
        substituir(ta.selectionStart, ta.selectionEnd, limpo);
        dica(corte ? "O texto colado é grande demais: só coube parte dele (máximo " + P.MAX_MODELO + " caracteres)." : "Ajustei o texto colado da IA (tirei marcas de formatação).");
        return;
      }
      if (tam + colado.length > P.MAX_MODELO) dica("O texto colado é grande demais: só coube parte dele (máximo " + P.MAX_MODELO + " caracteres).");
    });
    nome.addEventListener("input", agendar);
    ["select", "keyup", "mouseup", "focus", "blur"].forEach(function (ev) { ta.addEventListener(ev, atualizarBotoes); });
    // Esc: fecha a paleta aberta; senão, fecha o criador (com pergunta se há mudanças). Vale mesmo com o foco fora dos campos.
    // Janelas por cima (diálogos, perguntas, teste) tratam o próprio Esc antes e o marcam como já tratado.
    ed.teclaEsc = function (e) {
      if (!ed || e.key !== "Escape" || e.defaultPrevented) return;
      if (!document.getElementById("pergunta-tela").hidden || (P.Teste && P.Teste.ativo()) || document.querySelector(".dlg-pers")) return;
      e.preventDefault(); e.stopPropagation();
      if (ed.paletaTexto && !ed.paletaTexto.el.hidden) { ed.paletaTexto.fechar(); bPronto.setAttribute("aria-expanded", "false"); bPronto.focus(); return; }
      if (P.Blocos && P.Blocos.fecharPaleta()) return;
      pedirFechar();
    };
    document.addEventListener("keydown", ed.teclaEsc);
    raiz.addEventListener("keydown", function (e) {
      if (e.key === "Tab" && !e.altKey && !e.ctrlKey) {        // Tab não sai da janela
        var foc = Array.prototype.filter.call(raiz.querySelectorAll("button, input, select, textarea, summary, [tabindex='0']"), function (x) { return !x.disabled && x.tabIndex !== -1 && x.offsetParent !== null; });
        if (!foc.length) return;
        var p = foc.indexOf(document.activeElement);
        if (e.shiftKey && p <= 0) { e.preventDefault(); foc[foc.length - 1].focus(); }
        else if (!e.shiftKey && p === foc.length - 1) { e.preventDefault(); foc[0].focus(); }
      }
    });

    P.travarFundo(true);
    document.body.appendChild(raiz);
    if (P.Blocos) P.Blocos.iniciar();       // abre no último modo usado (Blocos na primeira vez)
    aoMudar();
    if (opcoes.rascunho) {                  // "Continuar" do painel "Minhas evoluções"
      var d = opcoes.rascunho;
      PE.comecar({ texto: d.texto, modo: d.modo, nomeFixo: d.nome }); PE.focarCorpo();
    }
    else if (comInicio) P.Inicio.focar(inicio);
    else if (ta.hidden || (visual && !visual.hidden)) nome.focus();            // começa pelo nome (Tab leva ao modelo)
    else if (opcoes.texto || rec) { ta.focus(); ta.setSelectionRange(0, 0); if (!rec) nome.focus(); } else nome.focus();
  };
})();
