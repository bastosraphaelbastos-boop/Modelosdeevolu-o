/*
 * Ajuda: janela grande (diálogo modal) com abas "Como usar", "Criar meu modelo", "Algo deu errado?" e "Sobre".
 * Abre pelo botão "❓ Ajuda" do cabeçalho (#btn-ajuda) e pelo botão "❓ Ajuda" do criador de modelos (já na aba "Criar meu modelo").
 * Esc fecha, o foco fica preso na janela e volta para quem estava com ele; por cima do criador, o criador fica "desligado" (inert) e volta como estava.
 * O texto de cada aba vem dos arquivos ajuda-uso.js (Como usar e Algo deu errado?), ajuda-criar.js (Criar meu modelo) e ajuda-sobre.js (Sobre),
 * que se registram aqui com Ajuda.registrar(id, function (painel, ctx) {...}). Todo texto entra por textContent (nunca innerHTML).
 * Marcas simples nos textos: **negrito**, `código`, <<Tecla>>. Não guarda nada. Carregue depois de personalizados-editor.js.
 */
(function () {
  "use strict";
  var P = window.Personalizados;
  var ORDEM = [["uso", "Como usar"], ["criar", "Criar meu modelo"], ["erro", "Algo deu errado?"], ["sobre", "Sobre"]];
  var montadores = {}, aberta = false;
  var A = window.Ajuda = {};

  A.registrar = function (id, fn) { montadores[id] = fn; };

  // ---------- peças para montar o texto ----------
  A.rico = function (pai, texto) {
    String(texto).split(/(\*\*[^*]+\*\*|`[^`]+`|<<[^>]+>>)/).forEach(function (t) {
      if (!t) return;
      if (t.indexOf("**") === 0) pai.appendChild(P.el("strong", "", t.slice(2, -2)));
      else if (t.charAt(0) === "`") pai.appendChild(P.el("code", "", t.slice(1, -1)));
      else if (t.indexOf("<<") === 0) pai.appendChild(P.el("kbd", "", t.slice(2, -2)));
      else pai.appendChild(document.createTextNode(t));
    });
    return pai;
  };
  A.titulo = function (pai, t) { pai.appendChild(P.el("h3", "", t)); };
  A.p = function (pai, t, classe) { pai.appendChild(A.rico(P.el("p", classe || ""), t)); };
  A.lista = function (pai, itens, ordenada) {
    var l = P.el(ordenada ? "ol" : "ul");
    itens.forEach(function (i) { l.appendChild(A.rico(P.el("li"), i)); });
    pai.appendChild(l);
  };
  // Pergunta e resposta recolhíveis (<details>)
  A.pergunta = function (pai, titulo, paragrafos) {
    var d = P.el("details", "ajuda-qa"), s = P.el("summary", "", titulo);
    d.appendChild(s);
    paragrafos.forEach(function (t) { A.p(d, t); });
    pai.appendChild(d);
  };

  // ---------- a janela ----------
  // aba: "uso" | "criar" | "erro" | "sobre" (padrão: "uso")
  A.abrir = function (aba) {
    if (aberta) return;
    aberta = true;
    var anterior = document.activeElement, atual = 0, criador = !!(P.editorAberto && P.editorAberto());
    var inertes = [];       // janelas que já estavam abertas (o criador): ficam desligadas enquanto a ajuda está aberta
    Array.prototype.forEach.call(document.querySelectorAll(".modal-pers"), function (m) { if (!m.inert) { m.inert = true; inertes.push(m); } });

    var fundo = P.el("div", "modal-pers dlg-pers ajuda-pers"), caixa = P.el("div", "ajuda-caixa");
    fundo.setAttribute("role", "dialog"); fundo.setAttribute("aria-modal", "true"); fundo.setAttribute("aria-labelledby", "ajuda-titulo");
    var cab = P.el("div", "ajuda-cab"), h = P.el("h2", "", "❓ Ajuda"); h.id = "ajuda-titulo";
    var bFechar = P.el("button", "ajuda-fechar", "Fechar"); bFechar.type = "button"; bFechar.title = "Fechar a ajuda (Esc)";
    cab.appendChild(h); cab.appendChild(bFechar);
    var abas = P.el("div", "ajuda-abas"); abas.setAttribute("role", "tablist"); abas.setAttribute("aria-label", "Assuntos da ajuda");
    var ind = P.el("span", "ajuda-ind"); ind.setAttribute("aria-hidden", "true"); abas.appendChild(ind);
    var painel = P.el("div", "ajuda-painel"); painel.id = "ajuda-painel"; painel.setAttribute("role", "tabpanel"); painel.tabIndex = 0;
    var botoes = ORDEM.map(function (o, i) {
      var b = P.el("button", "", o[1]); b.type = "button"; b.id = "ajuda-aba-" + o[0];
      b.setAttribute("role", "tab"); b.setAttribute("aria-controls", "ajuda-painel");
      b.addEventListener("click", function () { escolher(i, false); });
      abas.appendChild(b); return b;
    });

    function fechar() {
      aberta = false;
      document.removeEventListener("keydown", tecla, true);
      fundo.remove();
      inertes.forEach(function (m) { m.inert = false; });
      if (!P.editorAberto()) P.travarFundo(false);      // se o criador estiver aberto, o fundo continua travado
      if (anterior && anterior.isConnected && anterior.focus) anterior.focus({ preventScroll: true });
    }
    var ctx = { criador: criador, fechar: fechar };
    function escolher(i, focar) {
      atual = i; abas.style.setProperty("--i", i);
      botoes.forEach(function (b, k) { b.setAttribute("aria-selected", k === i ? "true" : "false"); b.tabIndex = k === i ? 0 : -1; });
      painel.setAttribute("aria-labelledby", botoes[i].id);
      painel.textContent = "";
      if (montadores[ORDEM[i][0]]) montadores[ORDEM[i][0]](painel, ctx);
      painel.scrollTop = 0;
      if (focar) botoes[i].focus();
    }
    function tecla(e) {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); fechar(); return; }
      if (e.key !== "Tab" || e.ctrlKey || e.altKey) return;
      var foc = Array.prototype.filter.call(fundo.querySelectorAll("button, summary, input, select, textarea, a[href], [tabindex='0']"),
        function (x) { return !x.disabled && x.tabIndex !== -1 && x.offsetParent !== null; });
      if (!foc.length) return;
      var p = foc.indexOf(document.activeElement);
      if (e.shiftKey && p <= 0) { e.preventDefault(); foc[foc.length - 1].focus(); }
      else if (!e.shiftKey && p === foc.length - 1) { e.preventDefault(); foc[0].focus(); }
    }
    // Setas, Home e End trocam de aba (padrão das abas acessíveis)
    abas.addEventListener("keydown", function (e) {
      var n = ORDEM.length, k = e.key, i = k === "ArrowRight" ? (atual + 1) % n : k === "ArrowLeft" ? (atual + n - 1) % n : k === "Home" ? 0 : k === "End" ? n - 1 : -1;
      if (i !== -1) { e.preventDefault(); escolher(i, true); }
    });
    bFechar.addEventListener("click", fechar);
    fundo.addEventListener("mousedown", function (e) { if (e.target === fundo) fechar(); });

    caixa.appendChild(cab); caixa.appendChild(abas); caixa.appendChild(painel);
    fundo.appendChild(caixa);
    P.travarFundo(true);
    document.body.appendChild(fundo);
    document.addEventListener("keydown", tecla, true);
    var pos = ORDEM.map(function (o) { return o[0]; }).indexOf(aba || "uso");
    escolher(pos < 0 ? 0 : pos, false);
    botoes[atual].focus();
  };

  var botao = document.getElementById("btn-ajuda");
  if (botao) botao.addEventListener("click", function () { A.abrir("uso"); });
})();
