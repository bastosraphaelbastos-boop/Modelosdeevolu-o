/*
 * Pedido (texto) que o criador de modelos oferece para copiar e usar numa ferramenta de inteligência artificial de terceiros.
 * Fica num arquivo próprio para ser fácil de atualizar. Para mudar o pedido, edite só o texto entre as crases abaixo.
 * Atenção: String.raw mantém as barras invertidas como estão (\[ \] \*). Não escreva crases (`) nem ${ dentro do texto.
 * Se mudar as marcações do aplicativo (personalizados.js), confira se o pedido e o exemplo continuam corretos.
 */
window.PROMPT_IA = String.raw`Você vai transformar um texto de evolução clínica em um MODELO para o aplicativo "Modelos de Evolução". O aplicativo lê marcações simples para criar espaços de preencher e opções de clicar. Siga TODAS as regras abaixo.

REGRAS DE SEGURANÇA (obrigatórias)
1. Não invente nada. Não acrescente achados, diagnósticos, exames, medicamentos, doses, condutas ou recomendações que não estejam no meu texto. Apenas marque o que muda de paciente para paciente.
2. Não mude o sentido clínico. Mantenha as minhas palavras, abreviações e a ordem do texto, mudando só o necessário para colocar as marcações.
3. Se houver qualquer dado que identifique um paciente (nome, CPF, prontuário, leito, telefone, endereço, data de nascimento), troque por um espaço para preencher, ex.: [leito].
4. Números, datas, horários, medidas, sinais vitais e resultados de exames do meu texto viram espaços para preencher, com o valor original como exemplo na dica. Ex.: PA 120X80 → PA [ex. 120X80].
5. Nunca deixe uma opção já escolhida: o médico sempre escolhe. Só crie alternativas óbvias do mesmo item (ex.: BEG / REG / MEG; NEGA / REFERE; PRESENTE / AUSENTE).
6. Não use formatação Markdown (negrito, itálico, listas com marcadores, tabelas), nem emojis. Use hífen no início da linha só se o meu texto já usar.
7. Responda APENAS com o modelo, dentro de um único bloco de código. Se algo ficar ambíguo, escolha a forma mais simples e, depois do bloco, escreva no máximo 3 linhas com dúvidas para eu conferir.

MARCAÇÕES QUE O APLICATIVO ENTENDE
# TÍTULO → linha começando com # vira título destacado.
[dica] → espaço para preencher; dentro vai uma dica curta do que escrever. Ex.: FC [ex. 80] BPM.
[dica=VALOR] → espaço que já vem preenchido com VALOR, mas pode ser mudado.
[A / B / C] → escolha entre opções (barra com espaço dos dois lados). Ex.: [BEG / REG / MEG].
*TEXTO* → texto que já vem escrito mas pode ser corrigido na hora. Use para achados habituais e linhas de conduta. Não pode passar de uma linha.
[...dica] → caixa de texto livre e opcional (observações).
[hoje] → data de hoje.
((SE OPÇÃO: texto)) → texto que só aparece se a OPÇÃO da escolha logo antes for marcada. Pode conter espaços para preencher e *texto corrigível*. Ex.: ALERGIAS: [NEGA / REFERE]((SE REFERE: A [quais])).
((SE SEM RESPOSTA: texto)) → aparece enquanto ninguém escolheu.
[? PERGUNTA? A / B] → pergunta que aparece só na tela (a resposta não vai para o texto). Use junto com ((SE ...)) para incluir trechos inteiros.
((AVISO: texto)) → aviso na tela que some quando a pergunta é respondida; deixa ___ no texto até lá. Use dentro de ((SE SEM RESPOSTA: ...)).
((DICA: texto)) → lembrete (só na tela); nunca vai para o texto.
[@NOME: dica] → espaço com nome; espaços com o mesmo @NOME são preenchidos juntos.
((DIAS DESDE @NOME)) → número de dias contado sozinho desde a data do espaço [@NOME: dd/mm/aaaa] (o dia da data é o dia 0).
Para escrever os símbolos [ ] * sem virar marcação, use \[ \] \*.

COMO DECIDIR
- Exame físico normal ("CORADA, HIDRATADA") → *texto corrigível*; estado geral → [BEG / REG / MEG].
- Item de sim/não com detalhe → [NEGA / REFERE]((SE REFERE: [quais])).
- Decisão que muda a conduta (ex.: alta) → [? Alta hoje? NÃO / SIM] com um ((SE ...)) para cada resposta e ((SE SEM RESPOSTA: ((AVISO: responda Alta hoje?)))).
- Datas de início (internação, antibiótico) com contagem de dias → [@NOME: dd/mm/aaaa] e ((DIAS DESDE @NOME)).

EXEMPLO
Texto: "Paciente em BEG, corada, hidratada. PA 120x80, FC 80. Nega alergias. Ceftriaxona desde 27/09. Abdome flácido, indolor. Alta hoje com orientações."
Modelo:
# EVOLUÇÃO
PACIENTE EM [BEG / REG / MEG], *CORADA, HIDRATADA*.
PA [ex. 120X80] MMHG, FC [ex. 80] BPM.
ALERGIAS: [NEGA / REFERE]((SE REFERE: A [quais])).
CEFTRIAXONA DESDE [@ATB: dd/mm/aaaa] (D((DIAS DESDE @ATB))).
ABDOME *FLÁCIDO, INDOLOR*.
# CONDUTA
[? Alta hoje? NÃO / SIM]((SE SIM: *ALTA HOSPITALAR COM ORIENTAÇÕES*))((SE NÃO: [conduta]))((SE SEM RESPOSTA: ((AVISO: responda Alta hoje?))))

MEU TEXTO (sem dados de pacientes):
[cole aqui]`;
