/*
 * Categorias de modelos (interno: o usuário ainda não vê isso).
 * Hoje só existe "evolucao": é o que o app lista e preenche. A estrutura existe para receber outras categorias no futuro,
 * por exemplo "alta" (modelos de alta acessados de dentro de uma evolução), sem misturá-las com as evoluções.
 *
 * Como os modelos dizem a categoria:
 *   - clássicos (modelos/<categoria>/*.js): campo `categoria: "evolucao"` (sem o campo = "evolucao");
 *   - "Minhas evoluções": campo opcional `categoria` no registro (sem o campo = "evolucao").
 * Para criar uma categoria nova: acrescentar aqui, criar a pasta modelos/<id>/ e decidir onde ela aparece
 * (veja a skill, seção "Expansão: categorias"). Carregue este arquivo ANTES de motor.js e de personalizados-*.js.
 */
(function () {
  "use strict";
  var C = window.Categorias = {
    PADRAO: "evolucao",
    lista: [
      { id: "evolucao", nome: "Evolução", plural: "Evoluções" },
      { id: "alta", nome: "Alta", plural: "Altas" }      // modelos/alta/*.js: textos da aba "Alta" (app/alta.js); não aparecem no menu de evoluções
    ]
  };
  C.de = function (m) { return (m && typeof m.categoria === "string" && m.categoria) || C.PADRAO; };
  C.existe = function (id) { return C.lista.some(function (c) { return c.id === id; }); };
  C.modelos = function (lista, id) { return (lista || []).filter(function (m) { return C.de(m) === (id || C.PADRAO); }); };
})();
