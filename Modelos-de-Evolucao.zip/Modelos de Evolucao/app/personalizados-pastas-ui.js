/*
 * Evoluções personalizadas — pastas de "Minhas evoluções": a tela (cabeçalho de cada pasta, menu da pasta, mini-janela para dar nome)
 * e o que cada ação faz (nova, renomear, enviar, apagar, novo modelo aqui). A parte lógica está em personalizados-pastas.js.
 * Carregue depois de personalizados-ui.js. Todo nome entra na tela por textContent.
 *
 * Preparado para os clássicos no futuro: U.grupo() só recebe nome, contador e função de abrir/fechar; quem desenha as linhas é
 * quem chama (personalizados-ui.js). Para agrupar os clássicos bastaria uma lista de pastas e uma função "pasta de cada modelo".
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var U = P.PastasUI = {};
  var el = P.el;

  // ---------- mini-janela para escrever um nome ----------
  // op: { titulo, rotulo, valor, textoOk, validar(valor) -> frase de erro ou "" }. Devolve uma Promise: o texto, ou null se cancelou.
  U.pedirTexto = function (op) {
    return new Promise(function (resolver) {
      var anterior = document.activeElement;
      var fundo = el("div", "modal-pers dlg-pers"), caixa = el("div", "dlg-caixa");
      fundo.setAttribute("role", "dialog"); fundo.setAttribute("aria-modal", "true"); fundo.setAttribute("aria-labelledby", "pt-titulo");
      var h = el("h2", "", op.titulo); h.id = "pt-titulo";
      var rot = el("label", "dlg-ajuda", op.rotulo); rot.htmlFor = "pt-campo";
      var cx = el("input", "dlg-campo"); cx.id = "pt-campo"; cx.type = "text"; cx.maxLength = P.MAX_NOME_PASTA; cx.value = op.valor || "";
      var msg = el("p", "dlg-erro"); msg.setAttribute("aria-live", "polite");
      var bCanc = el("button", "dlg-cancelar", "Cancelar"), bOk = el("button", "dlg-ok", op.textoOk || "OK");
      bCanc.type = "button"; bOk.type = "button";
      var ac = el("div", "dlg-acoes"); ac.appendChild(bCanc); ac.appendChild(bOk);
      caixa.appendChild(h); caixa.appendChild(rot); caixa.appendChild(cx); caixa.appendChild(msg); caixa.appendChild(ac); fundo.appendChild(caixa);

      function fechar(valor) {
        document.removeEventListener("keydown", tecla, true);
        fundo.remove();
        if (!P.editorAberto()) P.travarFundo(false);
        if (anterior && anterior.isConnected && anterior.focus) anterior.focus({ preventScroll: true });
        resolver(valor);
      }
      function confirmar() {
        var erro = op.validar ? op.validar(cx.value) : "";
        if (erro) { msg.textContent = erro; cx.focus(); return; }
        fechar(cx.value);
      }
      function tecla(e) {
        if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); fechar(null); }
        else if (e.key === "Enter" && e.target === cx) { e.preventDefault(); e.stopPropagation(); confirmar(); }
      }
      bCanc.addEventListener("click", function () { fechar(null); });
      bOk.addEventListener("click", confirmar);
      cx.addEventListener("input", function () { msg.textContent = ""; });
      fundo.addEventListener("keydown", function (e) {            // Tab não sai da janela
        if (e.key !== "Tab") return;
        var foc = [cx, bCanc, bOk], p = foc.indexOf(document.activeElement);
        if (e.shiftKey && p <= 0) { e.preventDefault(); foc[foc.length - 1].focus(); }
        else if (!e.shiftKey && p === foc.length - 1) { e.preventDefault(); foc[0].focus(); }
      });
      P.travarFundo(true);
      document.body.appendChild(fundo);
      document.addEventListener("keydown", tecla, true);
      cx.focus(); cx.select();
    });
  };

  // ---------- cabeçalho + corpo recolhível de um grupo ----------
  // cfg: { id, nome, total, aberto, aoAlternar(aberto), aoMover(d) (Alt+↑/↓ no nome), menu: [{ icone, texto, titulo, aoClicar }] }
  // O cabeçalho pode ser arrastado para mudar a ordem das pastas (personalizados-arrastar.js)
  // Devolve { el, corpo }: quem chama põe as linhas dos modelos em .corpo
  U.grupo = function (cfg) {
    var g = el("div", "pasta-grupo" + (cfg.aberto ? "" : " fechada")); g.dataset.pid = cfg.id || "-";
    var cab = el("div", "pasta-cab");
    var tg = el("button", "pasta-toggle"); tg.type = "button";
    var seta = el("span", "pasta-seta", cfg.aberto ? "▾" : "▸"); seta.setAttribute("aria-hidden", "true");
    var nomeEl = el("span", "pasta-nome", "📁 " + cfg.nome);
    nomeEl.appendChild(el("span", "pasta-qtd", " (" + cfg.total + ")"));
    tg.appendChild(seta); tg.appendChild(nomeEl);
    tg.setAttribute("aria-expanded", cfg.aberto ? "true" : "false");
    tg.title = "Mostrar ou esconder os modelos da pasta “" + cfg.nome + "”";
    cab.appendChild(tg);
    var corpo = el("div", "pasta-corpo");
    tg.addEventListener("keydown", function (e) {
      if (e.altKey && !e.ctrlKey && (e.key === "ArrowUp" || e.key === "ArrowDown") && cfg.aoMover) { e.preventDefault(); cfg.aoMover(e.key === "ArrowUp" ? -1 : 1); }
    });
    tg.addEventListener("click", function () {
      var abre = g.classList.contains("fechada");
      g.classList.toggle("fechada", !abre); seta.textContent = abre ? "▾" : "▸"; tg.setAttribute("aria-expanded", abre ? "true" : "false");
      if (cfg.aoAlternar) cfg.aoAlternar(abre);
    });
    // Opções da pasta: menu do BOTÃO DIREITO no cabeçalho (ou tecla Menu / Shift+F10 no nome)
    P.MenuContexto.ligar(cab, tg, function () { return cfg.menu; });
    tg.title = "Mostrar ou esconder os modelos da pasta “" + cfg.nome + "”. Botão direito: opções da pasta";
    g.appendChild(cab);
    g.appendChild(corpo);
    if (P.Arrastar) P.Arrastar.pasta(g, cab);
    return { el: g, corpo: corpo };
  };

  // ---------- janela "📁 Mover": escolher a pasta do modelo (para quem não consegue arrastar) ----------
  U.escolherPasta = function (rec) {
    var anterior = document.activeElement, atual = rec.pasta && P.pastaPorId(rec.pasta) ? rec.pasta : "";
    var fundo = el("div", "modal-pers dlg-pers"), caixa = el("div", "dlg-caixa");
    fundo.setAttribute("role", "dialog"); fundo.setAttribute("aria-modal", "true"); fundo.setAttribute("aria-labelledby", "mv-titulo");
    var h = el("h2", "", "Mover “" + rec.nome + "”"); h.id = "mv-titulo";
    caixa.appendChild(h); caixa.appendChild(el("p", "dlg-ajuda", "Escolha para onde vai o modelo:"));
    var lista = el("div", "mv-lista"), bts = [];
    function fechar(id) {
      document.removeEventListener("keydown", tecla, true);
      fundo.remove(); P.travarFundo(false);
      if (id == null) { if (anterior && anterior.isConnected) anterior.focus({ preventScroll: true }); return; }
      if (id !== atual) P.moverParaPasta(rec, id);
    }
    [{ id: "", nome: "Fora das pastas" }].concat(P.pastas).forEach(function (f) {
      var b = el("button", "mv-op" + (f.id === atual ? " atual" : ""), (f.id ? "📁 " : "📄 ") + f.nome + (f.id === atual ? "  (está aqui)" : ""));
      b.type = "button"; b.addEventListener("click", function () { fechar(f.id); });
      lista.appendChild(b); bts.push(b);
    });
    var bCanc = el("button", "dlg-cancelar", "Cancelar"); bCanc.type = "button"; bCanc.addEventListener("click", function () { fechar(null); });
    var ac = el("div", "dlg-acoes"); ac.appendChild(bCanc);
    caixa.appendChild(lista); caixa.appendChild(ac); fundo.appendChild(caixa);
    function tecla(e) { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); fechar(null); } }
    fundo.addEventListener("keydown", function (e) {            // Tab não sai da janela
      if (e.key !== "Tab") return;
      var foc = bts.concat([bCanc]), p = foc.indexOf(document.activeElement);
      if (e.shiftKey && p <= 0) { e.preventDefault(); foc[foc.length - 1].focus(); }
      else if (!e.shiftKey && p === foc.length - 1) { e.preventDefault(); foc[0].focus(); }
    });
    P.travarFundo(true);
    document.body.appendChild(fundo);
    document.addEventListener("keydown", tecla, true);
    (bts.filter(function (b) { return !b.classList.contains("atual"); })[0] || bCanc).focus();
  };

  U.vazia = function () {
    return el("p", "pers-vazio pasta-vazia", "Pasta vazia. Arraste modelos para cá (ou: botão direito no modelo › Mover para pasta).");
  };

  // Linha discreta de uma pasta que tem modelos ocultos (eles aparecem pelo link "Mostrar modelos ocultos", no fim da lista)
  U.ocultos = function (n) { return el("p", "pers-vazio pasta-ocultos", n + (n === 1 ? " oculto" : " ocultos")); };

  // ---------- ações ----------
  var gravar = function () { P.salvarPastas(); P.gravar(); };
  var foco = function (sel) { var x = document.querySelector("#lista-modelos " + sel); if (x) x.focus({ preventScroll: true }); };
  var seletorPasta = function (id) { return '.pasta-grupo[data-pid="' + id + '"] .pasta-toggle'; };

  U.nova = function () {
    if (P.pastas.length >= P.MAX_PASTAS) { P.mostrarStatus("Você já tem " + P.MAX_PASTAS + " pastas, que é o máximo. Apague uma que não usa mais."); return; }
    U.pedirTexto({ titulo: "Nova pasta", rotulo: "Nome da pasta (até " + P.MAX_NOME_PASTA + " letras)", textoOk: "Criar pasta",
      validar: function (v) { return P.erroNomePasta(v); } }).then(function (v) {
      if (v == null) { foco(".nova-pasta"); return; }
      var r = P.criarPasta(v);
      if (r.erro) { P.mostrarStatus(r.erro); return; }
      gravar(); P.lembrarPasta(r.pasta.id, true);
      P.renderMenu(); foco(seletorPasta(r.pasta.id));
      P.mostrarStatus("Pasta “" + r.pasta.nome + "” criada. Para pôr modelos nela, arraste-os até a pasta (ou: botão direito no modelo › Mover para pasta).");
    });
  };

  U.renomear = function (f) {
    U.pedirTexto({ titulo: "Renomear a pasta", rotulo: "Novo nome da pasta (até " + P.MAX_NOME_PASTA + " letras)", valor: f.nome, textoOk: "Salvar nome",
      validar: function (v) { return P.erroNomePasta(v, f.id); } }).then(function (v) {
      if (v == null) { foco(seletorPasta(f.id)); return; }
      var r = P.renomearPasta(f.id, v);
      if (r.erro) { P.mostrarStatus(r.erro); return; }
      gravar(); P.renderMenu(); foco(seletorPasta(f.id));
      P.copiaSeguranca();                  // ainda dentro do clique
      P.mostrarStatus("Pasta renomeada para “" + r.pasta.nome + "”. Uma cópia de segurança foi guardada no computador.");
    });
  };

  U.apagar = function (f) {
    var n = P.modelosDaPasta(f.id).length;
    var aviso = !n ? "Ela está vazia." : n === 1 ? "O modelo dela NÃO será apagado: ele fica na lista, fora das pastas." : "Os " + n + " modelos dela NÃO serão apagados: eles ficam na lista, fora das pastas.";
    P.Motor.perguntar("Apagar a pasta “" + f.nome + "”?\n\n" + aviso + " Você pode criar a pasta de novo quando quiser.", "Sim, apagar a pasta", "Cancelar", true).then(function (sim) {
      if (!sim) { foco(seletorPasta(f.id)); return; }
      var movidos = P.apagarPasta(f.id);
      P.lembrarPasta(f.id, true);
      gravar(); P.renderMenu(); foco(".nova-pasta");
      P.copiaSeguranca();
      P.mostrarStatus("Pasta apagada." + (movidos ? " " + (movidos === 1 ? "O modelo ficou" : "Os " + movidos + " modelos ficaram") + " fora das pastas." : "") + " Uma cópia de segurança foi guardada no computador.");
    });
  };

  U.enviar = function (f) {
    var ms = P.modelosDaPasta(f.id);
    if (!ms.length) { P.mostrarStatus("A pasta “" + f.nome + "” está vazia: não há o que enviar."); return; }
    P.exportar(ms, { pasta: f.nome });
  };

  U.novoModeloAqui = function (f) { P.abrirEditor({ pasta: f.id }); };

  // Itens do menu ⋯ de uma pasta
  U.itensMenu = function (f) {
    return [
      { icone: "＋", texto: "Novo modelo aqui", titulo: "Criar um modelo novo já dentro da pasta “" + f.nome + "”", aoClicar: function () { U.novoModeloAqui(f); } },
      { icone: "✏️", texto: "Renomear", titulo: "Mudar o nome da pasta “" + f.nome + "”", aoClicar: function () { U.renomear(f); } },
      { icone: "📤", texto: "Enviar pasta", titulo: "Salvar os modelos da pasta “" + f.nome + "” num arquivo, para mandar a um colega", aoClicar: function () { U.enviar(f); } },
      { icone: "🗑", texto: "Apagar pasta", perigo: true, titulo: "Apagar a pasta “" + f.nome + "” (os modelos NÃO são apagados: ficam fora das pastas)", aoClicar: function () { U.apagar(f); } }
    ];
  };
})();
