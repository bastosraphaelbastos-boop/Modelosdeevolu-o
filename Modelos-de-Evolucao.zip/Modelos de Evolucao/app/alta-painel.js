/*
 * Aba "Alta" — a tela (#painel-alta, no aside; a lógica está em alta.js). Mostra uma de duas coisas:
 *   - um aviso (modelo próprio, modelo sem alta, "Alta hoje?" ainda não é SIM...), ou
 *   - o painel: barra "📋 Copiar tudo" (fixa no topo), "Tipo de alta" (as sugeridas + "Outras altas ▸" com a lista completa agrupada;
 *     depois de escolher, a lista se recolhe e fica só a alta escolhida + "Trocar tipo de alta"; com a lista aberta de novo aparece "Cancelar" / Esc;
 *     faixa âmbar se a alta escolhida não está entre as sugeridas para a via atual)
 *     e os seis blocos (cartão com título, caixa editável de altura automática, "📋 Copiar" e, se a pessoa mexeu, "↶ voltar ao automático").
 * A tela só é refeita quando muda a situação ou a alta é zerada; no resto (a evolução mudou, outro tipo de alta, voltar de outra aba) só os textos
 * são atualizados, para nunca tirar o cursor de quem está escrevendo nem a rolagem do lugar (a rolagem é guardada ao sair da aba). Cópia: Motor.copiarTexto (a mesma do "Copiar texto" da evolução). Sem alert/confirm.
 * window.AltaPainel = { mostrar, guardar, copiarTudo }
 */
(function () {
  "use strict";
  var raiz = document.getElementById("painel-alta"), A = window.Alta, Motor = window.Motor;
  if (!raiz || !A || !Motor) return;
  var feito = "", geracao = -1, outrasAberto = false, trocando = false, timer = null, rolagem = 0, pendente = false;
  var areas = {}, avisos = {}, status = null, caixaTipos = null, listaTodas = null, botaoOutras = null, caixaEscolha = null, linhaEscolhida = null, nomeEscolhida = null, botaoTrocar = null, botaoCancelar = null, avisoVia = null, nota = null, sugeridas = [], todas = [], chaveTipos = "";

  function criar(tag, classe, texto, pai) {
    var e = document.createElement(tag);
    if (classe) e.className = classe;
    if (texto) e.textContent = texto;
    if (pai) pai.appendChild(e);
    return e;
  }
  function botao(classe, texto, pai, aoClicar) {
    var b = criar("button", classe, texto, pai);
    b.type = "button"; b.addEventListener("click", aoClicar);
    return b;
  }
  function ajustar(ta) { if (ta.offsetParent === null) return; ta.style.height = "auto"; ta.style.height = (ta.scrollHeight + 2) + "px"; }   // altura automática (aba fechada = 0: refaz ao mostrar)
  function ajustarTodas() { A.CHAVES.forEach(function (c) { if (areas[c]) ajustar(areas[c]); }); }

  // ---------- cópia ----------
  function dizer(texto) {
    if (!status) return;
    status.textContent = texto;
    clearTimeout(timer);
    timer = setTimeout(function () { if (status) status.textContent = ""; }, 6000);
  }
  function copiar(texto, nome) {
    Motor.copiarTexto(texto, function () { dizer("✔ Copiado: " + nome + ". Agora cole no prontuário (Ctrl+V)."); },
      function () { dizer("Não consegui copiar sozinho: clique no texto, aperte Ctrl+A e depois Ctrl+C."); });
  }
  var PRONTA = {
    teste: "durante o teste do modelo, a alta fica desligada.",
    proprio: "a alta automática existe só nos modelos prontos de evolução, por enquanto.",
    semalta: "este modelo não tem alta.",
    naosim: "responda “Alta hoje?” = SIM na evolução."
  };
  // Ctrl+Enter / "Copiar tudo": sem alta montada, avisa no painel em vez de não fazer nada
  function copiarTudo() {
    if (!raiz.hidden) desenhar();
    var s = A.situacao();
    if (s !== "ok") { if (nota) nota.textContent = "A alta ainda não está pronta: " + PRONTA[s]; return; }
    if (!status) return;
    var t = A.textoTudo();
    if (!t) { dizer("Ainda não há nada para copiar: escolha o tipo de alta."); return; }
    copiar(t, "tudo");
  }

  // ---------- tipo de alta ----------
  function pilula(a, pai) {
    var b = botao("alta-pilula", a.nome, pai, function () {
      A.escolher(a.id).then(function (ok) {         // "Não, manter" também recolhe de novo (nada mudou)
        trocando = false; atualizarTipos(); if (ok) atualizarBlocos();
        if (botaoTrocar && !linhaEscolhida.hidden) botaoTrocar.focus({ preventScroll: true });
      });
    });
    b.dataset.id = a.id;
    return b;
  }
  function marcarPilulas() {
    sugeridas.concat(todas).forEach(function (b) { b.setAttribute("aria-pressed", b.dataset.id === A.escolhida() ? "true" : "false"); });
  }
  // As sugeridas (a escolhida sempre aparece, mesmo que o modelo deixe de sugeri-la). Só refaz os botões se a lista mudou.
  function atualizarTipos() {
    var lista = A.sugeridas(), esc = A.porId(A.escolhida());
    if (esc && !lista.some(function (a) { return a.id === esc.id; })) lista.push(esc);
    var chave = lista.map(function (a) { return a.id; }).join("|");
    if (chave !== chaveTipos) {
      chaveTipos = chave; caixaTipos.textContent = ""; sugeridas = [];
      lista.forEach(function (a) { sugeridas.push(pilula(a, caixaTipos)); });
      if (!lista.length) criar("span", "alta-nada", "Nenhuma alta sugerida: abra “Outras altas”.", caixaTipos);
    }
    marcarPilulas();
    // Recolhido: com uma alta escolhida (e sem estar trocando), mostra só ela e o botão "Trocar tipo de alta"
    var recolher = !!esc && !trocando;
    caixaEscolha.hidden = recolher; linhaEscolhida.hidden = !recolher;
    botaoCancelar.hidden = !esc;               // (só há o que cancelar quando já existe uma alta escolhida)
    if (esc) {
      nomeEscolhida.textContent = esc.nome;
      botaoTrocar.setAttribute("aria-label", "Trocar tipo de alta (alta escolhida: " + esc.nome + ")");
      avisoVia.hidden = A.sugeridas().some(function (a) { return a.id === esc.id; });     // não combina com a via escolhida na evolução
    }
  }
  function cancelarTroca() {
    trocando = false; atualizarTipos();
    if (botaoTrocar && !linhaEscolhida.hidden) botaoTrocar.focus({ preventScroll: true });
  }
  function abrirOutras() {
    listaTodas.hidden = !outrasAberto;
    botaoOutras.textContent = outrasAberto ? "Outras altas ▾" : "Outras altas ▸";
    botaoOutras.setAttribute("aria-expanded", outrasAberto ? "true" : "false");
  }

  // ---------- blocos ----------
  // inicial: caixa recém-criada (também recebe o texto escrito à mão); depois, só os blocos automáticos são atualizados
  function atualizarBlocos(inicial) {
    A.CHAVES.forEach(function (c) {
      var ta = areas[c];
      if (inicial || !A.editado(c)) { var v = A.valor(c); if (ta.value !== v) ta.value = v; }
      ta.placeholder = A.dica(c);
      avisos[c].hidden = !A.editado(c);
      avisos[c].parentNode.classList.toggle("editado", A.editado(c));
      ajustar(ta);
    });
  }
  function bloco(c, pai) {
    var cartao = criar("section", "alta-bloco", "", pai), cab = criar("div", "alta-cab", "", cartao), id = "alta-area-" + c;
    criar("label", "alta-titulo-bloco", A.TITULOS[c], cab).htmlFor = id;
    botao("alta-copiar", "📋 Copiar", cab, function () { copiar(A.valor(c), A.TITULOS[c]); }).setAttribute("aria-label", "Copiar " + A.TITULOS[c]);
    var ta = criar("textarea", "alta-area", "", cartao);
    ta.id = id; ta.rows = 1; ta.spellcheck = true; ta.lang = "pt-BR";
    ta.addEventListener("input", function () { A.editar(c, ta.value); atualizarBlocos(); });
    var av = criar("div", "alta-edicao", "Você alterou este bloco · ", cartao);
    botao("alta-voltar", "↶ voltar ao automático", av, function () { A.voltar(c); atualizarBlocos(); ta.focus(); });
    areas[c] = ta; avisos[c] = av;
  }

  function montarPainel() {
    areas = {}; avisos = {}; sugeridas = []; todas = []; chaveTipos = ""; nota = null;
    var barra = criar("div", "alta-barra", "", raiz);
    botao("alta-tudo", "📋 Copiar tudo", barra, copiarTudo).title = "Copia todos os blocos, cada um com o seu título (Ctrl+Enter)";
    status = criar("span", "alta-status", "", barra); status.setAttribute("role", "status");

    criar("p", "alta-rotulo", "Tipo de alta", raiz);
    linhaEscolhida = criar("div", "alta-escolhida", "", raiz);
    var fixa = criar("span", "alta-pilula-fixa", "", linhaEscolhida);       // (não é botão: texto para leitor de tela, sem aria-pressed)
    criar("span", "alta-so-leitor", "Alta escolhida: ", fixa);
    nomeEscolhida = criar("span", "alta-nome", "", fixa);
    botaoTrocar = botao("alta-trocar", "Trocar tipo de alta", linhaEscolhida, function () {
      trocando = true; atualizarTipos();
      var atual = caixaEscolha.querySelector('.alta-pilula[aria-pressed="true"]') || caixaEscolha.querySelector(".alta-pilula");
      if (atual) atual.focus({ preventScroll: true });
    });
    avisoVia = criar("p", "alta-aviso-via", "Esta alta não combina com a via escolhida na evolução — confira", linhaEscolhida); avisoVia.hidden = true;
    caixaEscolha = criar("div", "alta-escolha", "", raiz);
    caixaEscolha.addEventListener("keydown", function (e) { if (e.key === "Escape" && trocando && A.escolhida()) { e.preventDefault(); e.stopPropagation(); cancelarTroca(); } });
    caixaTipos = criar("div", "alta-pilulas", "", caixaEscolha); caixaTipos.setAttribute("role", "group"); caixaTipos.setAttribute("aria-label", "Tipo de alta");
    var acoes = criar("div", "alta-acoes", "", caixaEscolha);
    botaoOutras = botao("alta-outras", "", acoes, function () { outrasAberto = !outrasAberto; abrirOutras(); });
    botaoCancelar = botao("alta-cancelar", "Cancelar", acoes, cancelarTroca);
    botaoCancelar.title = "Volta a mostrar só a alta escolhida, sem mudar nada (Esc)"; botaoCancelar.hidden = true;
    listaTodas = criar("div", "alta-todas", "", caixaEscolha);
    A.grupos().forEach(function (g) {
      criar("p", "alta-grupo", g.nome, listaTodas);
      var caixa = criar("div", "alta-pilulas", "", listaTodas);
      g.itens.forEach(function (a) { todas.push(pilula(a, caixa)); });
    });
    abrirOutras();
    var blocos = criar("div", "alta-blocos", "", raiz);
    A.CHAVES.forEach(function (c) { bloco(c, blocos); });
    atualizarTipos(); atualizarBlocos(true);
  }

  // ---------- avisos (quando não dá para montar a alta) ----------
  var TEXTOS = {
    teste: "Durante o teste do modelo, a alta fica desligada.",
    proprio: "A alta automática existe só nos modelos prontos de evolução, por enquanto.",
    semalta: "Este modelo não tem alta.",
    naosim: "Para montar a alta, responda “Alta hoje?” = SIM na evolução."
  };
  function montarAviso(situacao) {
    status = null;
    var c = criar("div", "alta-msg", "", raiz);
    criar("p", "", TEXTOS[situacao], c);
    nota = criar("p", "alta-msg-nota", "", c);          // mensagens curtas (Ctrl+Enter sem alta pronta; botão abaixo)
    nota.setAttribute("role", "status");
    if (situacao !== "naosim") return;
    botao("alta-ir", "Ir para “Alta hoje?”", c, function () {
      if (Motor.focarItem("alta")) { nota.textContent = ""; return; }
      nota.textContent = Motor.editadoAMao() ? "Os campos da evolução estão pausados porque o texto final foi alterado. Desfaça as alterações na aba Evolução para responder."
        : "Não encontrei a pergunta “Alta hoje?” na evolução.";
    });
    c.appendChild(nota);       // (a nota fica abaixo do botão)
  }

  // Desenha (ou só atualiza) conforme a situação. Chamado ao abrir a aba e a cada mudança.
  // Só refaz a tela se a situação mudou ou a alta foi zerada (nova paciente...); senão só atualiza os textos. Ao refazer, mantém a rolagem (zera se for outra alta).
  function desenhar() {
    var s = A.situacao(), chave = s + "|" + A.geracao(), nova = A.geracao() !== geracao;
    if (nova) { geracao = A.geracao(); outrasAberto = false; trocando = false; feito = ""; rolagem = 0; }
    if (chave !== feito) {
      if (!raiz.hidden && !nova && !pendente) rolagem = raiz.scrollTop;
      feito = chave; raiz.textContent = "";
      if (s === "ok") montarPainel(); else montarAviso(s);
      raiz.scrollTop = rolagem;
    } else if (s === "ok") { atualizarTipos(); atualizarBlocos(); }
  }

  A.aoMudar(function () { if (!raiz.hidden) desenhar(); });          // aba fechada: ao abrir, desenhar() atualiza (ou refaz se a situação mudou)
  window.addEventListener("resize", function () { if (!raiz.hidden) ajustarTodas(); });
  window.AltaPainel = {
    mostrar: function () { desenhar(); ajustarTodas(); if (pendente) { raiz.scrollTop = rolagem; pendente = false; } },   // (abas-saida.js tira o hidden antes)
    guardar: function () { if (!raiz.hidden) { rolagem = raiz.scrollTop; pendente = true; } },                          // chamado antes de a aba fechar (display:none zera a rolagem)
    copiarTudo: copiarTudo
  };
})();
