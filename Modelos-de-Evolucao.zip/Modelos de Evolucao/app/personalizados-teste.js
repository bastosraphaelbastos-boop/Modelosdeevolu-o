/*
 * Evoluções personalizadas — "▶ Testar o modelo" (como o médico vai usar).
 * Esconde o criador (sem perder nada) e abre o rascunho atual no MOTOR DE VERDADE da tela principal: campos, opções,
 * texto final, contador de pendências e copiar. É um modelo temporário (id "teste:rascunho"): não entra na lista nem no
 * localStorage. Uma faixa roxa fixa no topo avisa; Esc ou "← Voltar a editar" devolve o criador exatamente como estava.
 * O motor guarda o modelo que estava aberto (Motor.testar / Motor.sairDoTeste) e o devolve com o preenchimento dele.
 * Durante o teste o menu de modelos, a tela de início do app, "Ferramentas extras" e o cabeçalho ficam inertes.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var T = P.Teste = {};
  var el = P.el;
  var ativo = null;           // { faixa, rolagem, foco, travados } enquanto o teste está aberto
  var INERTES = "body > header, #inicio, #ferramentas, body > footer, #lista-modelos, #abas-saida, #painel-alta";

  T.ativo = function () { return !!ativo; };

  // O botão grande que fica acima de "Como vai ficar". Devolve um bloco com o botão em .bt
  T.botao = function () {
    var caixa = el("div", "ep-testar");
    var bt = el("button", "ep-testar-bt", "▶ Testar o modelo (como o médico vai usar)"); bt.type = "button";
    bt.title = "Abre o modelo na tela principal para você preencher como o médico vai fazer. Nada é salvo.";
    var msg = el("p", "ep-testar-msg"); msg.setAttribute("aria-live", "polite");
    bt.addEventListener("click", function () { iniciar(bt, msg); });
    caixa.appendChild(bt); caixa.appendChild(msg);
    caixa.bt = bt;
    return caixa;
  };

  function iniciar(bt, msg) {
    var e = P._ed.estado();
    if (!e || ativo) return;
    var v = P.validar(e.nome.value, e.master.value);
    if (v.erros.length) {            // erro grave: não abre
      var vazio = v.erros.some(function (x) { return x.vazio; });
      e.tentou = true; P._ed.aoMudar();
      msg.textContent = vazio ? "Escreva o modelo antes de testar." : "Corrija os itens em vermelho antes de testar.";
      bt.title = msg.textContent;
      if (!vazio) e.problemas.scrollIntoView({ block: "nearest" });
      return;
    }
    msg.textContent = "";
    var nome = P.nomeLimpo(e.nome.value) || "Sem nome";
    var m = P.modeloMotor({ id: "teste", nome: nome, texto: P.limpar(e.master.value) });
    m.id = "teste:rascunho";         // id especial: não é de nenhum modelo da lista
    ativo = { faixa: null, rolagem: e.raiz.scrollTop, foco: document.activeElement, bt: bt, raiz: e.raiz };

    if (window.AbasSaida) window.AbasSaida.escolher("evolucao");
    P.Motor.testar(m);
    e.raiz.classList.add("ep-oculto"); e.raiz.inert = true;           // escondido (visibility): a rolagem e o bloco aberto ficam como estão
    P.travarFundo(false);
    Array.prototype.forEach.call(document.querySelectorAll(INERTES), function (x) { x.inert = true; });
    document.body.classList.add("em-teste");

    var faixa = el("div", "faixa-teste"); faixa.setAttribute("role", "status");
    faixa.appendChild(el("span", "faixa-teste-tx", "🧪 Você está testando o modelo «" + nome + "». Nada é salvo."));
    var voltar = el("button", "faixa-teste-bt", "← Voltar a editar"); voltar.type = "button";
    voltar.addEventListener("click", sair);
    faixa.appendChild(voltar);
    document.body.insertBefore(faixa, document.body.firstChild);
    ativo.faixa = faixa;
  }

  function sair() {
    if (!ativo) return;
    var a = ativo; ativo = null;
    P.Motor.sairDoTeste();
    a.faixa.remove();
    document.body.classList.remove("em-teste");
    Array.prototype.forEach.call(document.querySelectorAll(INERTES), function (x) { x.inert = false; });
    P.travarFundo(true);              // o criador volta a ser a única janela ativa
    a.raiz.classList.remove("ep-oculto"); a.raiz.inert = false;
    a.raiz.scrollTop = a.rolagem;
    var foco = a.foco && a.foco.isConnected && a.raiz.contains(a.foco) ? a.foco : a.bt;
    if (foco && foco.focus) foco.focus({ preventScroll: true });
  }

  // Esc volta ao criador (a menos que o texto final esteja em tela cheia ou haja uma pergunta aberta: aí o Esc é dessas)
  document.addEventListener("keydown", function (e) {
    if (!ativo || e.key !== "Escape") return;
    if (!document.getElementById("pergunta-tela").hidden || document.querySelector("aside.ampliado")) return;
    e.preventDefault(); e.stopPropagation();
    sair();
  }, true);
})();
