/*
 * Evoluções personalizadas — o criador: janelinha "Contar dias" (parte de personalizados-editor.js; carregue depois de personalizados-marcar.js).
 * A janelinha "Escolha entre opções" está em personalizados-dialogo-opcoes.js.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var PE = P._ed;          // peças compartilhadas do criador (registradas em personalizados-editor.js)
  var el = PE.el, botao = PE.botao, dica = PE.dica, substituir = PE.substituir, janelinha = PE.janelinha,
      limparTextarea = PE.limparTextarea, compilarCache = PE.compilarCache, marcadores = PE.marcadores, selecao = PE.selecao;

  // ---------- diálogo "Contar dias" ----------
  // opcoes (opcional): { nova: true, aoCancelar: fn }, como em dialogoOpcoes (bloco vazio criado pela paleta some ao cancelar)
  function dialogoDias(opcoes) {
    var ed = PE.estado();
    opcoes = opcoes || {};
    var ta = ed.ta;
    limparTextarea();
    var a = ta.selectionStart, b = ta.selectionEnd, t0 = ta.value;
    if (a !== b) {
      var x = selecao(); if (!x) return;
      a = x.a; b = x.b;
    } else {
      var m = marcadores(t0);
      for (var k = 0; k < m.length; k++) if (m[k].s < a && a < m[k].e) { dica("Aqui já há uma marcação. Clique em outro lugar do texto."); return; }
    }
    dica("");
    var datas = compilarCache(ed.master.value).estrutura.datas;     // datas do modelo inteiro (no modo Blocos, t0 é só o bloco aberto)
    var j = janelinha("dlg-dias-titulo", "Contar dias", true), caixa = j.corpo;
    var fecharJ = j.fechar;
    j.fechar = function () { fecharJ(); if (opcoes.nova && opcoes.aoCancelar) opcoes.aoCancelar(); };
    caixa.appendChild(el("p", "dlg-ajuda", "O app conta sozinho quantos dias passaram desde uma data que o médico digita. O dia da própria data conta como 0 (ex.: internada hoje = 0 dias)."));
    var lb = el("label", "dlg-extra-rot", "Contar dias desde qual data?"); lb.htmlFor = "dlg-dias-sel";
    caixa.appendChild(lb);
    var sel = null;
    if (datas.length) {
      sel = el("select", "dlg-campo"); sel.id = "dlg-dias-sel";
      datas.forEach(function (d) { var o = el("option", "", "[@" + d.nome + "] (já está no modelo)"); o.value = d.id; sel.appendChild(o); });
      var oN = el("option", "", "＋ Outra data (nova)"); oN.value = ""; sel.appendChild(oN);
      caixa.appendChild(sel);
    }
    var nomeLb = el("label", "dlg-extra-rot", "Nome da data (ex.: INTERNAÇÃO, INÍCIO DO ANTIBIÓTICO):"); nomeLb.htmlFor = "dlg-dias-nome";
    var nome = el("input", "dlg-campo"); nome.type = "text"; nome.id = "dlg-dias-nome"; nome.maxLength = 60; nome.placeholder = "Ex.: INTERNAÇÃO";
    var bNome = el("div", "dlg-sub"); bNome.appendChild(nomeLb); bNome.appendChild(nome);
    caixa.appendChild(bNome);
    var previa = el("p", "dlg-hint dlg-previa-ins"), msg = el("p", "dlg-erro");
    caixa.appendChild(previa); caixa.appendChild(msg);
    var limparNome = function (s) { return s.replace(/[\[\]{}()|:=\\*]/g, " ").replace(/\s+/g, " ").trim().toUpperCase(); };
    function plano() {
      var existente = sel && sel.value ? datas.filter(function (d) { return d.id === sel.value; })[0] : null;
      if (existente) return { nome: existente.nome, novo: false, id: existente.id };
      var n = limparNome(nome.value), id = P.normalizarNome(n), ja = datas.filter(function (d) { return d.id === id; })[0];
      if (ja) return { nome: ja.nome, novo: false, id: id };
      return { nome: n, novo: true, id: id };
    }
    function atualizar() {
      bNome.hidden = !!(sel && sel.value);
      var p = plano();
      previa.textContent = p.nome ? "Vai inserir: " + (p.novo ? "[@" + p.nome + ": dd/mm/aaaa] " : "") + "((DIAS DESDE @" + p.nome + "))" : "";
    }
    if (sel) sel.addEventListener("change", atualizar);
    nome.addEventListener("input", atualizar);
    function inserir() {
      var p = plano();
      if (!p.id) { msg.textContent = "Escreva um nome para a data, com letras ou números (ex.: INTERNAÇÃO)."; nome.focus(); return; }
      var texto = (p.novo ? "[@" + p.nome + ": dd/mm/aaaa] " : "") + "((DIAS DESDE @" + p.nome + "))";
      fecharJ();
      substituir(a, b, texto);
      dica(p.novo ? "Pronto: o espaço da data e o número de dias foram colocados. Escreva o texto ao redor como quiser." : "Pronto: os dias serão contados desde «" + p.nome + "».");
    }
    nome.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); inserir(); } });
    var acoes = el("div", "dlg-acoes");
    acoes.appendChild(botao("dlg-cancelar", "", "Cancelar", j.fechar));
    acoes.appendChild(botao("dlg-ok", "", "✓ Inserir", inserir));
    j.caixa.appendChild(acoes);
    j.abrir(); atualizar();
    (sel || nome).focus();
  }

  PE.dialogoDias = dialogoDias;
})();
