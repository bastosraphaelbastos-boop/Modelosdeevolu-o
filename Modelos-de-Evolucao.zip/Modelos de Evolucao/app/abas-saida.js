/*
 * Abas "Evolução" / "Alta" no topo da coluna do texto final (indicador deslizante no CSS: #abas-saida).
 * Evolução = o texto final de sempre. Alta = o painel da alta (alta-painel.js), um segundo texto ao lado: a evolução nunca é trocada por ela.
 * Ctrl+Enter: com a aba Alta selecionada copia a ALTA toda (foco em qualquer lugar do aside, barra de abas incluída, ou fora de campos); com o foco
 * nos campos da evolução (#editor) copia a evolução e volta para a aba Evolução. Sem alta pronta, o painel mostra um aviso curto. Dentro de
 * #ferramentas e do criador não interfere. Não salva nada.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var caixa = $("abas-saida"), abas = { evolucao: $("aba-evolucao"), alta: $("aba-alta") };
  if (!caixa || !window.Motor) return;

  function escolher(qual, focar) {
    var naAlta = qual === "alta";
    if (!naAlta && window.AltaPainel) window.AltaPainel.guardar();       // guarda a rolagem do painel da alta antes de escondê-lo
    caixa.classList.toggle("na-alta", naAlta);
    Object.keys(abas).forEach(function (k) {
      var sim = k === qual;
      abas[k].setAttribute("aria-selected", sim ? "true" : "false");
      abas[k].tabIndex = sim ? 0 : -1;
    });
    $("painel-evolucao").hidden = naAlta;
    $("painel-alta").hidden = !naAlta;
    if (naAlta && window.AltaPainel) window.AltaPainel.mostrar();
    if (focar) abas[qual].focus();
  }

  abas.evolucao.addEventListener("click", function () { escolher("evolucao"); });
  abas.alta.addEventListener("click", function () { escolher("alta"); });
  // Setas, Home e End trocam de aba (padrão das abas acessíveis)
  caixa.addEventListener("keydown", function (e) {
    var k = e.key;
    if (k === "ArrowLeft" || k === "Home") { e.preventDefault(); escolher("evolucao", true); }
    else if (k === "ArrowRight" || k === "End") { e.preventDefault(); escolher("alta", true); }
  });
  // Ctrl+Enter (em captura, antes do atalho do motor, que copiaria a evolução)
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Enter" || !e.ctrlKey || e.altKey) return;
    if (!$("pergunta-tela").hidden || !$("termos-tela").hidden || document.body.classList.contains("no-inicio")) return;   // janelas abertas / tela de início: o motor também não faz nada
    var alvo = e.target && e.target.closest ? e.target : document.body;
    if (alvo.closest("#ferramentas") || alvo.closest(".modal-pers")) return;                    // ferramentas extras e criador: não interferir
    if (!window.Motor.emTeste() && document.querySelector(".modal-pers:not([hidden])")) return;   // criador aberto (no teste ele só fica escondido)
    if (!$("painel-alta").hidden && window.AltaPainel && !alvo.closest("#editor")) {              // aba Alta aberta e foco fora dos campos da evolução
      e.preventDefault(); e.stopPropagation(); window.AltaPainel.copiarTudo();
      return;
    }
    escolher("evolucao");                                                                        // copiar a evolução mostra a aba Evolução (o texto copiado é o dela)
  }, true);
  // Voltar a preencher a evolução (focar um campo dela) mostra a aba Evolução
  var editor = $("editor");
  if (editor) editor.addEventListener("focusin", function () { escolher("evolucao"); });
  window.AbasSaida = { escolher: escolher };
  // Escolher um modelo de evolução (menu ou Alt+n) volta para a aba Evolução, mas só se a troca de fato acontecer:
  // se a pessoa cancelar a pergunta "Trocar de modelo apaga o que foi preenchido", fica onde estava
  var querTrocar = false, menu = $("lista-modelos");
  document.addEventListener("modeloselecionado", function () { if (querTrocar) { querTrocar = false; escolher("evolucao"); } });
  if (menu) menu.addEventListener("click", function (e) {
    if (!e.target.closest(".item-modelo") || $("painel-alta").hidden) return;
    querTrocar = true;
    setTimeout(function () { if ($("pergunta-tela").hidden) querTrocar = false; }, 0);          // sem pergunta aberta e sem troca: era o mesmo modelo
  }, true);                                                                                       // (captura: antes do clique do item, que já pode trocar na hora)
  $("pergunta-nao").addEventListener("click", function () { querTrocar = false; });
  $("pergunta-tela").addEventListener("keydown", function (e) { if (e.key === "Escape") querTrocar = false; });
})();
