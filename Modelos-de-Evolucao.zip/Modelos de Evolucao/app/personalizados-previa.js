/*
 * Evoluções personalizadas — o criador: a prévia "Como vai ficar" e as mensagens de problemas, em âmbar
 * (parte de personalizados-editor.js). Todo texto entra por textContent. Carregue depois de personalizados-editor.js.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var PE = P._ed;          // peças compartilhadas do criador (registradas em personalizados-editor.js)
  var el = PE.el, compilarCache = PE.compilarCache;

  // ---------- pré-visualização "Como vai ficar" ----------
  function pvTitulos(texto, pai, inicioDeLinha) {
    texto.split(/(\n)/).forEach(function (parte, i, partes) {
      var inicio = i === 0 ? inicioDeLinha : partes[i - 1] === "\n";
      var m = inicio && parte.match(/^(#[^:(\n]*:?)([\s\S]*)$/);
      if (m && m[1].replace(/[#\s]/g, "")) {
        pai.appendChild(el("span", "titulo-secao", m[1]));
        if (m[2]) pai.appendChild(document.createTextNode(m[2]));
      } else if (parte) pai.appendChild(document.createTextNode(parte));
    });
  }

  // ctx: { autos: ids dos campos de "dias", simulaveis: ids de escolhas que têm trechos condicionais }
  function pvSegmentos(segs, pai, estado, ctx) {
    var ed = PE.estado();
    segs.forEach(function (s) {
      var x;
      if (s.tipo === "texto_fixo") { pvTitulos(s.texto, pai, estado.inicio); estado.inicio = /\n$/.test(s.texto); return; }
      estado.inicio = false;
      if (s.tipo === "campo") {
        if (ctx.autos[s.id]) x = el("span", "pv-dias", "nº de dias (automático)");
        else {                                  // igual ao espaço da tela principal: curto = compacto; mais longo que a dica = texto corrido que quebra a linha
          var tx = s.padrao || s.rotulo || "…";
          x = el("span", "pv-campo" + (s.padrao ? " cheio" : "") + (tx.length > Math.max((s.rotulo || "").length, 3) ? " longo" : ""), tx);
        }
      }
      else if (s.tipo === "texto") { x = el("span", "pv-texto", "✎ " + (s.rotulo || "texto livre (opcional)")); }
      else if (s.tipo === "editavel") { x = el("span", "editavel", s.padrao); }
      else if (s.tipo === "opcao" || s.tipo === "controle") {
        var simula = !!ctx.simulaveis[s.id];
        x = el("span", "opcoes pv-opcoes" + (s.tipo === "controle" ? " controle" : ""));
        if (s.rotulo) x.dataset.rotulo = s.rotulo;
        s.opcoes.forEach(function (o) {
          var bt = el("button", "", o); bt.type = "button";
          if (simula) {
            bt.title = "Clique para ver só o que aparece depois desta opção (só para conferir; nada é salvo)";
            if (ed.simul[s.id] === o) bt.classList.add("sel");
            bt.addEventListener("click", function () { ed.simul[s.id] = ed.simul[s.id] === o ? "" : o; atualizarPrevia(); });
          } else { bt.tabIndex = -1; bt.disabled = true; }
          x.appendChild(bt);
        });
      }
      else if (s.tipo === "auxiliar") { x = el("span", "pv-aux", s.rotulo || "…"); }
      else if (s.tipo === "dica") { x = el("span", "dica", "💡 " + s.texto); }
      else if (s.tipo === "aviso") { x = el("span", "aviso-inline", "⚠ " + s.texto); }
      else if (s.tipo === "bloco") {
        var escolhida = ctx.semSimular ? "" : ed.simul[s.chave];
        if (escolhida && escolhida !== s.valor) return;        // simulando outra opção: este trecho não apareceria
        x = el("span", "pv-bloco");
        x.appendChild(el("span", "pv-se", s.valor ? "➜ aparece se escolher «" + s.valor + "»" : "➜ enquanto ninguém responder"));
        pvSegmentos(s.filhos, x, { inicio: false }, ctx);
      }
      if (x) pai.appendChild(x);
    });
  }

  // Coluna da direita: o TEXTO FINAL, igual ao da tela principal (o que o médico copia e cola no prontuário),
  // ainda sem nada preenchido: ___ nos espaços e "A / B" nas escolhas. É o motor de verdade que monta (Motor.textoFinal).
  function atualizarPrevia() {
    var ed = PE.estado();
    var alvo = ed.previa, rolagem = alvo.scrollTop;
    alvo.textContent = "";
    if (ed.master.value.length > P.MAX_MODELO) { alvo.appendChild(el("p", "pv-vazio", "O texto é grande demais para mostrar.")); return; }
    var r = compilarCache(ed.master.value);
    if (!ed.master.value.trim()) { alvo.appendChild(el("p", "pv-vazio", "O texto final aparece aqui conforme você monta o modelo.")); return; }
    if (r.erros.length) { alvo.appendChild(el("p", "pv-vazio", "Corrija os itens marcados com ⛔ (abaixo do modelo) para ver o texto final.")); return; }
    try {
      var t = P.Motor.textoFinal(r.saida.replace(/^\n/, ""));
      alvo.appendChild(document.createTextNode(t || "(o texto final está vazio)"));
      alvo.scrollTop = rolagem;
    }
    catch (e) { alvo.appendChild(el("p", "pv-vazio", "Não consegui montar o texto final. Confira as mensagens abaixo do modelo.")); }
  }

  // ---------- mensagens de problemas (em âmbar) ----------
  function atualizarProblemas() {
    var ed = PE.estado();
    var v = P.validar(ed.nome.value, ed.master.value, compilarCache(ed.master.value)), caixa = ed.problemas, itens = [];
    caixa.textContent = "";
    // "modelo vazio" e "falta o nome" só aparecem depois de clicar em Salvar e usar
    v.erros.forEach(function (x) { if (!x.vazio || ed.tentou) itens.push({ grave: true, txt: P.mensagem(x), linha: x.linha }); });
    if (ed.tentou && v.nomeErro) itens.unshift({ grave: true, txt: v.nomeErro });
    v.avisos.forEach(function (x) {
      if (x.semMarca && !ed.tentou) return;          // "nenhum espaço nem escolha": só depois de tentar salvar (no começo é sempre assim)
      itens.push({ grave: false, txt: P.mensagem(x), linha: x.linha });
    });
    if (P.Blocos) P.Blocos.marcarErros(v.erros.filter(function (x) { return x.linha > 0; }));     // modo Blocos: o erro aparece no próprio cartão
    caixa.hidden = !itens.length;
    if (!itens.length) return v;
    if (itens.some(function (i) { return i.grave; })) caixa.appendChild(el("p", "pb-tit", "Confira antes de salvar:"));
    var ul = el("ul");
    itens.slice(0, 12).forEach(function (i) {
      var li = el("li", i.grave ? "grave" : "");
      if (i.linha > 0) {        // clicar leva o cursor à linha do problema (no modo Blocos, abre o bloco)
        var ir = el("button", "pb-ir", (i.grave ? "⛔ " : "⚠ ") + i.txt); ir.type = "button";
        ir.title = "Clique para ir até esta linha";
        ir.addEventListener("click", function () { irParaLinha(i.linha); });
        li.appendChild(ir);
      } else li.textContent = (i.grave ? "⛔ " : "⚠ ") + i.txt;
      ul.appendChild(li);
    });
    caixa.appendChild(ul);
    if (itens.length > 12) caixa.appendChild(el("p", "pb-mais", "…e mais " + (itens.length - 12) + " avisos."));
    return v;
  }

  // Leva o cursor ao começo da linha n (1 = primeira) do texto inteiro. No modo Blocos abre o bloco que contém a linha.
  function irParaLinha(n) {
    var ed = PE.estado();
    if (ed.modo === "blocos" && P.Blocos) { P.Blocos.irParaLinha(n); return; }
    var ta = ed.master, linhas = ta.value.split("\n"), a = 0, k;
    for (k = 0; k < n - 1 && k < linhas.length - 1; k++) a += linhas[k].length + 1;
    var b = a + (linhas[Math.min(n - 1, linhas.length - 1)] || "").length;
    if (ed.visual && !ed.visual.hidden && P.Visual) { P.Visual.irPara(a, a); return; }       // modo Texto: cursor no começo da linha, no editor visual
    ta.focus(); ta.setSelectionRange(a, b);
    var lh = parseFloat(getComputedStyle(ta).lineHeight) || 24;       // rola a caixa até a linha (conta linhas cortadas pela largura)
    var espelho = ta.value.slice(0, a).split("\n").length - 1;
    ta.scrollTop = Math.max(0, espelho * lh - ta.clientHeight / 3);
    ta.scrollIntoView({ block: "nearest" });
  }

  PE.pvSegmentos = pvSegmentos; PE.atualizarPrevia = atualizarPrevia; PE.atualizarProblemas = atualizarProblemas;
})();
