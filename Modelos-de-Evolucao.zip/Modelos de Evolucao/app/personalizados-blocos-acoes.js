/*
 * Modo "Blocos" do criador — mover, apagar e peças prontas (parte de personalizados-blocos.js; carregue depois de personalizados-blocos-cartao.js).
 * Registra em B._f: subir, descer, apagar, moverTrecho, adicionar, descartarVazio, fecharPaleta; e em B: fecharPaleta, adicionarPronto, abrirPaleta, focarInicio.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var B = P.Blocos = P.Blocos || {};
  var I = function () { return P._ed; };            // peças do criador (personalizados-editor.js)
  var st = null; B.aoMudarEstado(function (x) { st = x; });
  var Sec = P.BlocosSecoes;
  var ehTitulo = Sec.ehTitulo, fimSecao = Sec.fimSecao, trecho = Sec.trecho, garantirVisivel = Sec.garantirVisivel;
  var desativar = function () { return B._f.desativar(); }, guardar = function () { return B._f.guardar(); },
      sincronizar = function () { return B._f.sincronizar(); }, desenhar = function (f, c) { return B._f.desenhar(f, c); },
      trocar = function (i, n, novos) { return B._f.trocar(i, n, novos); };

  // ---------- mover / apagar ----------
  // Move n blocos a partir de ini para antes do bloco p (p = posição na lista de ANTES de tirar os blocos)
  function moverTrecho(ini, n, p, focarBotao) {
    if (p >= ini && p <= ini + n) return;
    desativar(); guardar();
    var us = st.unidades.splice(ini, n), fs = st.fecha.splice(ini, n), q = p > ini ? p - n : p;
    st.unidades.splice.apply(st.unidades, [q, 0].concat(us));
    st.fecha.splice.apply(st.fecha, [q, 0].concat(fs));
    sincronizar(); desenhar();
    garantirVisivel(q);                                // um bloco solto que caiu numa seção escondida: abre a seção
    var c = st.lista.children[q];
    if (c) {
      for (var k = q; k < q + n; k++) { var x = st.lista.children[k]; if (x) { x.classList.add("bl-movido"); (function (y) { setTimeout(function () { y.classList.remove("bl-movido"); }, 700); })(x); } }
      if (focarBotao) { var bt = c.querySelectorAll(".bl-ac:not(.bl-recolher)")[focarBotao === "sobe" ? 0 : 1]; if (bt && !bt.disabled) bt.focus(); else c.querySelector(".bl-corpo").focus(); }
    }
  }
  function subir(i, shift) {
    var t = trecho(i, shift), secao = !shift && ehTitulo(i), p;
    if (t[0] === 0) return;
    if (!secao) p = t[0] - 1;
    else { p = t[0] - 1; while (p > 0 && !ehTitulo(p)) p--; }       // a seção passa por cima da seção (ou dos blocos soltos) anterior
    moverTrecho(t[0], t[1] - t[0], p, "sobe");
  }
  function descer(i, shift) {
    var t = trecho(i, shift), secao = !shift && ehTitulo(i), p;
    if (t[1] >= st.unidades.length) return;
    p = secao ? fimSecao(t[1]) : t[1] + 1;
    moverTrecho(t[0], t[1] - t[0], p, "desce");
  }
  function removerFaixa(ini, fim) {
    desativar(); guardar();
    trocar(ini, fim - ini, []);
    if (!st.unidades.length) { st.unidades = [""]; st.fecha = [false]; }
    sincronizar(); desenhar();
    I().dica("Bloco apagado. Se foi sem querer, clique em “↶ Desfazer”.");
  }
  function apagar(i, shift) {
    var t = trecho(i, shift), n = t[1] - t[0];
    if (n === 1) { removerFaixa(t[0], t[1]); return; }
    var nome = st.unidades[i].replace(/^#+\s*/, "").trim().slice(0, 40) || "sem nome";
    P.Motor.perguntar("Apagar a seção «" + nome + "» e " + (n === 2 ? "o 1 bloco que está" : "os " + (n - 1) + " blocos que estão") + " nela?\n\nSe foi sem querer, depois dá para clicar em “↶ Desfazer”.",
      "Sim, apagar a seção", "Cancelar", true).then(function (sim) {
      if (sim && st && t[1] <= st.unidades.length) removerFaixa(t[0], t[1]);
    });
  }
  // Um bloco vazio criado pela paleta para uma peça com diálogo (escolha, pergunta, dias): se a pessoa cancelou o diálogo, ele some
  function descartarVazio(i) {
    if (!st || st.unidades[i] !== "") return;
    desativar();
    trocar(i, 1, []);
    if (!st.unidades.length) { st.unidades = [""]; st.fecha = [false]; }
    sincronizar(); desenhar();
  }

  // ---------- peças prontas ----------
  function adicionar(item) {
    fecharPaleta();
    desativar(); guardar();
    var pecas = P.Prontos.pecas(item);
    var pos = st.ultimo != null && st.ultimo < st.unidades.length ? st.ultimo + 1 : st.unidades.length;
    if (st.ultimo != null && ehTitulo(st.ultimo) && st.fecha[st.ultimo]) pos = fimSecao(st.ultimo);      // depois de uma seção escondida
    if (st.unidades.length === 1 && !st.unidades[0].trim()) { st.unidades = []; st.fecha = []; pos = 0; }      // modelo vazio: o bloco novo é o primeiro
    trocar(pos, 0, pecas);
    sincronizar();
    var alvo = pos + pecas.length - 1;
    st.ultimo = alvo;
    if (item.fechado) { desenhar(); marcarNovo(alvo); return; }
    desenhar(pos, item.sel != null ? item.sel : pecas[0].length);
    if (pecas.length > 1) marcarNovo(alvo);
    if (item.depois) P.Prontos.abrirDialogo(item, function () { descartarVazio(pos); });
  }
  function marcarNovo(i) {
    var c = st.lista.children[i]; if (!c) return;
    c.classList.add("bl-movido"); setTimeout(function () { c.classList.remove("bl-movido"); }, 700);
    c.scrollIntoView({ block: "nearest" });
  }
  function fecharPaleta() {
    if (st && st.paleta && st.paleta.aberto()) {
      var tinhaFoco = st.paleta.el.contains(document.activeElement);
      st.paleta.fechar(); st.bAdd.setAttribute("aria-expanded", "false");
      if (tinhaFoco) st.bAdd.focus({ preventScroll: true });          // o foco não se perde (o Esc seguinte continua valendo)
      return true;
    }
    return false;
  }
  B.fecharPaleta = fecharPaleta;
  B.adicionarPronto = adicionar;                     // usado pelos comandos "!" (personalizados-comandos.js)
  B.abrirPaleta = function () {                      // usado pela tela de início ("Montar do zero com blocos")
    if (!st || !st.paleta) return;
    st.paleta.abrir(); st.bAdd.setAttribute("aria-expanded", "true");
    st.paleta.focarPrimeira();
  };
  B.focarInicio = function () {
    if (!st) return;
    if (st.paleta && st.paleta.aberto()) { st.paleta.focarPrimeira(); return; }
    var c = st.lista.querySelector(".bl-corpo");
    if (c) c.focus({ preventScroll: true }); else if (st.bAdd) st.bAdd.focus();
  };

  B._f.subir = subir; B._f.descer = descer; B._f.apagar = apagar; B._f.moverTrecho = moverTrecho; B._f.adicionar = adicionar;
  B._f.descartarVazio = descartarVazio; B._f.fecharPaleta = fecharPaleta;
})();
