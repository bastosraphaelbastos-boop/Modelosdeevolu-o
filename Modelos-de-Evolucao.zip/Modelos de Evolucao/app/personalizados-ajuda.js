/*
 * Evoluções personalizadas — o criador: ajudas dentro da tela (parte de personalizados-editor.js).
 * Tabela "Comandos úteis pelo teclado", seção "Sem tempo? Peça para uma IA..." e a limpeza do texto colado de uma IA.
 * Todo texto entra por textContent. Carregue depois de personalizados-editor.js (o pedido da IA vem de prompt-ia.js).
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var PE = P._ed;          // peças compartilhadas do criador (registradas em personalizados-editor.js)
  var el = PE.el, botao = PE.botao;

  // ---------- texto colado de uma IA: tira as marcas de formatação ----------
  // Conteúdo de dentro de um bloco ``` (só o primeiro), linhas que são só ``` ou ```texto, e **negrito** -> *texto*
  P.limparColado = function (s) {
    var t = String(s).replace(/\r\n?/g, "\n");
    var m = /(^|\n)[ \t]*```[^\n]*\n([\s\S]*?)\n?[ \t]*```[ \t]*(?=\n|$)/.exec(t);
    if (m) t = m[2];
    t = t.split("\n").filter(function (l) { return !/^\s*```[\w-]*\s*$/.test(l); }).join("\n");
    return t.replace(/\*\*([^\s*](?:[^*\n]*?[^\s*])?)\*\*/g, "*$1*");
  };

  // ---------- seção "peça para uma IA" ----------
  function secaoIA() {
    var d = el("details", "ep-ia");
    d.appendChild(el("summary", "", "🤖 Sem tempo? Peça para uma IA montar o modelo (opcional)"));
    var passos = el("ol", "ep-ia-passos");
    ["Copie o pedido abaixo (botão “Copiar pedido para a IA”).",
     "Cole numa inteligência artificial de sua preferência e, no final, cole a sua evolução SEM dados de pacientes.",
     "Copie a resposta dela.",
     "Cole aqui na caixa do modelo e confira a prévia."].forEach(function (p) { passos.appendChild(el("li", "", p)); });
    d.appendChild(passos);
    var cuid = el("div", "ep-ia-cuidados"); cuid.setAttribute("role", "note");
    cuid.appendChild(el("p", "ep-ia-cuid-tit", "Cuidados importantes:"));
    var ul = el("ul");
    ["Nunca cole dados de pacientes na IA (nome, prontuário, CPF, leito, datas de nascimento). A IA é um serviço de terceiros, fora deste app.",
     "Usar IA não tira a sua responsabilidade: confira todo o modelo antes de salvar e todo texto antes de colar no prontuário.",
     "Não há garantia de que a IA siga o pedido corretamente: ela pode errar, omitir, inventar ou mudar o sentido do texto.",
     "Depois de colar aqui, você pode mudar o modelo como quiser, agora ou depois, em ✏️ Editar."].forEach(function (p) { ul.appendChild(el("li", "", p)); });
    cuid.appendChild(ul); d.appendChild(cuid);
    var st = el("p", "ep-ia-status"); st.setAttribute("aria-live", "polite");
    var pr = el("textarea", "ep-ia-prompt"); pr.readOnly = true; pr.rows = 10; pr.value = window.PROMPT_IA || "";
    pr.setAttribute("aria-label", "Pedido para a IA (somente leitura)");
    var ok = function () { st.textContent = "Pedido copiado. Agora cole na IA."; };
    var reserva = function () {
      var anterior = document.activeElement, deu = false;
      pr.focus(); pr.select();
      try { deu = document.execCommand("copy"); } catch (e) { deu = false; }
      pr.setSelectionRange(0, 0);
      if (anterior && anterior.focus) anterior.focus({ preventScroll: true });
      if (deu) ok(); else st.textContent = "Não consegui copiar sozinho: clique na caixa do pedido, aperte Ctrl+A e depois Ctrl+C.";
    };
    var copiar = botao("ep-ia-copiar", "", "📋 Copiar pedido para a IA", function () {
      var txt = window.PROMPT_IA || "";
      if (navigator.clipboard && window.isSecureContext) { try { navigator.clipboard.writeText(txt).then(ok, reserva); } catch (e) { reserva(); } }
      else reserva();
    });
    d.appendChild(copiar); d.appendChild(st);
    d.appendChild(el("p", "ep-ia-rot", "O pedido que será copiado:"));
    d.appendChild(pr);
    return d;
  }

  // [o que digitar, o que vira, exemplo]
  var REGRAS = [
    ["#", "título", "#EXAME FÍSICO"],
    ["[ ]", "espaço para preencher (clique dentro dele e use “Mudar este espaço” para dar um valor, ligar a outros espaços ou virar caixa grande)", "PA [pressão] MMHG"],
    ["[A / B]", "escolha entre opções", "[ESTÁVEL / INSTÁVEL]"],
    ["[...]", "caixa de texto livre (opcional)", "[...observações]"],
    ["[dica=VALOR]", "espaço que já vem preenchido com VALOR (o médico pode mudar)", "[turno=DIURNO]"],
    ["* *", "texto já escrito, que pode ser corrigido", "*SEM EDEMA*"],
    ["[hoje]", "data de hoje", "Data: [hoje]"],
    ["((SE A: texto))", "texto que só aparece se a escolha logo antes for A (deixe um espaço depois dos dois-pontos)", "ALERGIAS: [NEGA / REFERE]((SE REFERE: A [quais]))"],
    ["((SE SEM RESPOSTA: texto))", "texto que aparece enquanto ninguém escolheu", "[A / B]((SE SEM RESPOSTA: ((AVISO: escolha))))"],
    ["[? Pergunta? A / B]", "pergunta só na tela: a resposta não vai para o texto (use com ((SE …)))", "[? Alta hoje? NÃO / SIM]((SE SIM: *ALTA*))"],
    ["((AVISO: texto))", "aviso na tela que some quando responder; no texto fica ___ até resolver", "((AVISO: responda a pergunta))"],
    ["((DICA: texto))", "lembrete (só na tela); não vai para o texto", "((DICA: confira a data))"],
    ["[@NOME: dica]", "espaço com nome: espaços com o mesmo @NOME são preenchidos juntos", "[@ATB: dd/mm/aaaa]"],
    ["((DIAS DESDE @NOME))", "número de dias desde a data de [@NOME], contado sozinho (o dia da data é 0)", "D((DIAS DESDE @ATB))"],
    ["\\[  \\]  \\*", "escrevem o próprio símbolo", "\\[texto\\]"]
  ];

  // Tabela "Comandos úteis pelo teclado" (um <details> fechado)
  function secaoRegras() {
    var regras = el("details", "ep-regras"), sm = el("summary", "", "⌨ Comandos úteis pelo teclado (opcional)");
    regras.appendChild(sm);
    regras.appendChild(el("p", "ep-regras-intro", "Se preferir, você pode digitar estes símbolos em vez de usar os botões acima."));
    var envolta = el("div", "ep-regras-rol");
    var tab = el("table", "ep-regras-tab"), cab = el("tr");
    ["Digite", "Vira", "Exemplo"].forEach(function (c) { cab.appendChild(el("th", "", c)); });
    tab.appendChild(cab);
    REGRAS.forEach(function (r) {
      var tr = el("tr");
      [0, 2].forEach(function (k) { var td = el("td"); td.appendChild(el("code", "", r[k])); tr.appendChild(td); if (k === 0) tr.appendChild(el("td", "", r[1])); });
      tab.appendChild(tr);
    });
    envolta.appendChild(tab); regras.appendChild(envolta);
    return regras;
  }

  PE.secaoIA = secaoIA; PE.secaoRegras = secaoRegras; PE.REGRAS = REGRAS;      // (a janela de Ajuda, ajuda-criar.js, mostra a mesma tabela)
})();
