/*
 * Evoluções personalizadas — o "criador de modelos" (tela cheia): núcleo.
 * O médico cola um texto, SELECIONA com o mouse o que muda de paciente para paciente e clica num botão.
 * Por baixo, os botões só escrevem as regras simples (veja personalizados.js): [dica], [A / B], *texto*, [hoje], #título,
 * ((SE opção: texto)), [? pergunta? A / B], ((AVISO: …)), ((DICA: …)), [@NOME: dica], ((DIAS DESDE @NOME)).
 * Todo texto do modelo entra na tela por textContent (nunca por innerHTML): o texto pode vir de um arquivo de terceiros.
 *
 * Este arquivo tem o estado do criador aberto (ed), as janelinhas, a barra de botões e as peças compartilhadas (P._ed). O resto fica em arquivos
 * pequenos que registram suas funções em P._ed (carregue-os DEPOIS deste, nesta ordem):
 *   personalizados-editor-abrir.js  abrir / fechar / salvar e a montagem da tela do criador (P.abrirEditor)
 *   personalizados-marcar.js    achar marcações e os botões que marcam o texto
 *   personalizados-dialogos.js  janelinhas "Escolha entre opções" e "Contar dias"
 *   personalizados-previa.js    prévia "Como vai ficar" e mensagens de problemas
 *   personalizados-ajuda.js     tabela de comandos, seção da IA e limpeza do texto colado
 *   personalizados-inicio.js    tela de início do criador e o que cada botão dela faz (comecar, recomecar)
 * Uma função de outro arquivo é chamada por PE.nome() (PE = P._ed) na hora de usar; só se guarda antes (var x = PE.x) o que um
 * arquivo carregado ANTES já registrou. O estado do criador aberto é PE.estado() (nulo se fechado): quem o usa lê no início da função.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var ed = null;   // estado do criador aberto (null = fechado)

  var el = P.el;
  function botao(classe, icone, texto, aoClicar) {
    var b = el("button", classe); b.type = "button";
    if (icone) { var i = el("span", "ic", icone); i.setAttribute("aria-hidden", "true"); b.appendChild(i); }
    b.appendChild(el("span", "tx", texto));
    b.addEventListener("click", aoClicar);
    return b;
  }
  var semBarras = function (s) { return String(s).replace(/\\([\[\]*{}\\()])/g, "$1"); };

  // Enquanto uma janela está aberta, o resto da página fica "desligado" (não recebe clique nem Tab)
  P.travarFundo = function (sim) {
    Array.prototype.forEach.call(document.querySelectorAll("body > header, #ferramentas, .layout, body > footer"), function (x) { x.inert = !!sim; });
    document.body.classList.toggle("janela-aberta", !!sim);
  };

  // Compila com um pequeno cache (a prévia, os botões e as mensagens usam o mesmo resultado)
  var cacheC = { t: null, r: null };
  function compilarCache(t) {
    if (cacheC.t !== t) cacheC = { t: t, r: P.compilar(t) };
    return cacheC.r;
  }

  // ---------- escrever na caixa de texto mantendo o Ctrl+Z ----------
  // desloc (opcional): onde deixar o cursor, em relação ao fim do texto inserido (ex.: -2 = dois caracteres antes do fim)
  function substituir(a, b, novo, desloc) {
    var ta = ed.ta, antes = ta.value, esperado = antes.slice(0, a) + novo + antes.slice(b), ok = false;
    ta.focus(); ta.setSelectionRange(a, b);
    try { ok = novo === "" ? (a === b || document.execCommand("delete")) : document.execCommand("insertText", false, novo); } catch (e) { ok = false; }
    if (!ok || ta.value !== esperado) {       // plano B: não guarda no histórico do Ctrl+Z, mas funciona sempre
      ta.value = esperado;
      ta.dispatchEvent(new Event("input", { bubbles: true }));
    }
    var fim = a + novo.length + (desloc || 0);
    ta.setSelectionRange(fim, fim);
    ta.focus();
    clearTimeout(tempoMudar); aoMudar();       // depois de um botão a prévia atualiza na hora
  }

  function dica(msg) {
    ed.dica.textContent = msg;
    clearTimeout(ed.tDica);
    if (msg) ed.tDica = setTimeout(function () { ed.dica.textContent = ""; }, 7000);
  }

  // Tira da caixa os caracteres invisíveis que o compilador removeria (assim as posições do texto continuam certas)
  function limparTextarea() {
    var ta = ed.ta, v = P.limpar(ta.value);
    if (v !== ta.value) { var a = Math.min(ta.selectionStart, v.length), b = Math.min(ta.selectionEnd, v.length); ta.value = v; ta.setSelectionRange(a, b); }
  }

  // ---------- janelinhas (diálogos) ----------
  // Cria a janelinha, trava o fundo e devolve { fundo, caixa, fechar }. aoFechar roda depois de fechar.
  function janelinha(idTitulo, titulo, larga) {
    var fundo = el("div", "modal-pers dlg-pers"), caixa = el("div", "dlg-caixa" + (larga ? " dlg-larga" : ""));
    fundo.setAttribute("role", "dialog"); fundo.setAttribute("aria-modal", "true"); fundo.setAttribute("aria-labelledby", idTitulo);
    var h = el("h2", "", titulo); h.id = idTitulo;
    var corpoJ = el("div", "dlg-corpo");        // só o miolo rola; título e botões ficam sempre à vista, sem cobrir nada
    caixa.appendChild(h); caixa.appendChild(corpoJ); fundo.appendChild(caixa);
    var j = { fundo: fundo, caixa: caixa, corpo: corpoJ };
    function tecla(e) { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); j.fechar(); } }
    j.fechar = function () {
      document.removeEventListener("keydown", tecla, true);
      fundo.remove(); if (ed) { ed.raiz.inert = false; if (!(P.Visual && P.Visual.voltarDoDialogo())) ed.ta.focus(); }
    };
    j.abrir = function () {
      ed.raiz.inert = true;
      document.body.appendChild(fundo);
      document.addEventListener("keydown", tecla, true);
      fundo.addEventListener("keydown", function (e) {      // Tab não sai da janelinha
        if (e.key !== "Tab" || e.altKey || e.ctrlKey) return;
        var foc = Array.prototype.filter.call(fundo.querySelectorAll("button, input, select, textarea, summary"), function (x) { return !x.disabled && x.offsetParent !== null; });
        if (!foc.length) return;
        var p = foc.indexOf(document.activeElement);
        if (e.shiftKey && p <= 0) { e.preventDefault(); foc[foc.length - 1].focus(); }
        else if (!e.shiftKey && p === foc.length - 1) { e.preventDefault(); foc[0].focus(); }
      });
    };
    return j;
  }

  // Acha, pelo cursor, a escolha ([A / B] ou [? ...]) que o botão deve abrir. Devolve null | {nativo:true} | {idx}
  function acharAlvo(E, a, b, estrito) {
    var k, c, s, r = null;
    for (k = 0; k < E.escolhas.length && !r; k++) { c = E.escolhas[k]; if (c.ini <= a && b <= c.fim && a < c.fim) r = c.nativo ? { nativo: true } : { idx: k }; }
    for (k = 0; k < E.ses.length && !r; k++) { s = E.ses[k]; if (s.ini <= a && b <= s.fim && a < s.fim) r = E.escolhas[s.dono].nativo ? { nativo: true } : { idx: s.dono }; }
    if (!r && a === b && !estrito) {
      for (k = 0; k < E.escolhas.length && !r; k++) { c = E.escolhas[k]; if (c.fim === a) r = c.nativo ? { nativo: true } : { idx: k }; }
      for (k = 0; k < E.ses.length && !r; k++) { s = E.ses[k]; if (s.fim === a) r = E.escolhas[s.dono].nativo ? { nativo: true } : { idx: s.dono }; }
    }
    return r;
  }

  function atualizarBotoes() {       // os botões que precisam de seleção ficam "apagados" enquanto nada está selecionado
    if (!ed) return;       // a janela já fechou (o navegador ainda avisa "blur" ao remover a caixa)
    var espera = semAlvo();
    ed.barra.classList.toggle("ep-barra-espera", espera);      // modo Blocos sem bloco aberto: a barra mostra uma mensagem no lugar dos botões
    if (espera) {
      ed.todosBts.forEach(function (b) { b.classList.add("aguarda"); });
      ed.bOpcoes.querySelector(".tx").textContent = "Escolha entre opções";
      ed.bEspaco.querySelector(".tx").textContent = "Espaço para preencher";
      return;
    }
    ed.todosBts.forEach(function (b) { if (ed.precisaSel.indexOf(b) === -1 && b !== ed.bOpcoes && b !== ed.bEspaco) b.classList.remove("aguarda"); });
    var a0 = ed.ta.selectionStart, b0 = ed.ta.selectionEnd, tem = a0 !== b0, dentro = false;
    var al = acharAlvo(compilarCache(ed.ta.value).estrutura, a0, b0, true);
    dentro = !!(al && !al.nativo);
    var sp = P.Espaco ? P.Espaco.achar(ed.ta.value, a0, b0) : null, dentroEsp = !!(sp && sp.ok);
    ed.precisaSel.forEach(function (b) { b.classList.toggle("aguarda", !tem); });
    ed.bEspaco.classList.toggle("aguarda", !tem && !dentroEsp);
    ed.bEspaco.querySelector(".tx").textContent = dentroEsp ? "Mudar este espaço" : "Espaço para preencher";
    ed.bOpcoes.classList.toggle("aguarda", !tem && !dentro);
    ed.bOpcoes.querySelector(".tx").textContent = dentro ? "Mudar esta escolha" : "Escolha entre opções";
  }
  function aoMudar() { PE.atualizarPrevia(); PE.atualizarProblemas(); atualizarBotoes(); if (P.Rascunho) P.Rascunho.agendar(); }
  var tempoMudar;
  function agendar() { clearTimeout(tempoMudar); tempoMudar = setTimeout(function () { if (ed) aoMudar(); }, 100); }

  // ---------- passos do topo (mudam com o modo) ----------
  var PASSOS = {
    texto: ["Escreva ou cole a evolução", "Selecione o que muda e escolha o que vira", "Confira o texto final à direita e salve"],
    blocos: ["Clique num bloco ou em ＋ Adicionar bloco", "Marque o que muda (botões, botão direito ou !)", "Arraste ⋮⋮ para mudar a ordem"]
  };
  function definirPassos(modo) {
    var ol = ed.passos;
    ol.textContent = "";
    PASSOS[modo === "blocos" ? "blocos" : "texto"].forEach(function (p) { ol.appendChild(el("li", "", p)); });
  }

  // ---------- abrir / fechar ----------
  function sujo() { return !!ed && (ed.nome.value !== ed.nome0 || ed.master.value !== ed.texto0); }
  P.editorSujo = sujo;
  P.editorAberto = function () { return !!ed; };


  // No modo Blocos, ed.ta é a caixa do bloco aberto; sem bloco aberto, é o texto inteiro (ed.master), escondido
  function semAlvo() { return ed.modo === "blocos" && ed.ta === ed.master; }

  // Peças do criador, compartilhadas com o modo Blocos e com os outros arquivos personalizados-*.js.
  // Os outros arquivos acrescentam as suas (marcadores, selecao, dialogoOpcoes, atualizarPrevia, comecar...).
  var PE = P._ed = {
    estado: function () { return ed; }, el: el, botao: botao, dica: dica, atualizarBotoes: atualizarBotoes, agendar: agendar, aoMudar: aoMudar,
    definirPassos: definirPassos, janelinha: janelinha, substituir: substituir, limparTextarea: limparTextarea,
    compilarCache: compilarCache, acharAlvo: acharAlvo, semBarras: semBarras, sujo: sujo, semAlvo: semAlvo,
    definirEstado: function (x) { ed = x; },                  // chamado por estadoNovo() em personalizados-editor-abrir.js
    cancelarAgenda: function () { clearTimeout(tempoMudar); }
  };

})();
