﻿# Instala ou atualiza o app neste computador e cria o atalho na área de trabalho.
# Chamado por "INSTALAR OU ATUALIZAR.bat". Não instala nada de sistema.
# Parâmetros opcionais (usados em testes): -Destino, -AreaDeTrabalho, -Perfil, -PastaDownloads.
param(
  [string]$Destino,
  [string]$AreaDeTrabalho,
  [string]$Perfil,
  [string]$PastaDownloads
)

try {
$ErrorActionPreference = "Stop"
$nome = "Modelos de Evolução"   # nome do atalho (troque aqui se renomear o app)

$origem = Split-Path $PSScriptRoot -Parent
foreach ($item in "ABRIR.html", "app", "modelos") {
  if (-not (Test-Path (Join-Path $origem $item))) { throw "Falta '$item' na pasta de origem ($origem). Copie a pasta inteira do app." }
}

# Padrões (o usuário não precisa informar nada)
if (-not $Perfil) { $Perfil = Join-Path $env:LOCALAPPDATA "ModelosEvolucao\perfil-navegador" }
if (-not $AreaDeTrabalho) { $AreaDeTrabalho = [Environment]::GetFolderPath("Desktop") }
if (-not $PastaDownloads) { $PastaDownloads = Join-Path $env:USERPROFILE "Downloads" }

# 1) Pasta de destino no computador (se o atalho apontasse para o pendrive, quebraria ao remover o pendrive
#    ou quando o Windows trocar a letra da unidade)
if ($Destino) { New-Item -ItemType Directory -Force $Destino | Out-Null }
else {
  $Destino = "C:\ModelosEvolucao"
  try { New-Item -ItemType Directory -Force $Destino | Out-Null }
  catch {
    $Destino = Join-Path $env:USERPROFILE "ModelosEvolucao"
    New-Item -ItemType Directory -Force $Destino | Out-Null
  }
}
$Destino = (Resolve-Path -LiteralPath $Destino).ProviderPath.TrimEnd("\")
if ($origem.TrimEnd("\") -ieq $Destino) { throw "O instalador precisa ser executado a partir do pendrive (ou da pasta da nova versao), nao da pasta instalada." }

$pagina = Join-Path $Destino "ABRIR.html"
$atualizacao = Test-Path -LiteralPath $pagina
Write-Host ""
if ($atualizacao) { Write-Host "Atualizando o app em: $Destino" } else { Write-Host "Instalando o app em: $Destino" }

# 2) Se a janela do app estiver aberta, pede para fechar (senão o navegador segura arquivos e a atualização falha)
function Achar-JanelaAberta {
  try {
    $p = $Perfil.TrimEnd("\")
    @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe' OR Name='chrome.exe'" |
      Where-Object { $_.CommandLine -and $_.CommandLine.IndexOf($p, [StringComparison]::OrdinalIgnoreCase) -ge 0 })
  } catch { @() }
}
$tentativas = 0
while (@(Achar-JanelaAberta).Count -gt 0) {
  $tentativas++
  if ($tentativas -gt 10) { throw "A janela do app continua aberta. Feche-a e rode de novo." }
  Write-Host ""
  Read-Host "Feche a janela do app Modelos de Evolucao e pressione Enter" | Out-Null
}

# 3) Copia SÓ o que o app precisa (ABRIR.html, app\ sem este instalador, modelos\).
#    Primeiro numa pasta provisória; só depois troca o que havia (se a cópia falhar, a versão antiga continua intacta).
#    NUNCA toca em meus-modelos\ nem no perfil do navegador.
$novo = Join-Path $Destino "_novo"
if (Test-Path -LiteralPath $novo) { Remove-Item -LiteralPath $novo -Recurse -Force }
New-Item -ItemType Directory $novo | Out-Null
Copy-Item -LiteralPath (Join-Path $origem "ABRIR.html") -Destination $novo
Copy-Item -LiteralPath (Join-Path $origem "app") -Destination (Join-Path $novo "app") -Recurse
Copy-Item -LiteralPath (Join-Path $origem "modelos") -Destination (Join-Path $novo "modelos") -Recurse
$ps1Copiado = Join-Path $novo "app\instalar-atalho.ps1"
if (Test-Path -LiteralPath $ps1Copiado) { Remove-Item -LiteralPath $ps1Copiado -Force }
# arquivos do atualizador automático nunca ficam em app\ (vão, se a função estiver ligada, para atualizador\)
foreach ($extra in "atualizar.ps1", "atualizacao.json", "atualizacao-chave.xml") {
  $copiado = Join-Path $novo "app\$extra"
  if (Test-Path -LiteralPath $copiado) { Remove-Item -LiteralPath $copiado -Force }
}

# troca completa: apaga o que era velho (não sobram arquivos antigos) e coloca o novo
foreach ($velho in "ABRIR.html", "app", "modelos") {
  $v = Join-Path $Destino $velho
  if (Test-Path -LiteralPath $v) { Remove-Item -LiteralPath $v -Recurse -Force }
}
# sobras de instalações antigas, que copiavam tudo
Get-ChildItem -LiteralPath $Destino -File -Force | Where-Object { $_.Name -in "LEIA-ME.txt", "TERMOS-DE-USO.txt" -or $_.Name -like "*.bat" -or $_.Name -like "GUIA*.pdf" } |
  Remove-Item -Force
Get-ChildItem -LiteralPath $novo -Force | Move-Item -Destination $Destino
Remove-Item -LiteralPath $novo -Recurse -Force

# 4) Pasta dos modelos do usuário (cópias de segurança)
$pastaModelos = Join-Path $Destino "meus-modelos"
New-Item -ItemType Directory -Force $pastaModelos | Out-Null

# 5) Perfil do navegador: downloads do app caem em meus-modelos sem perguntar (se falhar, segue: vão para Downloads)
try {
  $defaultDir = Join-Path $Perfil "Default"
  New-Item -ItemType Directory -Force $defaultDir | Out-Null
  $arqPrefs = Join-Path $defaultDir "Preferences"
  Add-Type -AssemblyName System.Web.Extensions
  $js = New-Object System.Web.Script.Serialization.JavaScriptSerializer
  $js.MaxJsonLength = [int]::MaxValue
  $js.RecursionLimit = 200
  $prefs = $null
  if (Test-Path -LiteralPath $arqPrefs) {
    $bruto = [IO.File]::ReadAllText($arqPrefs)
    if ($bruto.Trim()) { $prefs = $js.DeserializeObject($bruto) }
  }
  if ($prefs -isnot [System.Collections.IDictionary]) { $prefs = [System.Collections.Generic.Dictionary[string,object]]::new() }
  function Pegar-Filho($pai, $chave) {
    if (-not $pai.ContainsKey($chave) -or $pai[$chave] -isnot [System.Collections.IDictionary]) {
      $pai[$chave] = [System.Collections.Generic.Dictionary[string,object]]::new()
    }
    return ,$pai[$chave]
  }
  $dl = Pegar-Filho $prefs "download"
  $dl["default_directory"] = [string]$pastaModelos
  $dl["prompt_for_download"] = $false
  $dl["directory_upgrade"] = $true
  $sf = Pegar-Filho $prefs "savefile"
  $sf["default_directory"] = [string]$pastaModelos
  $pf = Pegar-Filho $prefs "profile"
  $cs = Pegar-Filho $pf "content_settings"
  $ex = Pegar-Filho $cs "exceptions"
  $ad = Pegar-Filho $ex "automatic_downloads"
  $regra = [System.Collections.Generic.Dictionary[string,object]]::new()
  $regra["setting"] = 1
  $ad["file:///*,*"] = $regra
  $json = $js.Serialize($prefs)
  [void]$js.DeserializeObject($json)    # confere que o JSON é válido antes de gravar
  [IO.File]::WriteAllText($arqPrefs, $json, (New-Object System.Text.UTF8Encoding($false)))
} catch {
  Write-Host "Aviso: nao foi possivel configurar a pasta dos arquivos salvos. Eles irao para a pasta Downloads." -ForegroundColor Yellow
  Write-Host "  ($($_.Exception.Message))" -ForegroundColor DarkGray
}

# 6) recuperar.js: a cópia de segurança mais recente, para o app oferecer recuperar os modelos se sumirem
try {
  $cand = $null
  foreach ($pasta in $pastaModelos, $PastaDownloads) {
    if (-not $cand -and (Test-Path -LiteralPath $pasta)) {
      $cand = Get-ChildItem -LiteralPath $pasta -Filter "copia-seguranca-modelos*.txt" -File |
        Sort-Object LastWriteTime, Name -Descending | Select-Object -First 1
    }
  }
  if ($cand) {
    $txt = [IO.File]::ReadAllText($cand.FullName).Replace([string][char]0xFEFF, "")
    $j = ConvertTo-Json -InputObject $txt
    $j = [regex]::Replace($j, "[^\x20-\x7E]", { param($m) "\u{0:x4}" -f [int][char]$m.Value })   # só ASCII: sem problema de codificação
    [IO.File]::WriteAllText((Join-Path $pastaModelos "recuperar.js"), "window.COPIA_MODELOS = $j;`r`n", (New-Object System.Text.UTF8Encoding($false)))
  }
} catch {
  Write-Host "Aviso: nao foi possivel preparar a recuperacao automatica dos modelos." -ForegroundColor Yellow
}

# 7) Mantém só as 30 cópias de segurança mais recentes (recuperar.js não conta)
try {
  Get-ChildItem -LiteralPath $pastaModelos -Filter "copia-seguranca-modelos*.txt" -File |
    Sort-Object LastWriteTime, Name -Descending | Select-Object -Skip 30 | Remove-Item -Force
} catch { }

# 8) Abre como "janela de aplicativo" (sem barra de endereço) no Edge ou Chrome, se existirem
$url = "file:///" + ($pagina -replace "\\", "/")
$navegadores = @(
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
)
$nav = $navegadores | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1

# Perfil próprio do navegador para o app: abre sempre uma instância nova, que respeita o
# "--start-maximized" (com o perfil normal, o Edge fica rodando em segundo plano e ignora a instrução).
# --disable-background-mode: ao fechar a janela o navegador do app encerra de verdade (não fica ocupando memória)
# (os mesmos argumentos servem ao atalho direto e ao atualizador automático)
$argsNavegador = "--app=`"$url`" --start-maximized --user-data-dir=`"$Perfil`" --no-first-run --no-default-browser-check --disable-background-mode"

# 8b) Atualizador automático (DESLIGADO por padrão: app\atualizacao.json da origem com "ativa": true liga).
#     Desligado = nada disto existe no computador e o atalho abre o navegador direto, como sempre.
$pastaAtu = Join-Path $Destino "atualizador"
$usarAtualizador = $false
$cfgAtu = $null
try { $cfgAtu = [IO.File]::ReadAllText((Join-Path $origem "app\atualizacao.json"), [Text.Encoding]::UTF8).TrimStart([char]0xFEFF) | ConvertFrom-Json } catch { $cfgAtu = $null }
if ($cfgAtu -and $cfgAtu.ativa -is [bool] -and $cfgAtu.ativa -eq $true) {
  $chaveOrigem = Join-Path $origem "app\atualizacao-chave.xml"
  $manifestoAtu = [string]$cfgAtu.manifesto
  try {
    if (-not (Test-Path -LiteralPath $chaveOrigem)) { throw "falta a chave publica (app\atualizacao-chave.xml); rode publicar\gerar-chaves.ps1" }
    if (-not $manifestoAtu.StartsWith("https://", [StringComparison]::OrdinalIgnoreCase)) { throw "o endereco em atualizacao.json precisa comecar com https://" }
    if ($manifestoAtu -match "USUARIO/REPOSITORIO") { throw "troque USUARIO/REPOSITORIO pelo endereco real em atualizacao.json" }
    if (Test-Path -LiteralPath $pastaAtu) { Remove-Item -LiteralPath $pastaAtu -Recurse -Force }
    New-Item -ItemType Directory -Force $pastaAtu | Out-Null
    Copy-Item -LiteralPath (Join-Path $origem "app\atualizar.ps1") -Destination $pastaAtu
    Copy-Item -LiteralPath (Join-Path $origem "app\atualizacao.json") -Destination $pastaAtu
    Copy-Item -LiteralPath $chaveOrigem -Destination $pastaAtu
    $lancarObj = [ordered]@{ navegador = $(if ($nav) { [string]$nav } else { $null }); argumentos = $(if ($nav) { $argsNavegador } else { $null }); pagina = [string]$pagina }
    [IO.File]::WriteAllText((Join-Path $pastaAtu "lancar.json"), (ConvertTo-Json -InputObject $lancarObj), (New-Object System.Text.UTF8Encoding($false)))
    $psExe = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
    & $psExe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $pastaAtu "atualizar.ps1") -Verificar
    if ($LASTEXITCODE -ne 0) { throw "o teste do atualizador nao passou" }
    $usarAtualizador = $true
  } catch {
    Write-Host "Aviso: a atualizacao automatica nao foi ativada ($($_.Exception.Message)). O atalho abrira o app direto." -ForegroundColor Yellow
    try { if (Test-Path -LiteralPath $pastaAtu) { Remove-Item -LiteralPath $pastaAtu -Recurse -Force } } catch { }
  }
}
elseif (Test-Path -LiteralPath $pastaAtu) {
  try { Remove-Item -LiteralPath $pastaAtu -Recurse -Force } catch { }   # função desligada = atualizador desinstalado
}

# 9) Cria o atalho na área de trabalho
New-Item -ItemType Directory -Force $AreaDeTrabalho | Out-Null
$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut((Join-Path $AreaDeTrabalho "$nome.lnk"))
if ($usarAtualizador) {
  $lnk.TargetPath = $psExe
  $lnk.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $pastaAtu 'atualizar.ps1')`""
  $lnk.WindowStyle = 7   # 7 = minimizado (o atualizador abre o app em seguida)
}
else {
  if ($nav) {
    $lnk.TargetPath = $nav
    $lnk.Arguments = $argsNavegador
  }
  else { $lnk.TargetPath = $pagina }
  $lnk.WindowStyle = 3   # 3 = abrir maximizado
}
$lnk.IconLocation = (Join-Path $Destino "app\icone.ico") + ",0"
$lnk.Description = "Modelos de evolução — criado por Raphael Bastos Palitot de Brito"
$lnk.Save()

Write-Host ""
if ($atualizacao) { Write-Host "Pronto! Atualizacao concluida." -ForegroundColor Green }
else { Write-Host "Pronto! Instalacao concluida. Atalho 'Modelos de Evolucao' criado na area de trabalho." -ForegroundColor Green }
Write-Host "Seus modelos foram mantidos."
Write-Host "O app esta em: $Destino"
Write-Host "As copias de seguranca dos seus modelos ficam em: $pastaModelos"
exit 0

} catch {
  Write-Host ""
  Write-Host "ERRO: $($_.Exception.Message)" -ForegroundColor Red
  exit 1
}
