/*
 * Aviso de versão nova ("só avisar"). DESLIGADO por padrão: com CONFIG.ativo diferente de true
 * este arquivo não faz NADA (nenhum acesso à rede, nenhum elemento, nenhuma gravação).
 * Ligado: no máximo 1 consulta bem-sucedida por dia a um arquivo público com o número da versão mais recente.
 * Nada é baixado nem instalado: o cartão só mostra o número e leva ao site (CONFIG.site). Nenhum texto da internet
 * é exibido além do número validado; o link NUNCA vem da internet. Não envia dados de pacientes, modelos nem identificação.
 */
(function () {
  "use strict";
  var CONFIG = {
    ativo: false,                         // LIGAR SÓ COM ORDEM DO AUTOR
    manifesto: "https://raw.githubusercontent.com/USUARIO/REPOSITORIO/main/versao-atual.json",
    site: "https://github.com/USUARIO/REPOSITORIO/releases/latest"
  };

  // Só para teste: window.AVISO_VERSAO_TESTE = {manifesto, site, hoje, atraso} definido ANTES deste script.
  var TESTE = window.AVISO_VERSAO_TESTE, teste = !!TESTE && typeof TESTE === "object";
  if (!teste && CONFIG.ativo !== true) return;
  var cfg = teste ? { manifesto: String(TESTE.manifesto || ""), site: String(TESTE.site || "") } : CONFIG;
  var RE_LOCAL = /^http:\/\/(127\.0\.0\.1|localhost)(:\d{1,5})?\//;
  function enderecoOk(u) {
    return typeof u === "string" && u.indexOf("USUARIO/REPOSITORIO") < 0 && (/^https:\/\//.test(u) || (teste && RE_LOCAL.test(u)));
  }
  if (!enderecoOk(cfg.manifesto) || !enderecoOk(cfg.site)) return;

  var RE_VER = /^\d{1,3}(\.\d{1,3}){0,3}$/, RE_DIA = /^\d{4}-\d{2}-\d{2}$/;
  var CHAVE = "modelosEvolucao.avisoVersao.v1", MAX = 4096;
  var APP = window.APP_VERSAO;
  if (typeof APP !== "string" || !RE_VER.test(APP)) return;

  var novaVersao = null, card = null, timer = null, obs = null, adiar = null, fechado = false, iniciado = false, ultimoFoco = null;

  function maior(a, b) {            // a > b, comparando número por número
    var x = a.split("."), y = b.split(".");
    for (var i = 0; i < 4; i++) { var p = +(x[i] || 0), q = +(y[i] || 0); if (p !== q) return p > q; }
    return false;
  }
  function texto(v, re) { return typeof v === "string" && re.test(v) ? v : null; }
  function hoje() {
    if (teste && texto(TESTE.hoje, RE_DIA)) return TESTE.hoje;
    var d = new Date(), z = function (n) { return (n < 10 ? "0" : "") + n; };
    return d.getFullYear() + "-" + z(d.getMonth() + 1) + "-" + z(d.getDate());
  }

  // ---- o único dado guardado: data da última consulta, versão vista, versão pulada, dia do "Agora não" ----
  function ler() {
    var r = { ultima: null, versaoVista: null, pular: null, agoraNao: null };
    try {
      var o = JSON.parse(localStorage.getItem(CHAVE) || "null");
      if (o && typeof o === "object") {
        r.ultima = texto(o.ultima, RE_DIA); r.agoraNao = texto(o.agoraNao, RE_DIA);
        r.versaoVista = texto(o.versaoVista, RE_VER); r.pular = texto(o.pular, RE_VER);
      }
    } catch (e) {}
    return r;
  }
  function gravar(mudancas) {
    var s = ler();
    for (var k in mudancas) s[k] = mudancas[k];
    try { localStorage.setItem(CHAVE, JSON.stringify(s)); } catch (e) {}
  }
  function deveAvisar(v, s) {       // versão maior que a do app e (se pulou alguma) maior que a pulada
    return !!v && maior(v, APP) && (!s.pular || maior(v, s.pular)) && s.agoraNao !== hoje();
  }

  // ---- consulta (resposta de no máximo 4 KB, 5 s, sem cookies nem referência) ----
  function lerLimitado(r) {
    if (+r.headers.get("content-length") > MAX) throw new Error("grande");
    if (!r.body || !r.body.getReader) return r.text().then(function (s) { if (s.length > MAX) throw new Error("grande"); return s; });
    var rd = r.body.getReader(), dec = new TextDecoder("utf-8"), total = 0, s = "";
    function passo() {
      return rd.read().then(function (x) {
        if (x.done) return s + dec.decode();
        total += x.value.length;
        if (total > MAX) { rd.cancel(); throw new Error("grande"); }
        s += dec.decode(x.value, { stream: true });
        return passo();
      });
    }
    return passo();
  }
  function consultar() {            // devolve a versão (validada) ou null em qualquer falha
    var ctl = new AbortController(), t = setTimeout(function () { ctl.abort(); }, 5000);
    return fetch(cfg.manifesto, { cache: "no-store", credentials: "omit", referrerPolicy: "no-referrer", signal: ctl.signal })
      .then(function (r) { if (!r.ok) throw new Error("http"); return lerLimitado(r); })
      .then(function (txt) {
        clearTimeout(t);
        var o = JSON.parse(txt);
        return texto(o && o.versao, RE_VER);
      }, function () { clearTimeout(t); return null; })
      ["catch"](function () { return null; });
  }

  // ---- quando mostrar ----
  function ocupado() {
    var d = document, b = d.body, te = d.getElementById("termos-tela"), pe = d.getElementById("pergunta-tela");
    return !te || !pe || !te.hidden || !pe.hidden || b.classList.contains("no-inicio") || b.classList.contains("em-teste") ||
      !!d.querySelector(".modal-pers:not([hidden]), .menu-contexto, aside.ampliado") ||
      !!(window.Motor && window.Motor.emTeste && window.Motor.emTeste());
  }
  function agendar(v) {
    novaVersao = v;
    if (!timer) {
      timer = setInterval(tick, 1000);
      obs = new MutationObserver(function () { clearTimeout(adiar); adiar = setTimeout(tick, 60); });   // reage logo a janelas/telas abrindo e fechando
      obs.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["hidden", "class"] });
      window.addEventListener("scroll", posicionar, { passive: true });
      window.addEventListener("resize", posicionar);
    }
    tick();
  }
  function tick() {
    if (fechado) return parar();
    if (ocupado()) { if (card) card.hidden = true; return; }
    if (!card) card = montar();
    card.hidden = false;
    posicionar();
  }
  function parar() {
    clearInterval(timer); clearTimeout(adiar); timer = null;
    if (obs) obs.disconnect();
    window.removeEventListener("scroll", posicionar); window.removeEventListener("resize", posicionar);
  }
  // Fica no canto inferior direito; se ali cobriria o botão de copiar, as abas, o aviso de pendentes ou o rodapé, sobe até ficar acima deles
  var NAO_COBRIR = ["#abas-saida", "#btn-copiar", "#status-copia", "#pendentes", "footer"];
  function posicionar() {
    if (!card || card.hidden) return;
    var vh = window.innerHeight, base = 16;
    card.style.bottom = base + "px";
    for (var volta = 0; volta < 2; volta++) {
      var k = card.getBoundingClientRect();
      NAO_COBRIR.forEach(function (sel) {
        var e = document.querySelector(sel);
        if (!e || !e.getClientRects().length) return;
        var r = e.getBoundingClientRect();
        if (r.bottom > k.top && r.top < k.bottom && r.right > k.left && r.left < k.right) base = Math.max(base, vh - r.top + 8);
      });
      base = Math.min(base, vh - k.height - 8);
      card.style.bottom = base + "px";
    }
  }

  function fechar() {
    fechado = true; parar();
    if (!card) return;
    var tinhaFoco = card.contains(document.activeElement);
    card.parentNode.removeChild(card); card = null;
    if (!tinhaFoco) return;
    var volta = ultimoFoco && document.contains(ultimoFoco) ? ultimoFoco : document.getElementById("btn-copiar");
    if (volta && volta.focus) volta.focus({ preventScroll: true });
  }

  function botao(rotulo, classe, aoClicar) {
    var b = document.createElement("button");
    b.type = "button"; b.className = classe; b.textContent = rotulo;
    b.addEventListener("click", aoClicar);
    return b;
  }
  function montar() {
    var c = document.createElement("div"), p = document.createElement("p"), bts = document.createElement("div");
    c.className = "aviso-versao"; c.setAttribute("role", "region"); c.setAttribute("aria-label", "Versão nova do app");
    p.className = "aviso-texto";
    p.textContent = "Há uma versão nova do app (" + novaVersao + "). A sua é a " + APP + ".";
    bts.className = "aviso-botoes";
    bts.appendChild(botao("Ir para o site", "aviso-ir", function () {
      try { window.open(cfg.site, "_blank", "noopener,noreferrer"); } catch (e) {}
      fechar();                                         // só nesta sessão: nada é gravado
    }));
    bts.appendChild(botao("Agora não", "aviso-agora", function () { gravar({ agoraNao: hoje() }); fechar(); }));
    bts.appendChild(botao("Pular esta atualização", "aviso-pular", function () { gravar({ pular: novaVersao }); fechar(); }));
    c.appendChild(p); c.appendChild(bts);
    c.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); gravar({ agoraNao: hoje() }); fechar(); return; }
      // Enter/Espaço/números com o foco no cartão não devem acionar os atalhos do app por trás
      if (e.key !== "Tab" && !e.ctrlKey && !e.altKey && !e.metaKey) e.stopPropagation();
    });
    document.body.appendChild(c);
    return c;
  }

  function decidir() {
    var s = ler(), h = hoje();
    if (s.ultima === h) { if (deveAvisar(s.versaoVista, s)) agendar(s.versaoVista); return; }   // já consultou hoje
    consultar().then(function (v) {
      if (!v) return;                                   // falha: não grava a data (tenta de novo na próxima abertura)
      gravar({ ultima: h, versaoVista: v });
      if (deveAvisar(v, ler())) agendar(v);
    });
  }

  function iniciar() {              // depois dos Termos aceitos, com um pequeno atraso para não competir com a abertura
    if (iniciado) return;
    iniciado = true;
    setTimeout(decidir, teste && typeof TESTE.atraso === "number" ? TESTE.atraso : 3000);
  }

  document.addEventListener("focusin", function (e) {
    if (!card || !card.contains(e.target)) ultimoFoco = e.target;
  });
  var te = document.getElementById("termos-tela");
  if (te && te.hidden) iniciar();
  else document.addEventListener("termosaceitos", iniciar);
})();
