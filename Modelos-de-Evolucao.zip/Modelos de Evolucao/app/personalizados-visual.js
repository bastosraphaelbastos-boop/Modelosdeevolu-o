/*
 * Evoluções personalizadas — modo "Escrevendo o texto" do criador: editor VISUAL (como o Notion).
 * À esquerda o modelo aparece como vai ficar (espaços amarelos, escolhas como botões, títulos destacados) e se escreve
 * direto nele. As marcações ([dica], [A / B], *texto*, ((SE ...)), ...) aparecem como "pedaços" que não se partem:
 * clicar abre o que muda aquele pedaço; Backspace/Delete apagam o pedaço inteiro; botão direito mostra as opções.
 *
 * Fonte única: o texto do modelo continua em ed.master (uma caixa de texto invisível). Este editor NÃO deixa o navegador
 * mexer no HTML: cada digitação (beforeinput) vira uma troca de texto em ed.master e as linhas mudadas são redesenhadas.
 * Os botões e janelinhas do criador continuam trabalhando em ed.master; quando ele muda, o editor se redesenha.
 * Ctrl+Z / Ctrl+Y têm histórico próprio. Todo texto do modelo entra na tela por textContent.
 * Carregue depois de personalizados-blocos-base.js e antes de personalizados-blocos.js. Este arquivo tem o estado (st), o desenho das linhas e o
 * cursor (tela <-> texto do modelo). Partes (carregue nesta ordem): personalizados-visual-edicao.js (digitação, histórico, apagar, colar, composição)
 * e personalizados-visual-montar.js (clicar num pedaço, montar o editor, ponte dos comandos). O estado só se troca por V.definirEstado(x);
 * as partes registram em V.aoMudarEstado(f) a atualização da cópia delas. O que uma parte chama da outra fica em V._f.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var V = P.Visual = {};
  var copias = [];                          // funções das outras partes que atualizam a cópia delas de st
  V.aoMudarEstado = function (f) { copias.push(f); };
  V.definirEstado = function (x) { st = x; copias.forEach(function (f) { f(x); }); };
  var I = function () { return P._ed; };
  var ed = function () { return I().estado(); };
  var ZW = "​";                        // "apoio" invisível para o cursor ao lado dos pedaços (não existe no texto do modelo)
  var ESC = V.ESC = P._reg.ESCAPAVEIS;                    // caracteres que o modelo escreve com \ (\[ \] \* ...)
  var st = null;                            // { raiz, linhas: [div], unidades: [txt], bases: [n], hist, refazer, ... }

  var el = P.el;

  // ---------- desenhar ----------
  function prefixoTitulo(u) { var m = /^#+[ \t]*/.exec(u); return m && u.charAt(0) === "#" ? m[0].length : 0; }

  // Trechos de um texto (sem o # do título) que viram pedaços: as marcações de nível de cima e os blocos [[...]]
  function pedacos(t) {
    var r = P.BlocosBase.protegidos(t).sort(function (a, b) { return a[0] - b[0] || b[1] - a[1]; }), out = [], fim = -1;
    r.forEach(function (x) { if (x[0] >= fim) { out.push(x); fim = x[1]; } });
    return out;
  }

  // Nó de texto com o mapa "posição na tela -> posição no texto do modelo" (\[ aparece como [ e ocupa 2 no modelo)
  function noTexto(cru, ri) {
    var tela = "", mapa = [], i = 0;
    while (i < cru.length) {
      mapa.push(i);
      if (cru.charAt(i) === "\\" && i + 1 < cru.length && ESC.indexOf(cru.charAt(i + 1)) !== -1) { tela += cru.charAt(i + 1); i += 2; }
      else { tela += cru.charAt(i); i++; }
    }
    mapa.push(cru.length);
    var n = document.createTextNode(tela);
    n._ri = ri; n._rf = ri + cru.length; n._mapa = mapa;
    return n;
  }
  function apoio(pos) { var n = document.createTextNode(ZW); n._ri = pos; n._rf = pos; n._mapa = [0, 0]; n._apoio = true; return n; }

  function tipoPedaco(cru) {
    if (/^\(\(\s*SE\s/i.test(cru)) return "se";
    if (/^\(\(\s*DICA\s*:/i.test(cru)) return "dica";
    if (/^\(\(\s*AVISO\s*:/i.test(cru)) return "aviso";
    if (/^\(\(\s*DIAS\s/i.test(cru)) return "dias";
    if (/^\[\[/.test(cru)) return "bloco";
    if (cru.charAt(0) === "{") return "nativo";
    if (cru.charAt(0) === "*") return "corrigivel";
    if (/^\[\?\s/.test(cru) || /^\[[^\]]*\s\/\s/.test(cru)) return "escolha";
    return "espaco";
  }
  var DICAS = {
    escolha: "Clique para mudar esta escolha", espaco: "Clique para mudar este espaço", corrigivel: "Clique para mudar o texto já escrito",
    se: "Clique para mudar a escolha de que este texto depende", dica: "Clique para mudar o lembrete", aviso: "Clique para mudar o aviso",
    dias: "Número de dias contado sozinho", bloco: "Marcação avançada (botão direito: editar como texto)", nativo: "Marcação avançada (botão direito: editar como texto)"
  };

  function pedaco(cru, ri) {
    var tp = tipoPedaco(cru), s = el("span", "wy-chip wy-" + tp);
    s.contentEditable = "false"; s._ri = ri; s._rf = ri + cru.length; s._cru = cru; s._tipo = tp;
    s.title = DICAS[tp] + " · botão direito: mais opções";
    P.BlocosBase.mostrar(cru, s);
    Array.prototype.forEach.call(s.querySelectorAll("button"), function (b) { b.tabIndex = -1; b.disabled = true; });
    return s;
  }

  function linha(u) {
    var d = el("div", "wy-linha"), pref = prefixoTitulo(u), corpo = u.slice(pref);
    d._pref = pref;
    if (pref) d.classList.add("wy-titulo");
    var ps = pedacos(corpo), pos = 0;
    ps.forEach(function (x) {
      if (x[0] > pos) d.appendChild(noTexto(corpo.slice(pos, x[0]), pos)); else d.appendChild(apoio(x[0]));
      d.appendChild(pedaco(corpo.slice(x[0], x[1]), x[0]));
      pos = x[1];
    });
    if (pos < corpo.length) d.appendChild(noTexto(corpo.slice(pos), pos));
    else if (ps.length) d.appendChild(apoio(pos));
    if (!corpo.length) d.appendChild(el("br"));
    return d;
  }

  function bases() {
    st.bases = []; var b = 0;
    st.unidades.forEach(function (u) { st.bases.push(b); b += u.length + 1; });
  }

  // Redesenha a partir de ed.master: só as linhas que mudaram, quando dá
  function desenhar() {
    var t = ed().master.value, novas = P.BlocosBase.dividir(t), r = st.raiz;
    if (novas.length === st.unidades.length && st.linhas.length === novas.length) {
      novas.forEach(function (u, i) {
        if (u !== st.unidades[i]) { var n = linha(u); r.replaceChild(n, st.linhas[i]); st.linhas[i] = n; }
      });
    } else {
      r.textContent = ""; st.linhas = novas.map(function (u) { var n = linha(u); r.appendChild(n); return n; });
    }
    st.unidades = novas; st.ultimo = t; bases();
    r.classList.toggle("wy-vazio", !t);
  }

  // ---------- cursor: tela <-> texto do modelo ----------
  function linhaDe(no) {
    while (no && no !== st.raiz) { if (no.classList && no.classList.contains("wy-linha")) return no; no = no.parentNode; }
    return null;
  }
  function paraModelo(no, off) {
    if (no === st.raiz) {
      if (off >= st.linhas.length) return ed().master.value.length;
      return st.bases[off] + st.linhas[off]._pref;
    }
    var L = linhaDe(no); if (!L) return 0;
    var i = st.linhas.indexOf(L), base = st.bases[i] + L._pref;
    var chip = no.nodeType === 1 ? no.closest(".wy-chip") : no.parentNode && no.parentNode.closest && no.parentNode.closest(".wy-chip");
    if (chip && L.contains(chip)) return base + chip._rf;
    if (no === L) {
      if (off === 0) return base;
      var c = L.childNodes[off - 1];
      return base + (c && c._rf != null ? c._rf : 0);
    }
    if (no.nodeType === 3 && no._mapa) return base + no._ri + no._mapa[Math.min(off, no._mapa.length - 1)];
    return base;
  }
  function paraTela(pos) {
    var n = st.linhas.length, i = 0;
    while (i < n - 1 && pos > st.bases[i] + st.unidades[i].length) i++;
    var L = st.linhas[i], local = Math.max(0, pos - st.bases[i] - L._pref), filhos = L.childNodes;
    for (var k = 0; k < filhos.length; k++) {
      var c = filhos[k];
      if (c.nodeType === 3 && c._mapa) {
        if (local <= c._rf) { var rel = local - c._ri, d = 0; while (d < c._mapa.length - 1 && c._mapa[d] < rel) d++; return [c, d]; }
      } else if (c._cru) {
        if (local <= c._ri) return [L, k];
        if (local < c._rf) return [L, k + 1];
      }
    }
    var ult = filhos[filhos.length - 1];
    if (ult && ult.nodeType === 3) return [ult, ult.data.length];
    return [L, ult && ult.nodeName === "BR" ? 0 : filhos.length];
  }
  function selecaoModelo() {
    var s = window.getSelection();
    if (!s.rangeCount || !st.raiz.contains(s.anchorNode)) return null;
    var r = s.getRangeAt(0), a = paraModelo(r.startContainer, r.startOffset), b = paraModelo(r.endContainer, r.endOffset);
    return { a: Math.min(a, b), b: Math.max(a, b) };
  }
  function colocarCursor(a, b) {
    var s = window.getSelection(), r = document.createRange(), p = paraTela(a);
    try {
      r.setStart(p[0], p[1]);
      if (b != null && b !== a) { var q = paraTela(b); r.setEnd(q[0], q[1]); } else r.collapse(true);
      s.removeAllRanges(); s.addRange(r);
    } catch (e) { /* posição fora: deixa como está */ }
    var no = p[0].nodeType === 3 ? p[0].parentNode : p[0];
    if (no && no.scrollIntoView) { var rr = no.getBoundingClientRect(), cx = st.raiz.getBoundingClientRect(); if (rr.top < cx.top || rr.bottom > cx.bottom) no.scrollIntoView({ block: "nearest" }); }
  }
  // Espelha a seleção da tela em ed.master (os botões do criador leem a seleção de lá)
  function espelhar() {
    var x = selecaoModelo(); if (!x) return;
    try { ed().master.setSelectionRange(x.a, x.b); } catch (e) { /* sem problema */ }
    I().atualizarBotoes();
  }

  V._f = { desenhar: desenhar, colocarCursor: colocarCursor, selecaoModelo: selecaoModelo, paraModelo: paraModelo, linhaDe: linhaDe, espelhar: espelhar };
})();
