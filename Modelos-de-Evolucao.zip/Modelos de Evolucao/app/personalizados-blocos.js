/*
 * Evoluções personalizadas — modo "Blocos" do criador de modelos (NÚCLEO).
 * Cada linha do modelo vira um bloco (cartão) que pode ser aberto para escrever, arrastado, subido/descido ou apagado,
 * e há peças prontas para acrescentar (a paleta é compartilhada com o modo Texto: personalizados-prontos.js).
 * Por baixo é o MESMO texto do modo "Texto" (ed.master): os blocos são só outra forma de ver e mexer nele, então salvar,
 * enviar e a cópia de segurança não mudam.
 * Com um bloco aberto, ed.ta aponta para a caixa dele, e os botões da barra (Espaço, Escolha...) agem só nele.
 * Seções: um título (#) pode esconder os blocos até o próximo título (só na sessão); ↑ ↓ 🗑 e arrastar num título agem
 * na seção inteira (com Shift, só o título). Erros do validador aparecem dentro do cartão do bloco que os contém.
 * Todo texto do modelo entra na tela por textContent (nunca por innerHTML).
 *
 * Este arquivo tem o ESTADO do modo (st) e o que mexe nele de dentro: texto inteiro <-> blocos, desenhar a lista, abrir/escrever num bloco
 * (teclas), ↶ Desfazer. As outras partes (carregue nesta ordem):
 *   personalizados-blocos-base.js    dividir o texto, tipo e desenho do bloco (sem estado)
 *   personalizados-blocos-secoes.js  seções que escondem blocos e erros no cartão (leem B.est())
 *   personalizados-blocos.js         ESTE arquivo
 *   personalizados-blocos-cartao.js  o cartão de um bloco e o arrastar e soltar
 *   personalizados-blocos-acoes.js   mover, apagar, peças prontas e a paleta
 *   personalizados-blocos-modo.js    trocar de modo, seletor, área da lista e o que o diálogo de opções usa (paraMestre)
 * O estado st só se troca por B.definirEstado(x): as partes registram em B.aoMudarEstado(f) a função que atualiza a cópia delas.
 * Funções de uma parte que outra chama ficam em B._f (chamadas na hora de usar).
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var B = P.Blocos = P.Blocos || {};
  var I = function () { return P._ed; };            // peças do criador (personalizados-editor.js)
  var st = null;                                     // estado do modo Blocos do criador aberto
  var copias = [];                                   // funções das outras partes que atualizam a cópia delas de st
  B.est = function () { return st; };
  B.aoMudarEstado = function (f) { copias.push(f); };
  B.definirEstado = function (x) { st = x; copias.forEach(function (f) { f(x); }); };
  var Base = P.BlocosBase, Sec = P.BlocosSecoes;
  var dividir = Base.dividir, dentro = Base.dentro, protegidos = Base.protegidos, tipo = Base.tipo;
  var donoRecolhido = Sec.donoRecolhido, garantirVisivel = Sec.garantirVisivel, aplicarErros = Sec.aplicarErros;
  var cartao = function (u, i) { return B._f.cartao(u, i); };      // personalizados-blocos-cartao.js

  function el(tag, classe, texto) { return I().el(tag, classe, texto); }
  function ed() { return I().estado(); }

  // ---------- texto inteiro <-> blocos ----------
  // st.unidades = os blocos (texto de cada um); st.fecha[i] = a seção que começa no título i está escondida (só na sessão)
  function refazer(texto, manter) {
    var antigo = st.fecha || [];
    st.unidades = dividir(texto);
    st.fecha = st.unidades.map(function (u, i) { return !!(manter && antigo[i]) && tipo(u) === "titulo"; });
  }
  // Troca n blocos a partir de i por "novos", guardando junto o estado "escondido" (o 1º bloco novo herda o do 1º antigo)
  function trocar(i, n, novos) {
    var herda = n > 0 ? !!st.fecha[i] : false;
    st.unidades.splice.apply(st.unidades, [i, n].concat(novos));
    st.fecha.splice.apply(st.fecha, [i, n].concat(novos.map(function (x, k) { return k === 0 && herda; })));
  }
  function sincronizar() {
    var e = ed();
    e.master.value = st.unidades.join("\n");
    I().agendar();
  }
  function guardar() {                               // ponto de "↶ Desfazer" (antes de mudar a estrutura ou de escrever num bloco)
    var v = ed().master.value;
    if (st.hist[st.hist.length - 1] !== v) st.hist.push(v);
    if (st.hist.length > 80) st.hist.shift();
  }
  function desfazer() {
    desativar();
    var atual = ed().master.value;
    while (st.hist.length && st.hist[st.hist.length - 1] === atual) st.hist.pop();
    if (!st.hist.length) { I().dica("Não há mais o que desfazer nos blocos."); return; }
    var v = st.hist.pop();
    ed().master.value = v; refazer(v, false);
    I().agendar(); desenhar();
    I().dica("Desfeito.");
  }

  // ---------- desenhar a lista ----------
  function desenhar(foco, cursor) {
    var lista = st.lista, escondendo = false;
    lista.textContent = "";
    st.ativo = -1; st.cta = null; ed().ta = ed().master;
    st.unidades.forEach(function (u, i) {
      var c = cartao(u, i);
      if (tipo(u) === "titulo") escondendo = !!st.fecha[i]; else if (escondendo) c.classList.add("bl-oculto");
      lista.appendChild(c);
    });
    aplicarErros();
    I().atualizarBotoes();
    if (foco != null && foco >= 0 && foco < st.unidades.length) ativar(foco, cursor);
  }

  // ---------- abrir um bloco para escrever ----------
  function autoAltura(ta) { ta.style.height = "auto"; ta.style.height = Math.max(42, ta.scrollHeight + 2) + "px"; }

  function ativar(i, cursor) {
    if (st.ativo === i && st.cta) {
      st.cta.focus();
      if (cursor != null) { var q = Array.isArray(cursor) ? cursor : [cursor, cursor]; st.cta.setSelectionRange(q[0], q[1]); }
      return;
    }
    desativar();
    garantirVisivel(i);
    var c = st.lista.children[i]; if (!c) return;
    guardar();
    var corpo = c.querySelector(".bl-corpo");
    var ta = el("textarea", "bl-ta"); ta.spellcheck = true; ta.lang = "pt-BR"; ta.rows = 1;
    ta.setAttribute("aria-label", "Texto do bloco " + (i + 1));
    ta.value = st.unidades[i];
    ta.maxLength = P.MAX_MODELO;
    c.replaceChild(ta, corpo);
    c.classList.add("bl-aberto");
    st.ativo = i; st.cta = ta; st.valorAoAbrir = ta.value;
    ed().ta = ta;
    autoAltura(ta);
    ta.focus();
    var pos = cursor == null ? ta.value.length : cursor;
    if (Array.isArray(pos)) ta.setSelectionRange(pos[0], pos[1]); else ta.setSelectionRange(pos, pos);

    ta.addEventListener("input", function () {
      if (st.cta !== ta) return;
      var v = ta.value, partes = dividir(v);
      if (partes.length > 1) {                      // colou ou escreveu várias linhas: vira vários blocos
        var at = st.ativo, cur = ta.selectionStart, k = 0;
        while (k < partes.length - 1 && cur > partes[k].length) { cur -= partes[k].length + 1; k++; }
        trocar(at, 1, partes);
        sincronizar(); desenhar(at + k, Math.max(0, cur));
        return;
      }
      st.unidades[st.ativo] = v;
      autoAltura(ta);
      sincronizar();
    });
    ta.addEventListener("keydown", teclaBloco);
    if (P.Comandos) P.Comandos.ligarTextarea(ta);          // botão direito e "!" (comandos) dentro do bloco
    ta.addEventListener("paste", function (e) {
      var colado = (e.clipboardData && e.clipboardData.getData("text")) || "";
      var limpo = P.limparColado(colado), cru = colado.replace(/\r\n?/g, "\n");
      var cabe = P.MAX_MODELO - (ed().master.value.length - (ta.selectionEnd - ta.selectionStart));
      guardar();
      if (limpo !== cru || limpo.length > cabe) {        // veio de uma IA com marcas de formatação, ou é grande demais
        e.preventDefault();
        var corte = limpo.length > cabe;
        if (corte) limpo = limpo.slice(0, Math.max(0, cabe));
        if (limpo) document.execCommand("insertText", false, limpo) || insereDireto(ta, limpo);
        I().dica(corte ? "O texto colado é grande demais: só coube parte dele (máximo " + P.MAX_MODELO + " caracteres no modelo)."
          : "Ajustei o texto colado da IA (tirei marcas de formatação).");
      }
    });
    ["select", "keyup", "mouseup", "focus"].forEach(function (ev) { ta.addEventListener(ev, I().atualizarBotoes); });
    I().atualizarBotoes();
  }
  function insereDireto(ta, txt) {
    var a = ta.selectionStart, b = ta.selectionEnd;
    ta.value = ta.value.slice(0, a) + txt + ta.value.slice(b);
    ta.setSelectionRange(a + txt.length, a + txt.length);
    ta.dispatchEvent(new Event("input", { bubbles: true }));
    return true;
  }

  function desativar() {
    if (!st || st.ativo < 0) return;
    var i = st.ativo, c = st.lista.children[i], ta = st.cta;
    var tinhaFoco = document.activeElement === ta || document.activeElement === document.body;
    st.ativo = -1; st.cta = null; ed().ta = ed().master;
    if (c && ta && ta.parentNode === c) {
      var novo = cartao(st.unidades[i], i);
      st.lista.replaceChild(novo, c);
      aplicarErros();
      if (tinhaFoco) novo.querySelector(".bl-corpo").focus({ preventScroll: true });     // Esc e Tab continuam funcionando
    }
    I().atualizarBotoes();
  }

  // vizinho à vista (pula blocos de seções escondidas) na direção d (-1 ou 1); -1 se não houver
  function vizinhoVisivel(i, d) {
    var j = i + d;
    while (j >= 0 && j < st.unidades.length && donoRecolhido(j) >= 0) j += d;
    return j >= 0 && j < st.unidades.length ? j : -1;
  }

  function teclaBloco(e) {
    var ta = e.target, v = ta.value, a = ta.selectionStart, b = ta.selectionEnd, i = st.ativo, j;
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); desativar(); return; }
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && (e.key === "z" || e.key === "Z") && v === st.valorAoAbrir) {
      e.preventDefault(); desfazer(); return;          // nada escrito neste bloco ainda: desfaz a última mudança nos blocos
    }
    if (e.altKey || e.ctrlKey || e.metaKey) return;
    if (e.key === "Enter") {                           // Enter: o resto da linha vai para um bloco novo logo abaixo
      var umaLinha = I().marcadores(v).some(function (m) { return (m.k === "colchete" || m.k === "corrigivel" || m.k === "nativo") && m.s < a && a < m.e; });
      if (umaLinha) { e.preventDefault(); I().dica("Não dá para quebrar a linha dentro de uma marcação. Leve o cursor para fora dela."); return; }
      if (dentro(protegidos(v), a)) return;            // dentro de uma marcação de várias linhas: quebra normal
      e.preventDefault(); guardar();
      trocar(i, 1, [v.slice(0, a), v.slice(b)]);
      sincronizar(); desenhar(i + 1, 0);
    } else if (e.key === "Backspace" && a === 0 && b === 0 && i > 0) {     // junta com o bloco de cima
      e.preventDefault(); guardar();
      var ant = st.unidades[i - 1];
      trocar(i - 1, 2, [ant + v]);
      sincronizar(); desenhar(i - 1, ant.length);
    } else if (e.key === "Delete" && a === v.length && b === v.length && i < st.unidades.length - 1) {   // junta com o de baixo
      e.preventDefault(); guardar();
      trocar(i, 2, [v + st.unidades[i + 1]]);
      sincronizar(); desenhar(i, v.length);
    } else if (e.key === "ArrowUp" && a === 0 && b === 0 && (j = vizinhoVisivel(i, -1)) >= 0) { e.preventDefault(); ativar(j); }
    else if (e.key === "ArrowDown" && a === v.length && b === v.length && (j = vizinhoVisivel(i, 1)) >= 0) { e.preventDefault(); ativar(j, 0); }
  }

  B._f = { desativar: desativar, ativar: ativar, desenhar: desenhar, trocar: trocar, sincronizar: sincronizar, guardar: guardar,
    refazer: refazer, desfazer: desfazer };      // usados pelas outras partes e por personalizados-blocos-secoes.js
})();
