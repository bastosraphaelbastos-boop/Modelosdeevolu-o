/*
 * Motor — pendências (peça de motor.js; carregue antes dele): contar o que falta preencher, listar opções sem escolha e ir ao próximo item pendente.
 * Funciona sobre a tela montada (#editor) e, com o texto final editado à mão, sobre o texto de #saida. O estado (editadoAMao, semEscolhaAoEditar)
 * fica em motor.js, que entrega ao iniciar() as funções editadoAMao() e semEscolha().
 * M.Pendencias = { iniciar(ctx), contar, irPara(depoisDe, silencioso), opcoesSemEscolha, visivel }.
 */
(function () {
  "use strict";
  var M = window.MotorPecas, Campos = M.Campos;
  var ctx = null;
  var $ = function (id) { return document.getElementById(id); };

  function visivel(el) { return !el.closest(".oculto"); }

  // Trechos que ainda denunciam algo sem preencher no texto final: ___ e "A / B" de opções sem escolha
  function opcoesSemEscolha() {
    var lista = [];
    $("editor").querySelectorAll(".opcoes.pendente:not(.controle)").forEach(function (g) {
      if (!visivel(g)) return;
      var junto = Array.prototype.map.call(g.querySelectorAll("button"), function (b) { return b.dataset.valor; }).join(" / ");
      if (lista.indexOf(junto) === -1) lista.push(junto);
    });
    return lista.sort(function (a, b) { return b.length - a.length; }); // mais longos primeiro ("A / B / C" antes de "A / B")
  }

  function pendenciasNoTexto() {
    var texto = $("saida").value, achados = [];
    var sobrepoe = function (ini, fim) { return achados.some(function (a) { return ini < a.fim && fim > a.ini; }); };
    var procurar = function (alvo) {
      for (var i = texto.indexOf(alvo); i !== -1; i = texto.indexOf(alvo, i + alvo.length)) {
        if (!sobrepoe(i, i + alvo.length)) achados.push({ ini: i, fim: i + alvo.length });
      }
    };
    ctx.semEscolha().forEach(procurar);
    procurar("___");
    return achados.sort(function (a, b) { return a.ini - b.ini; });
  }

  // Campos curtos vazios e opções sem escolha (só os visíveis)
  function contarPendentes() {
    var ed = $("editor"), n = 0;
    if (ctx.editadoAMao()) n = pendenciasNoTexto().length;
    else {
      ed.querySelectorAll(".campo").forEach(function (c) { if (!Campos.ler(c).trim() && visivel(c)) n++; });
      ed.querySelectorAll(".opcoes.pendente").forEach(function (g) { if (visivel(g)) n++; });
      ed.querySelectorAll(".editavel").forEach(function (s) { if (!s.textContent.trim() && visivel(s)) n++; });
    }
    var p = $("pendentes");
    p.textContent = n ? n + (n === 1 ? " item sem preencher (aparece como ___ ou A / B)" : " itens sem preencher (aparecem como ___ ou A / B)") : "✔ Tudo preenchido";
    p.className = n ? "falta" : "ok";
    p.dataset.n = n;
  }

  // Vai ao próximo item pendente (depois de "depoisDe", se informado; senão, o primeiro)
  function irParaPendente(depoisDe, silencioso) {
    if (ctx.editadoAMao()) {
      var p = pendenciasNoTexto()[0], s = $("saida");
      if (!p) return;
      s.focus(); s.setSelectionRange(p.ini, p.fim);
      // rola a caixa até o trecho selecionado
      var antes = s.value.slice(0, p.ini).split("\n").length;
      s.scrollTop = Math.max(0, (antes - 4) * parseFloat(getComputedStyle(s).lineHeight || 18));
      return;
    }
    var ed = $("editor");
    var lista = Array.prototype.filter.call(ed.querySelectorAll(".campo, .opcoes.pendente, .editavel"), function (el) {
      return visivel(el) && el !== depoisDe && (el.classList.contains("campo") || el.classList.contains("editavel") ? !el.textContent.trim() : true);
    });
    var alvo = (depoisDe && lista.find(function (el) {
      return depoisDe.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING;
    })) || lista[0];
    if (!alvo) { if (depoisDe) $("btn-copiar").focus(); return; } // tudo pronto: Enter agora copia
    if (!silencioso) {
      alvo.scrollIntoView({ block: "nearest", behavior: "smooth" });
      alvo.classList.add("piscar");
      setTimeout(function () { alvo.classList.remove("piscar"); }, 1200);
    }
    var foco = (alvo.classList.contains("campo") || alvo.classList.contains("editavel")) ? alvo : alvo.querySelector("button");
    if (foco) foco.focus({ preventScroll: true });
  }

  M.Pendencias = { iniciar: function (c) { ctx = c; }, contar: contarPendentes, irPara: irParaPendente, opcoesSemEscolha: opcoesSemEscolha, visivel: visivel };
})();
