/*
 * Motor dos modelos. Não precisa mexer aqui para adicionar modelos.
 * A sintaxe dos modelos está explicada em LEIA-ME.txt.
 * Este arquivo é o núcleo: estado, texto final, troca de modelo, teste do criador e pontos de extensão (abrir outro modelo/categoria a partir do atual).
 * As outras peças (carregadas antes, em window.MotorPecas) são: motor-modelo.js (interpretar o texto do modelo), motor-campos.js (os espaços de preencher,
 * que quebram a linha), motor-calculos.js (dias e idade gestacional), motor-dialogos.js (pergunta Sim/Não e copiar), motor-pendencias.js (o que falta
 * preencher), motor-repetir.js ({mais#...}: linhas que a pessoa acrescenta, como "＋ Adicionar laboratório") e motor-tela.js (montar a tela do modelo).
 */
(function () {
  "use strict";

  var M = window.MotorPecas, Modelo = M.Modelo, Campos = M.Campos, Calculos = M.Calculos, Dialogos = M.Dialogos, Pend = M.Pendencias, Tela = M.Tela;
  // Modelos de uma categoria (app/categorias.js). O menu lista só as evoluções; ver "Pontos de extensão" mais abaixo para abrir outras categorias.
  function modelosDe(categoria) { return window.Categorias ? window.Categorias.modelos(window.MODELOS, categoria) : (window.MODELOS || []); }
  var modelos = modelosDe("evolucao");
  var atual = null;        // modelo selecionado
  var segmentos = [];      // modelo já interpretado
  var valores = {};        // valores preenchidos (apenas em memória)
  var alterado = false;    // usuário mexeu em algo neste modelo?
  var editadoAMao = false; // usuário editou o texto final diretamente?
  var VAZIO = "\u0000";    // marcador: item que não gera texto
  var calculados = {};     // último valor que o cálculo automático escreveu em cada campo (motor-calculos.js)
  var semEscolhaAoEditar = []; // textos "A / B" que estavam sem escolha quando a pessoa começou a editar (motor-pendencias.js)
  M.estado = function () { return { valores: valores, calculados: calculados, atual: atual }; };      // lido por motor-calculos.js
  var interpretar = Modelo.interpretar, perguntar = Dialogos.perguntar;

  var $ = function (id) { return document.getElementById(id); };

  // Peças que precisam do estado daqui: recebem funções que leem as variáveis na hora de usar
  var contarPendentes = function () { return Pend.contar(); }, irParaPendente = function (depoisDe, silencioso) { return Pend.irPara(depoisDe, silencioso); },
      opcoesSemEscolha = function () { return Pend.opcoesSemEscolha(); };
  Pend.iniciar({ editadoAMao: function () { return editadoAMao; }, semEscolha: function () { return semEscolhaAoEditar; } });
  Tela.iniciar({ valores: function () { return valores; }, irParaPendente: irParaPendente, sincronizar: sincronizar, mudou: mudou });

  // ---------- Montagem da tela ----------


  // ---------- Geração do texto final ----------
  // vals (opcional): valores a usar no lugar dos da tela (usado por textoFinal, para o criador)
  function gerar(segs, vals) {
    vals = vals || valores;
    return segs.map(function (s) {
      var v = s.id ? (vals[s.id] || "").trim() : "";
      if (v && s.tipo !== "opcao" && $("maiusculas").checked) v = v.split("\u00B5").map(function (p) { return p.toUpperCase(); }).join("\u00B5");
      switch (s.tipo) {
        case "texto_fixo": return s.texto;
        case "campo": case "editavel": return v || "___";
        case "aviso": return "___";
        case "texto": return v || VAZIO; // campo de texto livre é opcional
        case "controle": case "auxiliar": case "dica": return VAZIO;
        case "opcao": return v || s.opcoes.join(" / ");
        case "mais": return s.copias.length ? s.copias.map(function (c) { return gerar(c.filhos, vals); }).join("\n") : VAZIO; // linhas acrescentadas (motor-repetir.js)
        case "bloco": return vals[s.chave] === s.valor ? gerar(s.filhos, vals) : "";
        default: return "";
      }
    }).join("");
  }

  // Campos com o mesmo #nome no modelo mostram o mesmo valor (preenche uma vez só)
  function sincronizar(id, origem) {
    document.querySelectorAll('#editor [data-id="' + id + '"]').forEach(function (el) {
      if (el !== origem && Campos.ehEntrada(el)) Campos.escrever(el, valores[id]);
    });
  }


  function mudou() {
    alterado = true;
    if (editadoAMao) { atualizarTela(); return; } // texto final editado à mão: não sobrescrever
    atualizar();
  }

  function atualizarTela() {
    var ed = $("editor");
    ed.classList.toggle("maiusculas", $("maiusculas").checked);
    ed.querySelectorAll(".opcoes").forEach(function (g) {
      var v = valores[g.dataset.id];
      g.classList.toggle("pendente", !v);
      g.querySelectorAll("button").forEach(function (b) { b.classList.toggle("sel", b.dataset.valor === v); });
    });
    ed.querySelectorAll(".bloco").forEach(function (b) {
      b.classList.toggle("oculto", valores[b.dataset.chave] !== b.dataset.valor);
    });
    ed.querySelectorAll(".campo, textarea.texto").forEach(function (c) {
      c.classList.toggle("preenchido", (c.tagName === "TEXTAREA" ? c.value : Campos.ler(c)).trim() !== "");
    });
    contarPendentes();
  }

  function limparSaida(t) {
    return t.replace(/^[\u0000 \t]*\u0000[\u0000 \t]*\n/gm, "")   // remove linhas que só tinham itens de tela
      .replace(/\u0000/g, "")
      .replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }
  function atualizar() {
    atualizarTela();
    $("saida").value = limparSaida(gerar(segmentos));
    avisar("saidamudou");
  }
  // Avisos para peças de fora do motor (aba Alta etc.): "saidamudou" = o texto final mudou por aqui; "modeloselecionado" = abriu/reiniciou um modelo
  function avisar(nome) { document.dispatchEvent(new Event(nome)); }

  // Texto final de um modelo (sintaxe nativa) ainda SEM nada preenchido, igual ao que a tela principal mostraria
  // (___ nos espaços, "A / B" nas escolhas). Não mexe na tela nem nos valores do modelo aberto. Usado pelo criador.
  function textoFinal(textoNativo) {
    var segs = interpretar(textoNativo), vals = {};
    (function iniciais(ss) { ss.forEach(function (s) { if (s.filhos) iniciais(s.filhos); else if (s.id && !(s.id in vals)) vals[s.id] = s.padrao || ""; }); })(segs);
    return limparSaida(gerar(segs, vals));
  }



  // ---------- Seleção de modelo ----------
  // opcoes (opcional): { herdar: { id do campo: texto } } preenche, no modelo novo, os campos de mesmo #nome (ver "Pontos de extensão")
  function selecionar(modelo, opcoes) {
    modelo.desatualizado = false;
    atual = modelo; valores = {}; calculados = {}; Modelo.contador(0); alterado = false;
    sairEdicaoManual(); ampliar(false);
    segmentos = interpretar(modelo.texto.replace(/^\n/, ""));
    Modelo.valoresIniciais(segmentos, valores);
    if (opcoes && opcoes.herdar) Object.keys(opcoes.herdar).forEach(function (k) { if (k in valores && opcoes.herdar[k]) valores[k] = opcoes.herdar[k]; });
    $("titulo-modelo").textContent = modelo.nome;
    var ed = $("editor"); ed.innerHTML = "";
    Tela.reiniciar();
    Tela.montar(segmentos, ed);
    marcarAtivo();
    $("status-copia").textContent = "";
    avisar("modeloselecionado");
    atualizar();
    setTimeout(function () { irParaPendente(null, true); }, 0); // cursor já no 1º item, sem rolar a página
    window.scrollTo(0, 0);
  }

  // Destaca no menu o modelo em uso (chamado também quando o menu é refeito)
  function marcarAtivo() {
    document.querySelectorAll("#lista-modelos .item-modelo").forEach(function (b) {
      b.classList.toggle("ativo", !!atual && b.dataset.id === atual.id);
    });
  }

  function sairEdicaoManual() {
    editadoAMao = false;
    $("aviso-edicao").hidden = true;
    $("saida").classList.remove("editado");
    document.querySelector("main").classList.remove("pausado");
    $("editor").inert = false;
    semEscolhaAoEditar = [];
  }

  function ampliar(sim) {
    document.querySelector("aside").classList.toggle("ampliado", sim);
    $("btn-ampliar").textContent = sim ? "✕ Fechar tela cheia" : "⤢ Tela cheia";
    if (sim) $("saida").focus();
  }

  function copiar() { Campos.formatar(document.activeElement); Dialogos.copiar(function () { irParaPendente(); }); }

  // ---------- Teste do criador de modelos (usado por personalizados-teste.js) ----------
  // Abre um modelo temporário SEM perder o que estava aberto. Os campos já montados continuam com os eventos deles, que
  // apontam para as variáveis deste arquivo: por isso basta guardar as variáveis e a árvore de campos (tirada da tela) e
  // devolver tudo em sairDoTeste(). Nada é gravado em lugar nenhum.
  var guardado = null;
  function testar(modelo) {
    if (guardado) return;
    var ed = $("editor"), area = document.createElement("div");
    while (ed.firstChild) area.appendChild(ed.firstChild);
    guardado = {
      atual: atual, segmentos: segmentos, valores: valores, calculados: calculados, contador: Modelo.contador(), alterado: alterado,
      editadoAMao: editadoAMao, semEscolha: semEscolhaAoEditar, area: area, saida: $("saida").value, mai: $("maiusculas").checked,
      titulo: $("titulo-modelo").textContent, status: $("status-copia").textContent, y: window.scrollY
    };
    selecionar(modelo);
  }
  function sairDoTeste() {
    if (!guardado) return;
    var g = guardado, ed = $("editor");
    guardado = null;
    sairEdicaoManual(); ampliar(false);
    ed.innerHTML = "";
    while (g.area.firstChild) ed.appendChild(g.area.firstChild);
    atual = g.atual; segmentos = g.segmentos; valores = g.valores; calculados = g.calculados; Modelo.contador(g.contador);
    alterado = g.alterado; semEscolhaAoEditar = g.semEscolha;
    $("maiusculas").checked = g.mai; $("titulo-modelo").textContent = g.titulo; $("status-copia").textContent = g.status;
    if (g.editadoAMao) {            // o texto final tinha sido editado à mão: volta como estava (campos pausados)
      editadoAMao = true; ed.inert = true;
      $("saida").value = g.saida; $("saida").classList.add("editado"); $("aviso-edicao").hidden = false;
      document.querySelector("main").classList.add("pausado");
      atualizarTela(); avisar("saidamudou");
    } else atualizar();
    marcarAtivo();
    window.scrollTo(0, g.y);
  }

  // ---------- Início ----------
  // Troca de modelo (pergunta antes se há algo preenchido). Usada pelo menu.
  function trocar(m) {
    if (atual && atual.id === m.id && !atual.desatualizado) { irParaModelo(); return; }   // desatualizado: o modelo foi editado enquanto estava aberto
    if (!alterado) { selecionar(m); irParaModelo(); return; }
    perguntar("Trocar de modelo apaga o que foi preenchido. Continuar?", "Trocar de modelo", "Cancelar")
      .then(function (sim) { if (sim) { selecionar(m); irParaModelo(); } });
  }

  // Depois de escolher um modelo, a tela desce até a parte que o médico usa (em telas menores o menu fica em cima do modelo).
  // Se o topo do modelo já está à vista, nada se mexe.
  // (roda depois do foco no 1º item que o selecionar() agenda: o foco cancelaria a rolagem suave)
  function irParaModelo() {
    setTimeout(function () {
      var main = document.querySelector("main");
      if (!main || guardado) return;
      var topo = main.getBoundingClientRect().top;
      if (topo < 0 || topo > window.innerHeight * 0.3) {
        main.scrollIntoView({ block: "start", behavior: "smooth" });
        setTimeout(function () {        // garantia: se a rolagem suave não aconteceu (animações desligadas no Windows etc.), vai direto
          var t = main.getBoundingClientRect().top;
          if (t < -2 || t > window.innerHeight * 0.3) main.scrollIntoView({ block: "start" });
        }, 700);
      }
    }, 40);
  }

  // ---------- Pontos de extensão (o motor continua sem saber de obstetrícia) ----------
  // A aba Alta (app/alta.js, alta-painel.js) usa: os eventos "modeloselecionado" e "saidamudou" (avisar), modelosDe(), ativo(), valorDe(), focarItem(),
  // editadoAMao(), emTeste() e copiarTexto(). A evolução NUNCA é trocada pela alta. valoresAtuais()/abrirOutro(modelo, herdar) abrem outro modelo
  // com os campos de mesmo #nome já preenchidos (ids automáticos c0, e1, auto1 ficam de fora); ficaram prontos, mas nada os usa hoje.
  function valoresAtuais() { var o = {}; Object.keys(valores).forEach(function (k) { if (!/^(c|e|auto)\d+$/.test(k)) o[k] = valores[k]; }); return o; }
  function abrirOutro(modelo, herdar) { selecionar(modelo, { herdar: herdar || valoresAtuais() }); irParaModelo(); }
  // valor escolhido numa opção/controle (#nome) e levar o foco a esse item na tela
  function valorDe(id) { return valores[id] || ""; }
  function focarItem(id) {
    var g = $("editor").querySelector('[data-id="' + id + '"]');
    if (!g || $("editor").inert) return false;
    var alvo = g.querySelector("button") || g;
    g.scrollIntoView({ block: "center", behavior: "smooth" }); g.classList.add("piscar");
    setTimeout(function () { g.classList.remove("piscar"); }, 1200);
    alvo.focus({ preventScroll: true });
    return true;
  }

  // Ponte para personalizados-*.js (menu, criador de modelos). O motor continua sem saber de modelos personalizados.
  window.Motor = {
    perguntar: perguntar, copiarTexto: Dialogos.copiarTexto, trocar: trocar, selecionar: selecionar, marcarAtivo: marcarAtivo,
    interpretar: interpretar, testar: testar, sairDoTeste: sairDoTeste, textoFinal: textoFinal,
    emTeste: function () { return !!guardado; },
    modelosDe: modelosDe, valoresAtuais: valoresAtuais, abrirOutro: abrirOutro, valorDe: valorDe, focarItem: focarItem,
    editadoAMao: function () { return editadoAMao; },
    ativo: function () { return atual; },
    alterado: function () { return alterado; }
  };

  // O menu é montado por personalizados-ui.js. Se ele faltar, monta só os modelos clássicos.
  if (window.Personalizados && window.Personalizados.iniciar) window.Personalizados.iniciar(window.Motor, modelos);
  else {
    var nav = $("lista-modelos");
    modelos.forEach(function (m, n) {
      var b = document.createElement("button");
      b.className = "item-modelo"; b.textContent = m.nome; b.dataset.id = m.id;
      b.title = "Atalho: Alt+" + (n + 1);
      b.addEventListener("click", function () { trocar(m); });
      nav.appendChild(b);
    });
  }

  $("btn-copiar").addEventListener("click", copiar);
  $("pendentes").addEventListener("click", function () { irParaPendente(); });
  $("maiusculas").addEventListener("change", function () { editadoAMao ? atualizarTela() : atualizar(); });
  $("btn-limpar").addEventListener("click", function () {
    if (!alterado) { selecionar(atual); return; }
    perguntar("Apagar tudo o que foi preenchido e começar uma nova paciente?", "Sim, nova paciente", "Cancelar")
      .then(function (sim) { if (sim) selecionar(atual); });
  });
  $("saida").addEventListener("input", function () {
    if (!editadoAMao) {
      semEscolhaAoEditar = opcoesSemEscolha(); // guarda antes de pausar os campos
      $("editor").inert = true;                // campos pausados de verdade: não dá para clicar por engano
    }
    editadoAMao = true; alterado = true;
    $("saida").classList.add("editado");
    $("aviso-edicao").hidden = false;
    document.querySelector("main").classList.add("pausado");
    contarPendentes();
  });
  $("btn-ampliar").addEventListener("click", function () {
    ampliar(!document.querySelector("aside").classList.contains("ampliado"));
  });
  // Atalhos globais: Esc fecha a tela cheia; Ctrl+Enter copia; Alt+1..9 troca de modelo
  document.addEventListener("keydown", function (e) {
    if (!$("termos-tela").hidden || !$("pergunta-tela").hidden || (!guardado && document.querySelector(".modal-pers:not([hidden])"))) return; // atalhos desligados com janelas abertas (no teste do criador, ele está só escondido)
    if (document.body.classList.contains("no-inicio")) return; // na tela de início valem só os atalhos dela (inicio.js)
    if (e.key === "Escape") ampliar(false);
    else if (e.key === "Enter" && e.ctrlKey && !e.altKey && !e.target.closest("#ferramentas")) { e.preventDefault(); copiar(); }
    else if (e.altKey && !e.ctrlKey && !guardado && /^[1-9]$/.test(e.key)) { // (no teste do criador o menu fica inerte) sem Ctrl: AltGr (teclado ABNT2) = Ctrl+Alt
      var P = window.Personalizados, itens = P && P.itensAtalho ? P.itensAtalho() : document.querySelectorAll("#lista-modelos .item-modelo");   // só os modelos à vista (fora de pasta fechada), na ordem da lista
      var b = itens[+e.key - 1];
      if (b) { e.preventDefault(); b.click(); }
    }
  });
  var desfazerEdicao = function () {
    perguntar("Isso apaga o que você escreveu direto no texto final e volta a montar o texto pelos campos. Continuar?", "Sim, voltar aos campos", "Cancelar")
      .then(function (sim) { if (sim) { sairEdicaoManual(); atualizar(); } });
  };
  $("btn-refazer").addEventListener("click", desfazerEdicao);
  $("btn-refazer-topo").addEventListener("click", desfazerEdicao);

  // Depois de escolher a especialidade na tela de início, o cursor vai para o primeiro item do modelo
  document.addEventListener("especialidadeescolhida", function () { if (!editadoAMao) irParaPendente(null, true); });

  // E se fechar/recarregar a aba sem querer?
  window.addEventListener("beforeunload", function (e) {
    if (alterado) { e.preventDefault(); e.returnValue = ""; }
  });

  if (modelos.length) selecionar(modelos[0]);
  else $("editor").textContent = "Nenhum modelo encontrado na pasta modelos/.";
})();
