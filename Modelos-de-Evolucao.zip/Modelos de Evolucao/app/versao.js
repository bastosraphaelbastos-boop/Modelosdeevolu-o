/*
 * Versão do app: o ÚNICO lugar onde ela é escrita (a aba "Sobre" da Ajuda lê daqui). Carregado cedo, antes dos modelos.
 * Ao lançar uma versão nova: mude APP_VERSAO/APP_DATA e ACRESCENTE no INÍCIO de APP_HISTORICO a versão nova com o que mudou
 * (a primeira da lista é a atual e aparece aberta; as outras ficam recolhidas em "Versões anteriores"). Nunca apague versões antigas.
 * Nas novidades vale **negrito** e <<Tecla>> (como no resto da Ajuda).
 * Não confundir com a versão dos Termos de Uso (app/termos.js).
 */
window.APP_VERSAO = "2.0";
window.APP_DATA = "outubro de 2026";
window.APP_HISTORICO = [
  {
    versao: "2.0", data: "outubro de 2026",
    novidades: [
      "Abas **Evolução** e **Alta**, com altas automáticas para os modelos prontos (tratamento, conduta, laboratórios, resumo, recomendações e CID, cada um com o seu botão de copiar).",
      "Botão **＋ Adicionar laboratório** nos modelos que têm linha de laboratório.",
      "Atalhos de digitação para datas, horas, pressão, temperatura e Apgar.",
      "**Busca rápida** de modelos com <<Ctrl>>+<<K>>.",
      "Modelos (prontos e os seus) podem ser **favoritados** ou **ocultados**, e os ocultos podem ser vistos de novo a qualquer momento.",
      "Esta janela de **Ajuda**.",
      "Modelos recebidos de colegas **atualizam** os que você já tem, sem duplicar.",
      "O app **fecha de verdade** quando você fecha a janela.",
      "Termos de Uso versão 1.6."
    ]
  },
  {
    versao: "1.0", data: "outubro de 2026 (primeira instalação)",
    novidades: [
      "Seis **modelos prontos** de Ginecologia e Obstetrícia: nota de parto, puérpera, curetagem, gestante em tratamento clínico, laqueadura (admissão e evolução).",
      "Preenchimento pelo teclado (<<Enter>> vai ao próximo item, <<1>> a <<9>> escolhem a opção, <<Ctrl>>+<<Enter>> copia) e contagem dos dias e da idade gestacional.",
      "Texto final editável à mão, com opção de desfazer, e conversão para MAIÚSCULAS.",
      "**Ferramentas extras**: TUDO MAIÚSCULO e calculadora de DPP/IG.",
      "**Minhas evoluções**: criar os próprios modelos (escrevendo o texto ou em blocos), testar antes de salvar, rascunho automático, pastas e organizar arrastando.",
      "Enviar modelos a colegas e abrir arquivo de modelo, com cópia de segurança automática e aviso para recuperar os modelos.",
      "Instalador com atalho na área de trabalho e Termos de Uso."
    ]
  }
];
