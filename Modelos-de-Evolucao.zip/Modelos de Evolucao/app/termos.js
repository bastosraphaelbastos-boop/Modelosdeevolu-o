/*
 * Termos de Uso: texto oficial e tela de aceite obrigatória (aparece a cada abertura).
 * Para alterar os termos: edite TERMOS abaixo e atualize "versao" e "data".
 * O arquivo TERMOS-DE-USO.txt deve ser mantido com o mesmo conteúdo.
 */
window.TERMOS = {
  versao: "1.6",
  data: "02/10/2026",
  // Trechos entre **asteriscos** aparecem em negrito na tela.
  secoes: [
    { titulo: "Identificação", texto: [
      "Software “Modelos de Evolução”, criado por Raphael Bastos Palitot de Brito, pessoa física. Contato: brito_raphael@hotmail.com.",
      "Este software **não é um produto oficial** do hospital ou de qualquer instituição, e seu uso não implica endosso institucional."
    ] },
    { titulo: "1. O que é este software", texto: [
      "Ferramenta de apoio à **digitação de textos** de evolução clínica a partir de modelos, e de **cálculos de calendário** (dias de internação, idade gestacional e data provável do parto) feitos com os dados que o próprio usuário digita.",
      "**Não é dispositivo médico, não é registrado na ANVISA, não realiza diagnóstico, não sugere conduta, tratamento ou doses e não é ferramenta de apoio à decisão clínica.** Não substitui o julgamento clínico nem a consulta às diretrizes vigentes."
    ] },
    { titulo: "2. Responsabilidade do usuário pelo prontuário", texto: [
      "**O médico é o único responsável por revisar, corrigir e adaptar o texto ao paciente e por tudo o que registrar no prontuário oficial** (Código de Ética Médica, arts. 80 e 87; Res. CFM 1.638/2002). O uso de modelos não dispensa a avaliação individual do paciente. Não copie texto sem conferi-lo.",
      "Campos preenchidos automaticamente (data de hoje, dias e idade gestacional calculados) são apenas facilidades e devem ser conferidos."
    ] },
    { titulo: "3. Cálculos e diretrizes", texto: [
      "Os resultados dependem integralmente dos dados informados. A calculadora de DPP mostra os resultados pela DUM e pelo USG e o critério publicado de referência (ACOG, Committee Opinion 700, 2017), **sem escolher a datação**, que é decisão do médico. Diretrizes podem ser revistas; confira a versão vigente."
    ] },
    { titulo: "4. Privacidade e dados (LGPD — Lei 13.709/2018)", texto: [
      "O software funciona apenas no navegador deste computador. **Não coleta, não transmite e não compartilha dados**, não usa cookies, e o autor não tem acesso a nada do que é digitado. **Nunca guarda o que é digitado sobre pacientes**: tudo o que é preenchido é apagado ao fechar a página.",
      "Guarda apenas, neste computador e neste navegador, os **modelos que o próprio usuário criar ou abrir de um arquivo** (função “Minhas evoluções”) e os **nomes das pastas** em que os organiza, o **rascunho do modelo que está sendo criado** (somente o texto do modelo, sem dados de pacientes; é guardado automaticamente enquanto o criador está aberto e apagado ao salvar ou ao sair) e preferências de exibição (quais painéis e pastas do menu estão abertos, o modo preferido do criador de modelos e os modelos (prontos ou próprios) marcados como favoritos ou ocultos). A cada mudança nesses modelos, grava também **uma cópia de segurança em arquivo de texto neste computador** (pasta “meus-modelos” da instalação, ou a pasta de downloads), contendo apenas os modelos e os nomes das pastas. Nada disso é transmitido: permanece no computador até o usuário apagar os modelos, as cópias ou os dados do navegador.",
      "**Não digite nome, CPF, número de prontuário ou outros dados que identifiquem o paciente**, nem ao preencher um modelo nem ao escrever um modelo próprio: os modelos não precisam deles. **O usuário é responsável por não colocar dados de pacientes nos modelos** e pelo conteúdo de todos os modelos que criar ou abrir de arquivo. O tratamento dos dados do paciente no prontuário oficial é de responsabilidade do hospital e do médico.",
      "O software oferece, como conveniência, um texto de pedido que o usuário pode copiar e usar em ferramentas de inteligência artificial de terceiros, **fora do software**, para ajudar a montar modelos. O uso é opcional e fica por conta e sob responsabilidade do usuário. O autor não garante que o pedido funcione nem o resultado produzido pela ferramenta, que pode conter erros, omissões ou mudanças de sentido. **É proibido inserir dados de pacientes nessas ferramentas.** O usuário deve conferir todo o modelo antes de salvá-lo e todo texto antes de usá-lo no prontuário."
    ] },
    { titulo: "5. Licença de uso", texto: [
      "O software é licenciado, não vendido (Lei 9.609/1998). O autor concede, gratuitamente e por liberalidade, licença **não exclusiva, intransferível e revogável** para uso em atividades assistenciais no hospital, em computadores autorizados pela instituição.",
      "É proibido vender, alugar ou sublicenciar o software, remover a identificação do autor ou apresentá-lo como obra de terceiros. Alterações no código dependem de autorização do autor. Os textos dos modelos clínicos pertencem às equipes que os elaboraram; os modelos criados ou abertos de arquivo pelo usuário são de responsabilidade dele."
    ] },
    { titulo: "6. Garantia e limitação de responsabilidade", texto: [
      "**O software é oferecido gratuitamente, no estado em que se encontra, sem garantia de funcionamento ininterrupto ou livre de erros.** Na máxima extensão permitida pela lei, e considerando a natureza gratuita da licença (Código Civil, art. 392), o autor responde apenas por dolo. Nada nestes termos afasta direitos que a lei não permite excluir nem limita direitos de terceiros.",
      "Não há obrigação de suporte, manutenção ou atualização. O autor pode alterar, suspender ou retirar o software a qualquer momento."
    ] },
    { titulo: "7. Uso institucional", texto: [
      "O uso nos computadores do hospital depende de autorização da direção e do setor de Tecnologia da Informação, e deve seguir as normas internas. Use somente a cópia entregue pelo autor ou pelo hospital; cópias alteradas não são de responsabilidade do autor."
    ] },
    { titulo: "8. Disposições gerais", texto: [
      "Vale a versão destes termos exibida ao abrir o software; o aceite é pedido a cada abertura e **não fica registrado**, pois o software não guarda esse registro. Se alguma cláusula for considerada inválida, as demais continuam válidas. Aplica-se a lei brasileira, no foro da comarca onde o software é utilizado."
    ] }
  ]
};
(function () {
  "use strict";
  var T = window.TERMOS;
  var $ = function (id) { return document.getElementById(id); };
  var bloqueaveis = function () { return document.querySelectorAll("body > header, #inicio, #ferramentas, .layout, body > footer"); };

  function montarTexto() {
    var caixa = $("termos-texto");
    caixa.innerHTML = "";
    T.secoes.forEach(function (s) {
      var h = document.createElement("h3"); h.textContent = s.titulo; caixa.appendChild(h);
      s.texto.forEach(function (p) {
        var e = document.createElement("p");
        p.split("**").forEach(function (trecho, i) {
          if (i % 2) { var b = document.createElement("strong"); b.textContent = trecho; e.appendChild(b); }
          else e.appendChild(document.createTextNode(trecho));
        });
        caixa.appendChild(e);
      });
    });
    var fim = document.createElement("p"); fim.className = "termos-fim";
    fim.textContent = "Ao clicar em “Li e concordo”, o usuário declara ter lido integralmente e aceitar estes Termos de Uso (versão " + T.versao + ", " + T.data + ").";
    caixa.appendChild(fim);
    $("termos-versao").textContent = "Versão " + T.versao + " — " + T.data;
  }

  // Só libera o aceite depois de rolar o texto até o fim
  function verificarLeitura() {
    var c = $("termos-texto");
    if (c.scrollTop + c.clientHeight >= c.scrollHeight - 8) {
      $("termos-check").disabled = false;
      $("termos-dica").textContent = "Marque a caixa abaixo para continuar.";
      $("termos-dica").classList.add("ok");
    }
  }

  function abrir(somenteLeitura) {
    montarTexto();
    var tela = $("termos-tela");
    tela.classList.toggle("leitura", !!somenteLeitura);
    tela.hidden = false;
    bloqueaveis().forEach(function (el) { el.inert = true; });
    $("termos-texto").scrollTop = 0;
    if (!somenteLeitura) {
      $("termos-check").checked = false; $("termos-check").disabled = true; $("termos-aceitar").disabled = true;
      $("termos-dica").textContent = "Role o texto até o final para liberar o aceite."; $("termos-dica").classList.remove("ok");
      setTimeout(verificarLeitura, 0); // tela grande: se o texto couber inteiro, já libera
    }
    $("termos-texto").focus();
  }

  function fechar() {
    var soLeitura = $("termos-tela").classList.contains("leitura");
    $("termos-tela").hidden = true;
    bloqueaveis().forEach(function (el) { el.inert = false; });
    if (soLeitura) $("link-termos").focus();                  // só estava relendo: volta para onde estava
    else document.dispatchEvent(new Event("termosaceitos"));  // aceite: o app começa no 1º item
  }

  // Esc fecha apenas a leitura pelo rodapé (o aceite inicial continua obrigatório)
  $("termos-tela").addEventListener("keydown", function (e) {
    if (e.key === "Escape" && $("termos-tela").classList.contains("leitura")) fechar();
  });

  $("termos-texto").addEventListener("scroll", verificarLeitura);
  window.addEventListener("resize", function () { if (!$("termos-tela").hidden) verificarLeitura(); });
  $("termos-check").addEventListener("change", function () { $("termos-aceitar").disabled = !this.checked; });
  $("termos-aceitar").addEventListener("click", function () { if ($("termos-check").checked) fechar(); });
  $("termos-fechar").addEventListener("click", fechar);
  $("termos-recusar").addEventListener("click", function () {
    $("termos-dica").textContent = "Sem o aceite dos termos, o aplicativo não pode ser usado. Você pode fechar esta janela.";
    $("termos-dica").classList.remove("ok");
  });
  $("link-termos").addEventListener("click", function (e) { e.preventDefault(); abrir(true); });

  abrir(false); // obrigatório a cada abertura (nada é salvo, então o aceite não fica guardado)
})();
