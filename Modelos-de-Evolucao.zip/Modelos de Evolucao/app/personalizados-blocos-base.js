/*
 * Modo "Blocos" do criador — peças que não dependem do estado (parte de personalizados-blocos.js; carregue antes dele).
 * Dividir o texto em blocos (sem cortar marcações), classificar cada bloco e desenhá-lo "como vai ficar" (igual à prévia).
 * Registra tudo em P.BlocosBase. Todo texto do modelo entra na tela por textContent.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var I = function () { return P._ed; };            // peças do criador (personalizados-editor.js)
  function el(tag, classe, texto) { return I().el(tag, classe, texto); }

  // ---------- dividir o texto em blocos ----------
  // Trechos que não podem ser cortados por uma quebra de linha: marcações ((...)), [..], {..} e blocos [[...]]
  function protegidos(t) {
    var r = [];
    I().marcadores(t).forEach(function (m) {
      if (m.k === "se-ini") r.push([m.ins.ini, m.ins.fim]);
      else if (m.k !== "se-fim") r.push([m.s, m.e]);
    });
    var re = /\[\[[\wÀ-ſ]+=[^:\]\n]*:/g, m;
    while ((m = re.exec(t))) {
      var f = t.indexOf("]]", m.index + m[0].length);
      if (f === -1) break;
      r.push([m.index, f + 2]); re.lastIndex = f + 2;
    }
    return r;
  }
  function dentro(r, pos) { return r.some(function (x) { return x[0] < pos && pos < x[1]; }); }
  function dividir(t) {
    var r = protegidos(t), out = [], ini = 0;
    for (var i = 0; i < t.length; i++) {
      if (t.charAt(i) === "\n" && !dentro(r, i)) { out.push(t.slice(ini, i)); ini = i + 1; }
    }
    out.push(t.slice(ini));
    return out;
  }

  // ---------- aparência de cada bloco ----------
  var TIPOS = {
    vazio: "Linha em branco", titulo: "Título", pergunta: "Pergunta", condicional: "Escolha com texto a mais",
    escolha: "Escolha", texto: "Texto"
  };
  function tipo(u) {
    var t = u.trim();
    if (!t) return "vazio";
    if (t.charAt(0) === "#") return "titulo";
    if (/\[\?\s/.test(t) || /\{controle/.test(t)) return "pergunta";
    if (/\(\(\s*SE\s/i.test(t) || /\[\[/.test(t)) return "condicional";
    if (/\[[^\]\n]*\s\/\s[^\]\n]*\]/.test(t) || /\{opcao/.test(t)) return "escolha";
    return "texto";
  }
  function mostrar(u, alvo) {                        // desenha o bloco como ele vai ficar (igual à prévia)
    alvo.textContent = "";
    if (!u.trim()) { alvo.appendChild(el("span", "bl-branco", "— linha em branco —")); return; }
    var r = P.compilar(u), falsa = false, DIAS = "nº de dias (automático)";
    if (r.erros.length) {
      // O bloco depende de outro (a data de ((DIAS DESDE @X)) ou a escolha de um ((SE ...)) estão em outro bloco).
      // Só para desenhar: os dias viram um espaço e uma escolha "de mentira" no começo recebe os ((SE ...)); depois ela some.
      var t2 = u.replace(/\(\(\s*DIAS\s+DESDE\s+@[^)]*\)\)/gi, "[" + DIAS + "]"), ops = [];
      t2.replace(/\(\(\s*SE\s+([^:()]+?)\s*:/gi, function (x, o) { o = o.trim(); if (!/^SEM RESPOSTA$/i.test(o) && ops.indexOf(o) === -1) ops.push(o); });
      if (/\(\(\s*SE\s/i.test(t2)) {
        while (ops.length < 2) ops.push(ops.length ? "…" : "—");
        t2 = "[" + ops.map(P.escapar).join(" / ") + "]" + t2; falsa = true;
      }
      r = P.compilar(t2);
    }
    if (!r.erros.length) {
      try {
        var segs = P.Motor.interpretar(r.saida.replace(/^\n/, "")), ctx = { autos: {}, simulaveis: {}, semSimular: true };
        r.calculos.forEach(function (c) { ctx.autos[c.para] = true; });
        I().pvSegmentos(segs, alvo, { inicio: true }, ctx);
        if (falsa) { var f = alvo.querySelector(".opcoes"); if (f) f.remove(); }
        Array.prototype.forEach.call(alvo.querySelectorAll(".pv-campo"), function (c) { if (c.textContent === DIAS) c.className = "pv-dias"; });
        return;
      } catch (e) { alvo.textContent = ""; }
    }
    // não dá para desenhar sozinho (ex.: um ((SE ...)) ligado a uma escolha de outro bloco): mostra o texto como está
    alvo.appendChild(el("span", "bl-cru", u));
  }

  P.BlocosBase = { dividir: dividir, dentro: dentro, protegidos: protegidos, tipo: tipo, mostrar: mostrar, TIPOS: TIPOS };
})();
