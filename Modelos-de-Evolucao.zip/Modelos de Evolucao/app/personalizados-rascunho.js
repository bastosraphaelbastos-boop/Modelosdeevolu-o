/*
 * Evoluções personalizadas — rascunho automático do modelo que está sendo criado.
 * Enquanto o criador está aberto e com mudanças não salvas, grava no navegador (localStorage), no máximo a cada 2 segundos:
 *   { id (do modelo que está sendo editado, ou null), nome, texto, modo, quando, pasta (id da pasta de um modelo novo criado de dentro dela) }
 * É o texto do MODELO, nunca dados de pacientes. Some ao salvar, ao sair confirmando "Sair sem salvar" e ao fechar sem mudanças.
 * Ao abrir o criador (novo, ou o MESMO modelo) com um rascunho mais novo e diferente, mostra uma faixa no topo com
 * "Continuar o rascunho" e "Descartar"; ao abrir o app, o painel "Minhas evoluções" avisa que há um modelo não terminado.
 * Só existe um rascunho por vez. Tudo em try/catch: se o navegador não deixar guardar, o app segue sem rascunho.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var R = P.Rascunho = {};
  var CHAVE = "modelosEvolucao.rascunho.v1";
  var tempo = null;        // espera de 2 s para a próxima gravação
  var pendente = null;     // rascunho que a faixa do criador oferece (ainda não continuado nem descartado)
  var el = P.el;
  var armazem = function () { try { return window.localStorage; } catch (e) { return null; } };
  var dois = function (n) { return (n < 10 ? "0" : "") + n; };
  var quandoTexto = function (ms) { var d = new Date(ms); return dois(d.getDate()) + "/" + dois(d.getMonth() + 1) + " " + dois(d.getHours()) + ":" + dois(d.getMinutes()); };

  // Lê e confere o rascunho guardado (null se não há ou se está estragado)
  R.ler = function () {
    try {
      var st = armazem(), bruto = st && st.getItem(CHAVE);
      if (!bruto) return null;
      var d = JSON.parse(bruto);
      if (!d || typeof d.texto !== "string" || typeof d.nome !== "string") return null;
      return {
        id: typeof d.id === "string" ? d.id : null,
        nome: P.limpar(d.nome).slice(0, P.MAX_NOME), texto: P.limpar(d.texto).slice(0, P.MAX_MODELO),
        modo: d.modo === "texto" ? "texto" : "blocos", quando: +d.quando || 0,
        pasta: typeof d.pasta === "string" ? d.pasta.replace(/[^\w-]/g, "").slice(0, 40) : ""      // id da pasta onde o modelo NOVO nasce
      };
    } catch (e) { return null; }
  };
  R.apagar = function () { try { var st = armazem(); if (st) st.removeItem(CHAVE); } catch (e) { /* sem problema */ } };

  function gravarAgora() {
    tempo = null;
    var e = P._ed && P._ed.estado();
    if (!e || !P._ed.sujo() || !e.master.value.trim()) return;       // sem texto ou sem mudanças: não há o que guardar
    try {
      var st = armazem();
      if (st) st.setItem(CHAVE, JSON.stringify({ id: e.rec ? e.rec.id : null, nome: e.nome.value, texto: e.master.value, modo: e.modo, quando: Date.now(), pasta: e.rec ? "" : e.pasta || "" }));
    } catch (x) { /* sem problema: o app segue sem rascunho */ }
  }
  // Chamado a cada mudança no criador: agenda a gravação (no máximo uma a cada 2 s)
  R.agendar = function () {
    if (tempo || !P._ed || !P._ed.sujo()) return;
    tempo = setTimeout(gravarAgora, 2000);
  };
  // Fechar a página com uma gravação ainda esperando: grava já
  window.addEventListener("pagehide", function () { if (tempo) { clearTimeout(tempo); gravarAgora(); } });

  // O criador vai fechar. rec = modelo que estava sendo editado (null = modelo novo).
  // Salvou ou saiu de propósito: o rascunho some. Fechou sem mudanças com a faixa ainda oferecendo um rascunho: ele fica.
  R.aoFechar = function (sujo, rec) {
    clearTimeout(tempo); tempo = null;
    var ficar = !sujo && pendente;
    pendente = null;
    if (ficar) return;
    var d = R.ler();
    if (d && d.id === (rec ? rec.id : null)) R.apagar();      // um rascunho de OUTRO modelo não é tocado
  };

  // Faixa no topo do criador. opcoes = as de abrirEditor; aplicar(d) põe o rascunho no criador.
  R.faixa = function (opcoes, aplicar) {
    pendente = null;
    if (opcoes.rascunho || opcoes.texto) return null;
    var rec = opcoes.rec || null, d = R.ler();
    if (!d || !d.texto.trim() || d.id !== (rec ? rec.id : null)) return null;
    if (rec && (!(d.quando > (rec.alterado || 0)) || (d.texto === rec.texto && d.nome === rec.nome))) return null;     // só se for mais novo e diferente
    pendente = d;
    var f = el("div", "ep-rascunho"); f.setAttribute("role", "status");
    var tx = el("span", "ep-rascunho-tx", "Encontramos um rascunho não salvo de " + quandoTexto(d.quando) + ".");
    var bC = el("button", "ep-rascunho-bt forte", "Continuar o rascunho"), bD = el("button", "ep-rascunho-bt", "Descartar");
    bC.type = "button"; bD.type = "button";
    var fim = function (msg) { pendente = null; tx.textContent = msg; bC.remove(); bD.remove(); };      // a faixa continua (mesma altura): nada se mexe
    bC.addEventListener("click", function () { aplicar(d); fim("✓ Rascunho recuperado. Confira e salve quando terminar."); });
    bD.addEventListener("click", function () { R.apagar(); fim("Rascunho descartado."); });
    f.appendChild(tx); f.appendChild(bC); f.appendChild(bD);
    return f;
  };

  // Aviso no painel "Minhas evoluções" ao abrir o app
  R.caixaMenu = function () {
    if (P.editorAberto && P.editorAberto()) return null;
    var d = R.ler();
    if (!d || !d.texto.trim()) return null;
    var caixa = el("div", "pers-rascunho"); caixa.setAttribute("role", "status");
    caixa.appendChild(el("p", "", "✏️ Você tem um modelo não terminado («" + (d.nome.trim() || "sem nome") + "»)."));
    var b = el("button", "acao-grande forte", "Continuar"); b.type = "button";
    b.addEventListener("click", function () {
      var rec = d.id ? P.lista.filter(function (r) { return r.id === d.id; })[0] : null;
      P.abrirEditor({ rec: rec || null, rascunho: d });
    });
    caixa.appendChild(b);
    return caixa;
  };
})();
