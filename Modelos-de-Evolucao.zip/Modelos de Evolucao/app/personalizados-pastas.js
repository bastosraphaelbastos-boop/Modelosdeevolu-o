/*
 * Evoluções personalizadas — pastas de "Minhas evoluções" (parte lógica, não mexe na tela).
 * Um nível só, no máximo P.MAX_PASTAS pastas, nome até P.MAX_NOME_PASTA caracteres, sem repetir e nunca "Sem pasta" (essa é fixa).
 * O modelo guarda o id da pasta no campo OPCIONAL "pasta" (sem o campo = "Sem pasta": modelos antigos continuam valendo).
 * A lista de pastas fica em outra chave do navegador (P.CHAVE_PASTAS) = [{ id, nome, ordem }] e é mesclada entre janelas como a dos
 * modelos (P.pastasApagadas impede que uma pasta apagada nesta janela volte). Apagar uma pasta NUNCA apaga modelos.
 * A tela está em personalizados-ui.js e personalizados-pastas-ui.js. Carregue depois de personalizados-armazem.js.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var SEM = "sem pasta";

  P.pastas = [];             // [{ id, nome, ordem }] na ordem de exibição
  P.pastasApagadas = {};     // ids de pastas apagadas nesta janela

  function armazem() { try { return window.localStorage; } catch (e) { return null; } }
  var semAcento = function (t) { return String(t).normalize("NFD").replace(/[̀-ͯ]/g, ""); };

  P.nomePastaLimpo = function (n) {
    return P.limpar(n).replace(/\s+/g, " ").replace(/={3,}/g, "=").replace(/^[\s*_]+|[\s*_]+$/g, "").slice(0, P.MAX_NOME_PASTA).replace(/[\s*_]+$/, "");
  };
  P.chavePasta = function (n) { return semAcento(P.nomePastaLimpo(n)).toLowerCase(); };

  // "" se o nome serve; senão a frase que explica o problema (ignorarId: a própria pasta, ao renomear)
  P.erroNomePasta = function (nome, ignorarId) {
    var n = P.nomePastaLimpo(nome), k = P.chavePasta(n);
    if (!n) return "Escreva o nome da pasta.";
    if (k === SEM) return "“Sem pasta” não pode ser usado como nome de pasta. Escolha outro nome.";
    if (P.pastas.some(function (f) { return f.id !== ignorarId && P.chavePasta(f.nome) === k; })) return "Já existe uma pasta com esse nome.";
    return "";
  };

  function nomeLivrePasta(base, usadas) {          // "Nome" -> "Nome (2)" se já existir
    var chaves = usadas.map(P.chavePasta), k = 2, cand = base;
    while (chaves.indexOf(P.chavePasta(cand)) !== -1) cand = P.nomePastaLimpo(base.slice(0, P.MAX_NOME_PASTA - 5) + " (" + (k++) + ")");
    return cand;
  }

  // Lê e limpa a lista guardada (nomes repetidos ganham "(2)"; ids repetidos são descartados)
  P.carregarPastas = function () {
    var lista = [], vistos = {}, st = armazem(), bruto = null;
    if (!st) return lista;
    try {
      bruto = st.getItem(P.CHAVE_PASTAS);
      var dados = bruto ? JSON.parse(bruto) : [];
      if (!Array.isArray(dados)) throw new Error("formato");
      dados.forEach(function (r, k) {
        if (!r || typeof r.id !== "string" || typeof r.nome !== "string") return;
        var id = r.id.replace(/[^\w-]/g, "").slice(0, 40), nome = P.nomePastaLimpo(r.nome);
        if (!id || vistos[id] || !nome || P.chavePasta(nome) === SEM) return;
        vistos[id] = true;
        nome = nomeLivrePasta(nome, lista.map(function (f) { return f.nome; }));
        lista.push({ id: id, nome: nome, ordem: typeof r.ordem === "number" && isFinite(r.ordem) ? r.ordem : k, pos0: k });
      });
      lista.sort(function (a, b) { return a.ordem - b.ordem || a.pos0 - b.pos0; });
      lista.forEach(function (f, k) { f.ordem = k; delete f.pos0; });
    } catch (e) {
      if (bruto) { try { st.setItem(P.CHAVE_PASTAS + ".corrompido", bruto); } catch (e2) { /* sem problema */ } }
    }
    return lista;
  };

  // Grava a lista de pastas, juntando (por id) as que OUTRA janela tenha criado
  P.salvarPastas = function () {
    var st = armazem();
    if (!st) return false;
    try {
      var meus = {};
      P.pastas.forEach(function (f) { meus[f.id] = true; });
      P.carregarPastas().forEach(function (f) {
        if (meus[f.id] || P.pastasApagadas[f.id]) return;
        f.nome = nomeLivrePasta(f.nome, P.pastas.map(function (x) { return x.nome; }));
        P.pastas.push(f);
      });
      P.pastas.forEach(function (f, k) { f.ordem = k; });
      st.setItem(P.CHAVE_PASTAS, JSON.stringify(P.pastas)); return true;
    } catch (e) { return false; }
  };

  P.pastaPorId = function (id) { return id ? P.pastas.filter(function (f) { return f.id === id; })[0] || null : null; };
  P.pastaPorNome = function (nome) { var k = P.chavePasta(nome); return k ? P.pastas.filter(function (f) { return P.chavePasta(f.nome) === k; })[0] || null : null; };
  // Pasta do modelo (null = "Sem pasta"; um id que não existe mais também conta como sem pasta)
  P.pastaDe = function (rec) { return rec && rec.pasta ? P.pastaPorId(rec.pasta) : null; };
  P.modelosDaPasta = function (id) {
    return P.lista.filter(function (r) { var f = P.pastaDe(r); return id ? !!f && f.id === id : !f; });
  };

  P.novoIdPasta = function () { return "p" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); };

  // Cria uma pasta. Devolve { pasta } ou { erro }
  P.criarPasta = function (nome) {
    if (P.pastas.length >= P.MAX_PASTAS) return { erro: "Você já tem " + P.MAX_PASTAS + " pastas, que é o máximo. Apague uma que não usa mais." };
    var erro = P.erroNomePasta(nome);
    if (erro) return { erro: erro };
    var f = { id: P.novoIdPasta(), nome: P.nomePastaLimpo(nome), ordem: P.pastas.length };
    P.pastas.push(f);
    return { pasta: f };
  };

  P.renomearPasta = function (id, nome) {
    var f = P.pastaPorId(id), erro = P.erroNomePasta(nome, id);
    if (!f) return { erro: "Esta pasta não existe mais." };
    if (erro) return { erro: erro };
    f.nome = P.nomePastaLimpo(nome);
    return { pasta: f };
  };

  // Apaga a pasta; os modelos dela ficam SEM PASTA (nunca são apagados). Devolve quantos foram para "Sem pasta".
  P.apagarPasta = function (id) {
    var n = 0;
    P.lista.forEach(function (r) { if (r.pasta === id) { delete r.pasta; n++; } });
    P.pastasApagadas[id] = true;
    P.pastas = P.pastas.filter(function (f) { return f.id !== id; });
    P.pastas.forEach(function (f, k) { f.ordem = k; });
    return n;
  };

  // Põe o modelo na pasta (id vazio = "Sem pasta")
  P.colocarNaPasta = function (rec, id) {
    if (id && P.pastaPorId(id)) rec.pasta = id; else delete rec.pasta;
  };

  // Sobe (-1) ou desce (+1) a pasta na ordem de exibição
  P.moverPasta = function (id, d) {
    var i = -1, j;
    P.pastas.forEach(function (f, k) { if (f.id === id) i = k; });
    j = i + d;
    if (i < 0 || j < 0 || j >= P.pastas.length) return false;
    var f = P.pastas.splice(i, 1)[0]; P.pastas.splice(j, 0, f);
    P.pastas.forEach(function (x, k) { x.ordem = k; });
    return true;
  };

  // Pastas fechadas no menu (lembradas na preferência "pf": lista de ids; "-" = a fixa "Sem pasta")
  P.pastaFechada = function (id) { var pf = P.lerPref().pf; return Array.isArray(pf) && pf.indexOf(id || "-") !== -1; };
  P.lembrarPasta = function (id, aberta) {
    var pf = P.lerPref().pf, k = id || "-";
    pf = Array.isArray(pf) ? pf.filter(function (x) { return x !== k; }) : [];
    if (!aberta) pf.push(k);
    P.salvarPref({ pf: pf });
  };
})();
