/*
 * Ferramentas extras (painel recolhível): TUDO MAIÚSCULO e Calculadora de DPP.
 * Independente do motor dos modelos. Não salva nada.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };

  // ---------- Datas (contadas em dias inteiros, em UTC, para não sofrer com fuso/horário de verão) ----------
  var DIA = 864e5;

  // Aceita 27/09/2026, 27/09/26, 27-09-2026, 27.09.2026 e 27092026. Exige o ano (evita ano errado na DUM).
  function lerData(txt) {
    txt = (txt || "").trim();
    var m = txt.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2}|\d{4})$/) || txt.match(/^(\d{2})(\d{2})(\d{4})$/);
    if (!m) return null;
    var d = +m[1], mes = +m[2], a = +m[3];
    if (a < 100) a += 2000;
    var t = Date.UTC(a, mes - 1, d), dt = new Date(t);
    if (dt.getUTCFullYear() !== a || dt.getUTCMonth() !== mes - 1 || dt.getUTCDate() !== d) return null; // ex.: 31/02
    return Math.round(t / DIA); // nº do dia
  }
  function hoje() { var d = new Date(); return Math.round(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / DIA); }
  function fmt(n) {
    var d = new Date(n * DIA);
    return String(d.getUTCDate()).padStart(2, "0") + "/" + String(d.getUTCMonth() + 1).padStart(2, "0") + "/" + d.getUTCFullYear();
  }
  function ig(dias) { var s = Math.floor(dias / 7), d = dias % 7; return s + (s === 1 ? " SEMANA E " : " SEMANAS E ") + d + (d === 1 ? " DIA" : " DIAS"); }
  function igCurta(dias) { return Math.floor(dias / 7) + "s" + (dias % 7) + "d"; }
  function inteiro(txt) { txt = (txt || "").trim(); return /^\d{1,2}$/.test(txt) ? +txt : null; }

  // Critério ACOG (Committee Opinion 611/700) para preferir o USG: faixa pela IG da DUM na data do USG
  function limiteRedatar(igDumNoUsg) {
    var s = igDumNoUsg / 7;
    if (s < 9) return { dias: 5, faixa: "até 8s6d (CCN)" };
    if (s < 14) return { dias: 7, faixa: "9s0d a 13s6d (CCN)" };
    if (s < 16) return { dias: 7, faixa: "14s0d a 15s6d (biometria)" };
    if (s < 22) return { dias: 10, faixa: "16s0d a 21s6d (biometria)" };
    if (s < 28) return { dias: 14, faixa: "22s0d a 27s6d (biometria)" };
    return { dias: 21, faixa: "28s0d ou mais (biometria)" };
  }

  // ---------- Calculadora de DPP ----------
  function calcularDPP() {
    var saida = $("dpp-resultado"), erros = [], avisos = [], linhas = [];
    var txtDum = $("dpp-dum").value, txtUsg = $("dpp-usg-data").value;
    var txtS = $("dpp-usg-sem").value, txtD = $("dpp-usg-dias").value, txtRef = $("dpp-ref").value;
    var ref = txtRef.trim() ? lerData(txtRef) : hoje();
    if (ref === null) erros.push("Data de referência inválida (use dd/mm/aaaa).");

    var dum = null, usg = null, igUsg = null;
    if (txtDum.trim()) { dum = lerData(txtDum); if (dum === null) erros.push("DUM inválida — use dd/mm/aaaa, com o ano."); }
    var algoUsg = txtUsg.trim() || txtS.trim() || txtD.trim();
    if (algoUsg) {
      usg = lerData(txtUsg);
      var s = inteiro(txtS), d = txtD.trim() === "" ? 0 : inteiro(txtD);
      if (usg === null) erros.push("Data do USG inválida — use dd/mm/aaaa, com o ano.");
      if (s === null || s < 4 || s > 42) erros.push("Semanas no USG: informe um número entre 4 e 42.");
      if (d === null || d > 6) erros.push("Dias no USG: informe um número entre 0 e 6.");
      if (!erros.length) igUsg = s * 7 + d;
    }
    if (!erros.length && dum === null && igUsg === null) { saida.innerHTML = '<p class="dpp-vazio">Preencha a DUM e/ou os dados do USG.</p>'; return; }
    if (!erros.length && dum !== null && dum > ref) erros.push("A DUM está depois da data de referência.");
    if (!erros.length && usg !== null && usg > ref) erros.push("A data do USG está depois da data de referência.");
    if (!erros.length && dum !== null && usg !== null && usg < dum) erros.push("A data do USG é anterior à DUM.");
    if (erros.length) { saida.innerHTML = '<ul class="dpp-erros">' + erros.map(function (e) { return "<li>⚠ " + e + "</li>"; }).join("") + "</ul>"; return; }

    var porDum = null, porUsg = null;
    if (dum !== null) porDum = { igHoje: ref - dum, dpp: dum + 280 };
    if (igUsg !== null) { var dumEq = usg - igUsg; porUsg = { igHoje: ref - dumEq, dpp: dumEq + 280 }; }

    var refTxt = txtRef.trim() ? "em " + fmt(ref) : "hoje";
    var html = '<table class="dpp-tabela"><tr><th></th><th>IG ' + refTxt + "</th><th>DPP</th></tr>";
    if (porDum) html += "<tr><td>Pela DUM (" + fmt(dum) + ")</td><td>" + igCurta(porDum.igHoje) + "</td><td><strong>" + fmt(porDum.dpp) + "</strong></td></tr>";
    if (porUsg) html += "<tr><td>Pelo USG (" + fmt(usg) + ", " + igCurta(igUsg) + ")</td><td>" + igCurta(porUsg.igHoje) + "</td><td><strong>" + fmt(porUsg.dpp) + "</strong></td></tr>";
    html += "</table>";


    if (porDum && porUsg) {
      var igDumNoUsg = usg - dum;          // IG pela DUM no dia do USG
      var dif = igDumNoUsg - igUsg;        // + = DUM "mais adiantada" que o USG
      var lim = limiteRedatar(igDumNoUsg);
      var ultrapassa = Math.abs(dif) > lim.dias;
      if (Math.abs(dif) > 28) avisos.push("DUM e USG discordam em mais de 4 semanas — confira se as datas foram digitadas corretamente.");
      html += '<p class="dpp-criterio">Diferença entre DUM e USG no dia do exame: <strong>' + Math.abs(dif) + (Math.abs(dif) === 1 ? " dia" : " dias") +
        "</strong>. Referência (ACOG, Committee Opinion 700/2017): para IG pela DUM de " + lim.faixa + ", a redatação pelo USG é considerada quando a diferença é <strong>maior que " + lim.dias + " dias</strong>. " +
        "Neste caso, a diferença <strong>" + (ultrapassa ? "ultrapassa" : "não ultrapassa") + "</strong> esse limite.<br>" +
        "<em>Qual datação adotar é decisão do médico.</em></p>";
    }
    [porDum, porUsg].forEach(function (p) { if (p && p.igHoje > 42 * 7) avisos.push("IG acima de 42 semanas — confira as datas."); });
    if (avisos.length) html += '<p class="dpp-aviso">⚠ ' + avisos.filter(function (a, i) { return avisos.indexOf(a) === i; }).join(" ") + "</p>";

    // Uma linha pronta para cada método; o médico escolhe qual copiar
    var linhas = [];
    var emRef = txtRef.trim() ? " EM " + fmt(ref) : "";
    if (porDum) linhas.push({ rotulo: "Pela DUM", texto: "IG " + ig(porDum.igHoje) + " (DUM)" + emRef + " - DPP: " + fmt(porDum.dpp) });
    if (porUsg) linhas.push({ rotulo: "Pelo USG", texto: "IG " + ig(porUsg.igHoje) + " (USG " + fmt(usg) + " COM " + igCurta(igUsg).toUpperCase() + ")" + emRef + " - DPP: " + fmt(porUsg.dpp) });
    linhas.forEach(function (l, i) {
      html += '<div class="dpp-texto"><span class="dpp-rotulo">' + l.rotulo + ':</span><code>' + l.texto + '</code><button type="button" data-linha="' + i + '">Copiar</button></div>';
    });
    saida.innerHTML = html;
    saida.querySelectorAll("button[data-linha]").forEach(function (b) {
      b.addEventListener("click", function () { copiarTexto(linhas[+b.dataset.linha].texto, b); });
    });
  }

  // ---------- TUDO MAIÚSCULO ----------
  function converterMaiusculo() {
    var t = $("mai-texto");
    t.value = t.value.toLocaleUpperCase("pt-BR");
  }

  function copiarTexto(texto, botao) {
    var ok = function () { var o = botao.textContent; botao.textContent = "✔ Copiado"; setTimeout(function () { botao.textContent = o; }, 2000); };
    var reserva = function () {
      var t = document.createElement("textarea"); t.value = texto; document.body.appendChild(t); t.select();
      try { document.execCommand("copy"); ok(); } catch (e) { /* o texto continua visível para Ctrl+C */ }
      document.body.removeChild(t);
    };
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(texto).then(ok, reserva); else reserva();
  }

  // Completa datas digitadas só com números (27092026 -> 27/09/2026)
  function mascaraData(el) {
    el.addEventListener("input", function () {
      var d = el.value.trim();
      if (/^\d{8}$/.test(d)) el.value = d.slice(0, 2) + "/" + d.slice(2, 4) + "/" + d.slice(4);
    });
  }

  ["dpp-dum", "dpp-usg-data", "dpp-ref"].forEach(function (id) { mascaraData($(id)); });
  ["dpp-dum", "dpp-usg-data", "dpp-usg-sem", "dpp-usg-dias", "dpp-ref"].forEach(function (id) { $(id).addEventListener("input", calcularDPP); });
  $("dpp-limpar").addEventListener("click", function () {
    ["dpp-dum", "dpp-usg-data", "dpp-usg-sem", "dpp-usg-dias", "dpp-ref"].forEach(function (id) { $(id).value = ""; });
    calcularDPP();
  });
  $("mai-converter").addEventListener("click", converterMaiusculo);
  $("mai-copiar").addEventListener("click", function () { converterMaiusculo(); copiarTexto($("mai-texto").value, this); });
  $("mai-limpar").addEventListener("click", function () { $("mai-texto").value = ""; $("mai-texto").focus(); });
  calcularDPP();

  // Exposto só para testes automáticos
  window.__ferramentas = { lerData: lerData, fmt: fmt, limiteRedatar: limiteRedatar, calcularDPP: calcularDPP };
})();
