/*
 * Busca rápida (Ctrl+K): caixa no centro da tela com TODOS os modelos de evolução (prontos que não estão ocultos + "Minhas evoluções"),
 * filtro sem acento nem maiúsculas, ↑ ↓ andam, Enter abre, Esc fecha. Mostra a pasta/grupo de cada modelo.
 * Só abre na tela de uso (não no criador, nos termos, na tela de início, durante o teste nem com outra janela aberta).
 * Abrir um modelo = clicar no item dele no menu (o mesmo caminho do clique e do Alt+n: pergunta de troca, volta para a aba Evolução).
 * Carregue depois de motor.js. Não guarda nada. Todo texto entra por textContent.
 */
(function () {
  "use strict";
  var P = window.Personalizados;
  var $ = function (id) { return document.getElementById(id); };
  var semAcento = function (t) { return String(t).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); };
  var aberta = false;

  // [{ id (o do botão no menu), nome, grupo, fav, oc (oculto), abrir }] na ordem em que o menu mostra (favoritos no alto de cada grupo).
  // Os ocultos vêm junto, marcados oc: ficam fora da lista; só contam para a linha "N modelo(s) oculto(s) combina(m)".
  function todos() {
    var F = P.Favoritos;
    var r = F.visiveis(true).map(function (m) { return { id: m.id, nome: m.nome, grupo: "Modelos prontos", fav: F.ehFavorito(m.id), oc: F.ehOculto(m.id), abrir: function () { P.Motor.trocar(m); } }; });
    var meus = function (rec, grupo) { var k = F.chave(rec); return { id: k, nome: rec.nome, grupo: grupo, fav: F.ehFavorito(k), oc: F.ehOculto(k), abrir: function () { P.abrirModelo(rec); } }; };
    var ehEvolucao = function (rec) { return !rec.categoria || rec.categoria === "evolucao"; };
    P.pastas.forEach(function (f) { F.meus(f.id, true).filter(ehEvolucao).forEach(function (rec) { r.push(meus(rec, "Minhas evoluções › " + f.nome)); }); });
    F.meus("", true).filter(ehEvolucao).forEach(function (rec) { r.push(meus(rec, "Minhas evoluções")); });
    return r;
  }

  function podeAbrir() {
    return !aberta && !document.body.classList.contains("no-inicio") && $("termos-tela").hidden && $("pergunta-tela").hidden &&
      !document.querySelector(".modal-pers, .menu-contexto") && !P.Motor.emTeste();
  }

  function abrir() {
    var anterior = document.activeElement, itens = todos(), vis = [], ocultos = [], ativo = 0;
    aberta = true;
    var fundo = P.el("div", "modal-pers dlg-pers busca-pers"), caixa = P.el("div", "busca-caixa");
    fundo.setAttribute("role", "dialog"); fundo.setAttribute("aria-modal", "true"); fundo.setAttribute("aria-label", "Busca rápida de modelos");
    var topo = P.el("div", "busca-topo");
    var campo = P.el("input", "busca-campo"); campo.type = "text"; campo.maxLength = 60; campo.autocomplete = "off"; campo.spellcheck = false;
    campo.placeholder = "Digite o nome do modelo"; campo.setAttribute("aria-label", "Buscar modelo pelo nome");
    campo.setAttribute("role", "combobox"); campo.setAttribute("aria-expanded", "true"); campo.setAttribute("aria-controls", "busca-lista"); campo.setAttribute("aria-autocomplete", "list");
    var x = P.el("button", "busca-x", "✕"); x.type = "button"; x.setAttribute("aria-label", "Fechar a busca");
    topo.appendChild(campo); topo.appendChild(x);
    var ocBtn = P.el("button", "busca-ocultos"); ocBtn.type = "button"; ocBtn.hidden = true;      // "N modelo(s) oculto(s) combina(m)": só sem resultado visível
    var lista = P.el("ul", "busca-lista"); lista.id = "busca-lista"; lista.setAttribute("role", "listbox"); lista.setAttribute("aria-label", "Modelos");
    var estado = P.el("p", "busca-estado"); estado.setAttribute("role", "status");
    caixa.appendChild(topo); caixa.appendChild(lista); caixa.appendChild(ocBtn); caixa.appendChild(estado);
    caixa.appendChild(P.el("p", "busca-dica", "↑ ↓ escolhem · Enter abre · Esc fecha"));
    fundo.appendChild(caixa);

    function marcar(i, rolar) {
      ativo = i;
      Array.prototype.forEach.call(lista.children, function (li, k) { li.setAttribute("aria-selected", k === i ? "true" : "false"); });
      if (lista.children[i]) {
        campo.setAttribute("aria-activedescendant", lista.children[i].id);
        if (rolar) lista.children[i].scrollIntoView({ block: "nearest" });
      } else campo.removeAttribute("aria-activedescendant");
    }
    function filtrar() {
      var q = semAcento(campo.value).trim().split(/\s+/).filter(Boolean);
      var casa = itens.filter(function (it) { var t = semAcento(it.nome + " " + it.grupo); return q.every(function (w) { return t.indexOf(w) !== -1; }); });
      vis = casa.filter(function (it) { return !it.oc; }); ocultos = casa.filter(function (it) { return it.oc; });
      lista.textContent = "";
      vis.forEach(function (it, k) {
        var li = P.el("li", "busca-item"); li.id = "busca-op-" + k; li.setAttribute("role", "option");
        li.appendChild(P.el("span", "busca-nome", (it.fav ? "⭐ " : "") + it.nome));
        li.appendChild(P.el("span", "busca-grupo", it.grupo));
        li.addEventListener("mousedown", function (e) { e.preventDefault(); });      // o foco fica no campo
        li.addEventListener("click", function () { escolher(k); });
        li.addEventListener("mousemove", function () { if (ativo !== k) marcar(k, false); });
        lista.appendChild(li);
      });
      estado.textContent = vis.length ? vis.length + (vis.length === 1 ? " modelo" : " modelos") : "Nenhum modelo com esse nome.";
      ocBtn.hidden = vis.length > 0 || !ocultos.length;
      ocBtn.textContent = ocultos.length === 1 ? "1 modelo oculto combina — clique para mostrar" : ocultos.length + " modelos ocultos combinam — clique para mostrar";
      marcar(0, true);
    }
    function fechar() {
      aberta = false;
      document.removeEventListener("keydown", tecla, true);
      fundo.remove(); P.travarFundo(false);
      if (anterior && anterior.isConnected && anterior.focus) anterior.focus({ preventScroll: true });
    }
    function escolher(k) {
      var it = vis[k];
      if (!it) return;
      fechar();
      var b = document.querySelector('#lista-modelos .item-modelo[data-id="' + it.id + '"]');
      if (b) b.click(); else it.abrir();
    }
    function revelar() {      // fecha a busca e mostra, no menu, os ocultos que combinam (não os "desoculta")
      var ks = ocultos.map(function (it) { return it.id; });
      fechar(); P.Favoritos.revelar(ks);
    }
    function tecla(e) {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); fechar(); }
      else if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault(); e.stopPropagation();
        if (vis.length) marcar((ativo + (e.key === "ArrowDown" ? 1 : vis.length - 1)) % vis.length, true);
      } else if (e.key === "Enter" && document.activeElement === campo) { e.preventDefault(); e.stopPropagation(); if (!vis.length && !ocBtn.hidden) revelar(); else escolher(ativo); }
      else if (e.key === "Tab") {
        e.preventDefault();
        var ordem = ocBtn.hidden ? [campo, x] : [campo, ocBtn, x], p = ordem.indexOf(document.activeElement);
        ordem[(p + (e.shiftKey ? ordem.length - 1 : 1)) % ordem.length].focus();
      }
    }
    campo.addEventListener("input", filtrar);
    x.addEventListener("click", fechar);
    ocBtn.addEventListener("click", revelar);
    fundo.addEventListener("mousedown", function (e) { if (e.target === fundo) fechar(); });
    P.travarFundo(true);
    document.body.appendChild(fundo);
    document.addEventListener("keydown", tecla, true);
    filtrar(); campo.focus();
  }

  document.addEventListener("keydown", function (e) {
    if ((e.key !== "k" && e.key !== "K") || !(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey) return;
    if (!podeAbrir()) return;
    e.preventDefault(); e.stopPropagation(); abrir();
  }, true);

  // Dica discreta no alto do menu (também abre a busca com o mouse)
  var nav = $("lista-modelos");
  if (nav) {
    var dica = P.el("button", "busca-dica-menu"); dica.type = "button"; dica.title = "Buscar um modelo pelo nome";
    dica.appendChild(document.createTextNode("🔎 Buscar modelo "));
    dica.appendChild(P.el("kbd", "", "Ctrl")); dica.appendChild(document.createTextNode("+")); dica.appendChild(P.el("kbd", "", "K"));
    dica.addEventListener("click", function () { if (podeAbrir()) abrir(); });
    nav.insertBefore(dica, nav.firstChild);
  }
  window.BuscaRapida = { abrir: function () { if (podeAbrir()) abrir(); } };
})();
