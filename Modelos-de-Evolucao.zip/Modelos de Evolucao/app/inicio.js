// Tela de início: escolha da especialidade (por enquanto só Ginecologia e Obstetrícia está disponível)
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var corpo = document.body;
  var noInicio = function () { return corpo.classList.contains("no-inicio"); };
  var disponivel = document.querySelector("#inicio .esp:not(.indisponivel)");
  var timer = null;

  function mostrarInicio() {
    corpo.classList.add("no-inicio");
    document.dispatchEvent(new Event("voltouespecialidades")); // a aba Alta é zerada (app/alta.js)
    window.scrollTo(0, 0);
    disponivel.focus();
  }

  function abrirEspecialidade(bt) {
    // Identificação da área: selo no topo, trilha acima do título e faixa colorida no painel
    ["esp-atual", "esp-trilha"].forEach(function (id) {
      $(id).querySelector(".esp-txt").textContent = bt.querySelector(".esp-nome").textContent;
      $(id).querySelector(".esp-ico").innerHTML = bt.querySelector("svg").outerHTML;
    });
    document.documentElement.style.setProperty("--cor-area", bt.getAttribute("data-cor") || "var(--roxo)");
    corpo.classList.remove("no-inicio");
    window.scrollTo(0, 0);
    document.dispatchEvent(new Event("especialidadeescolhida")); // o motor leva o cursor ao 1º item
  }

  function avisarIndisponivel(bt) {
    document.querySelectorAll("#inicio .esp.mostrar").forEach(function (b) { b.classList.remove("mostrar"); });
    bt.classList.add("mostrar");
    $("inicio-aviso").textContent = bt.querySelector(".esp-nome").textContent + ": indisponível, por enquanto.";
    clearTimeout(timer);
    timer = setTimeout(function () { bt.classList.remove("mostrar"); }, 2500);
  }

  document.querySelectorAll("#inicio .esp").forEach(function (bt) {
    bt.addEventListener("click", function () {
      if (bt.classList.contains("indisponivel")) avisarIndisponivel(bt);
      else abrirEspecialidade(bt);
    });
  });

  $("btn-especialidades").addEventListener("click", mostrarInicio);

  // Teclado: 1 a 4 escolhem o quadrado (Enter no quadrado focado já funciona por ser botão)
  document.addEventListener("keydown", function (e) {
    if (!noInicio() || e.ctrlKey || e.altKey || e.metaKey) return;
    if (!$("termos-tela").hidden || !$("pergunta-tela").hidden) return;
    var bts = document.querySelectorAll("#inicio .esp");
    if (/^[1-9]$/.test(e.key) && bts[+e.key - 1]) { e.preventDefault(); bts[+e.key - 1].click(); }
    else if (e.key === "Enter" && !e.target.closest("#inicio .esp")) { e.preventDefault(); disponivel.click(); }
  });

  // Depois do aceite dos termos, o foco vai para o quadrado disponível
  document.addEventListener("termosaceitos", function () { if (noInicio()) disponivel.focus(); });
})();

// Telas menores (notebook, zoom do Windows): as instruções acima do modelo começam recolhidas, para o modelo aparecer mais alto.
(function () {
  var d = document.getElementById("como-usar");
  if (d && (window.innerHeight < 900 || window.innerWidth < 1500)) d.open = false;
})();
