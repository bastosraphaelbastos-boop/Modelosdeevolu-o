/*
 * Evoluções personalizadas — organizar "Minhas evoluções" ARRASTANDO (sem botão de "organizar").
 *   - modelo sobre outro modelo: muda a ordem (e passa para a pasta do outro, se for o caso);
 *   - modelo sobre o nome de uma pasta (ou sobre a pasta vazia): entra nessa pasta, no fim;
 *   - modelo de uma pasta solto na área de baixo ("Solte aqui para tirar o modelo da pasta"): sai da pasta;
 *   - pasta (pelo cabeçalho) sobre outra pasta: muda a ordem das pastas.
 * Quem não consegue arrastar tem Alt+↑/↓ (no modelo ou na pasta) e "📁 Mover" (personalizados-ui.js / -pastas-ui.js).
 * Carregue antes de personalizados-ui.js (a lista chama P.Arrastar.linha / .pasta / .lista ao se desenhar).
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var A = P.Arrastar = {};
  var TIPO = "application/x-modelo-lista";
  var arr = null;          // o que está sendo arrastado: { tipo: "modelo" | "pasta", id }
  var destino = null;      // onde cairia, calculado no dragover

  function comecar(e, tipo, id, el, caixaClasse) {
    arr = { tipo: tipo, id: id };
    try { e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData(TIPO, id); } catch (x) { /* sem problema */ }
    el.classList.add("arrastando");
    var cx = el.closest(".pers-lista"); if (cx && caixaClasse) cx.classList.add(caixaClasse);
  }
  function terminar() {
    arr = null; destino = null;
    Array.prototype.forEach.call(document.querySelectorAll("#lista-modelos .arrastando"), function (x) { x.classList.remove("arrastando"); });
    Array.prototype.forEach.call(document.querySelectorAll("#lista-modelos .pers-lista"), function (x) { x.classList.remove("de-pasta"); });
    limparMarcas();
  }
  function limparMarcas() {
    Array.prototype.forEach.call(document.querySelectorAll("#lista-modelos .arr-antes, #lista-modelos .arr-depois, #lista-modelos .arr-dentro"), function (x) {
      x.classList.remove("arr-antes", "arr-depois", "arr-dentro");
    });
  }
  var pidDe = function (el) { var g = el.closest(".pasta-grupo"); return g ? g.dataset.pid : ""; };
  var metade = function (el, e) { var r = el.getBoundingClientRect(); return e.clientY > r.top + r.height / 2; };

  // Uma linha de modelo pode ser arrastada
  A.linha = function (linha) {
    linha.draggable = true;
    linha.addEventListener("dragstart", function (e) { comecar(e, "modelo", linha.dataset.rid, linha, pidDe(linha) ? "de-pasta" : ""); });
    linha.addEventListener("dragend", terminar);
  };
  // O cabeçalho de uma pasta pode ser arrastado (muda a ordem das pastas)
  A.pasta = function (grupo, cab) {
    cab.draggable = true;
    cab.addEventListener("dragstart", function (e) { comecar(e, "pasta", grupo.dataset.pid, grupo, ""); });
    cab.addEventListener("dragend", terminar);
  };

  // Calcula onde o que está sendo arrastado cairia e mostra a marca (linha teal antes/depois ou contorno "dentro")
  function calcular(e) {
    var alvo = e.target && e.target.closest ? e.target : null, d = null;
    limparMarcas();
    if (!alvo) return null;
    if (arr.tipo === "modelo") {
      var linha = alvo.closest(".linha-modelo"), grupo = alvo.closest(".pasta-grupo"), soltos = alvo.closest(".pers-soltos");
      if (linha && linha.dataset.rid !== arr.id) {
        var dep = metade(linha, e);
        linha.classList.add(dep ? "arr-depois" : "arr-antes");
        d = { pid: pidDe(linha), ref: linha.dataset.rid, depois: dep };
      } else if (linha) d = null;                                   // em cima de si mesmo: nada muda
      else if (grupo) { grupo.classList.add("arr-dentro"); d = { pid: grupo.dataset.pid }; }
      else if (soltos) { soltos.classList.add("arr-dentro"); d = { pid: "" }; }
    } else {
      var g = alvo.closest(".pasta-grupo");
      if (g && g.dataset.pid !== arr.id) {
        var dp = metade(g, e);
        g.classList.add(dp ? "arr-depois" : "arr-antes");
        d = { ref: g.dataset.pid, depois: dp };
      } else if (!g && alvo.closest(".pers-soltos")) {                // abaixo de todas as pastas: vai para o fim
        var todas = document.querySelectorAll("#lista-modelos .pasta-grupo"), ult = todas[todas.length - 1];
        if (ult && ult.dataset.pid !== arr.id) { ult.classList.add("arr-depois"); d = { fim: true }; }
      }
    }
    return d;
  }

  function soltarModelo(d) {
    var rec = P.lista.filter(function (r) { return r.id === arr.id; })[0];
    if (!rec) return;
    var antes = rec.pasta && P.pastaPorId(rec.pasta) ? rec.pasta : "";
    P.colocarNaPasta(rec, d.pid);
    P.lista.splice(P.lista.indexOf(rec), 1);
    var ref = d.ref ? P.lista.filter(function (r) { return r.id === d.ref; })[0] : null, pos;
    if (ref) pos = P.lista.indexOf(ref) + (d.depois ? 1 : 0);
    else {                                                           // no fim do grupo de destino
      var mesmos = P.modelosDaPasta(d.pid);
      pos = mesmos.length ? P.lista.indexOf(mesmos[mesmos.length - 1]) + 1 : P.lista.length;
    }
    P.lista.splice(pos, 0, rec);
    P.numerar();
    if (d.pid) P.lembrarPasta(d.pid, true);                         // a pasta abre, para o modelo aparecer
    P.gravar(); P.renderMenu();
    var b = document.querySelector('#lista-modelos .linha-modelo[data-rid="' + rec.id + '"] .item-modelo'); if (b) b.focus({ preventScroll: true });
    var f = P.pastaPorId(d.pid);
    P.mostrarStatus(d.pid === antes ? "Ordem atualizada." : f ? "“" + rec.nome + "” agora está na pasta “" + f.nome + "”." : "“" + rec.nome + "” agora está fora das pastas.");
  }

  function soltarPasta(d) {
    var f = P.pastaPorId(arr.id); if (!f) return;
    P.pastas.splice(P.pastas.indexOf(f), 1);
    var ref = d.ref ? P.pastaPorId(d.ref) : null;
    P.pastas.splice(ref ? P.pastas.indexOf(ref) + (d.depois ? 1 : 0) : P.pastas.length, 0, f);
    P.pastas.forEach(function (x, k) { x.ordem = k; });
    P.salvarPastas(); P.renderMenu();
    var bt = document.querySelector('#lista-modelos .pasta-grupo[data-pid="' + f.id + '"] .pasta-toggle'); if (bt) bt.focus({ preventScroll: true });
    P.mostrarStatus("Ordem das pastas atualizada.");
  }

  // A caixa da lista recebe o que é solto (é refeita a cada desenho do menu)
  A.lista = function (caixa) {
    caixa.addEventListener("dragover", function (e) {
      if (!arr) return;
      destino = calcular(e);
      if (destino) { e.preventDefault(); e.dataTransfer.dropEffect = "move"; }
    });
    caixa.addEventListener("dragleave", function (e) { if (arr && !caixa.contains(e.relatedTarget)) { limparMarcas(); destino = null; } });
    caixa.addEventListener("drop", function (e) {
      if (!arr) return;
      e.preventDefault();
      var d = calcular(e) || destino, tipo = arr.tipo;
      if (d) { if (tipo === "modelo") soltarModelo(d); else soltarPasta(d); }
      terminar();
    });
  };
})();
