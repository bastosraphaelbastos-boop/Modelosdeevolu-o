﻿# Atualizador/lançador do app Modelos de Evolução.
# Só existe no computador se a função de atualização automática estiver LIGADA (app\atualizacao.json: "ativa": true).
# O atalho da área de trabalho chama este script; ele confere (no máximo uma vez por dia) se há versão nova,
# instala se a assinatura digital e o pacote estiverem corretos, e SEMPRE abre o app no final (mesmo com qualquer erro).
# Nunca toca em meus-modelos\, em atualizador\ nem no perfil do navegador.
# Parâmetros: -Verificar (só confere configuração e chave; sem rede, não abre nada; sai 0 se estiver tudo certo).
# Só para testes: -UrlManifesto, -PastaEstado, -NaoAbrir, -Hoje (AAAA-MM-DD).
param(
  [switch]$Verificar,
  [string]$UrlManifesto,
  [string]$PastaEstado,
  [switch]$NaoAbrir,
  [string]$Hoje
)

$ErrorActionPreference = "Stop"
$pasta = $PSScriptRoot
$Destino = Split-Path $pasta -Parent
$arqLancar = Join-Path $pasta "lancar.json"
$arqConfig = Join-Path $pasta "atualizacao.json"
$arqChave = Join-Path $pasta "atualizacao-chave.xml"
$MAX_ZIP = 30MB
$EXT_OK = @(".html", ".js", ".css", ".png", ".ico", ".svg")
$script:permitirLocal = [bool]$UrlManifesto   # http://127.0.0.1 só quando se passa -UrlManifesto (teste)
$script:form = $null
$lancar = $null

function Ler-Texto($arq) { [IO.File]::ReadAllText($arq, [Text.Encoding]::UTF8).TrimStart([char]0xFEFF) }

function Carregar-Chave {
  $rsa = New-Object Security.Cryptography.RSACryptoServiceProvider
  $rsa.PersistKeyInCsp = $false
  $rsa.FromXmlString((Ler-Texto $arqChave))
  if (-not $rsa.PublicOnly) { throw "o arquivo da chave tem parte privada" }
  return $rsa
}

# ---------- -Verificar: só confere que o PowerShell executa o script e lê configuração + chave ----------
if ($Verificar) {
  try {
    $l = Ler-Texto $arqLancar | ConvertFrom-Json
    if (-not $l.pagina -or ($l.navegador -and -not $l.argumentos)) { throw "lancar.json incompleto" }
    $c = Ler-Texto $arqConfig | ConvertFrom-Json
    if ($c.ativa -isnot [bool]) { throw "atualizacao.json invalido" }
    if (-not ([string]$c.manifesto).StartsWith("https://", [StringComparison]::OrdinalIgnoreCase)) { throw "manifesto sem https" }
    [void](Carregar-Chave)
    exit 0
  } catch { exit 1 }
}

# ---------- estado e log ----------
if (-not $PastaEstado) { $PastaEstado = Join-Path $env:LOCALAPPDATA "ModelosEvolucao" }
$arqLog = Join-Path $PastaEstado "atualizacao.log"
$arqEstado = Join-Path $PastaEstado "atualizacao-estado.json"
$utf8 = New-Object Text.UTF8Encoding($false)
$hojeTxt = (Get-Date).ToString("yyyy-MM-dd")
if ($Hoje -and $Hoje -match '^\d{4}-\d{2}-\d{2}$') { $hojeTxt = $Hoje }

function Log($msg) {
  try {
    New-Item -ItemType Directory -Force $PastaEstado | Out-Null
    $linhas = @()
    if (Test-Path -LiteralPath $arqLog) { $linhas = @([IO.File]::ReadAllLines($arqLog, $utf8)) }
    $linhas += ((Get-Date).ToString("yyyy-MM-dd HH:mm:ss") + "  " + $msg)
    if ($linhas.Count -gt 300) { $linhas = $linhas[($linhas.Count - 300)..($linhas.Count - 1)] }
    [IO.File]::WriteAllLines($arqLog, [string[]]$linhas, $utf8)
  } catch { }
}
function Ler-Estado {
  try { return [string]((Ler-Texto $arqEstado | ConvertFrom-Json).ultimaConsulta) } catch { return "" }
}
function Gravar-Estado {
  try {
    New-Item -ItemType Directory -Force $PastaEstado | Out-Null
    [IO.File]::WriteAllText($arqEstado, ('{"ultimaConsulta":"' + $hojeTxt + '"}'), $utf8)
  } catch { Log "Nao foi possivel gravar a data da consulta." }
}

# ---------- janelinha de espera ----------
function Mostrar-Janela($texto) {
  if ($NaoAbrir) { return }
  try {
    Add-Type -AssemblyName System.Windows.Forms
    $f = New-Object Windows.Forms.Form
    $f.Text = "Modelos de Evolução"
    $f.StartPosition = "CenterScreen"
    $f.FormBorderStyle = "FixedDialog"
    $f.ControlBox = $false
    $f.TopMost = $true
    $f.ClientSize = New-Object Drawing.Size(480, 90)
    $r = New-Object Windows.Forms.Label
    $r.Text = $texto
    $r.Dock = "Fill"
    $r.TextAlign = "MiddleCenter"
    $r.Font = New-Object Drawing.Font("Segoe UI", 11)
    $f.Controls.Add($r)
    $f.Show()
    [Windows.Forms.Application]::DoEvents()
    $script:form = $f
  } catch { $script:form = $null }
}
function Fechar-Janela {
  if ($script:form) { try { $script:form.Close(); $script:form.Dispose() } catch { }; $script:form = $null }
}
function Bombear { if ($script:form) { try { [Windows.Forms.Application]::DoEvents() } catch { } } }

# ---------- regras de endereço ----------
function Url-Permitida([string]$u) {
  $uri = $null
  if (-not [Uri]::TryCreate($u, [UriKind]::Absolute, [ref]$uri)) { return $false }
  if ($uri.Scheme -eq "https") { return $true }
  if ($script:permitirLocal -and $uri.Scheme -eq "http" -and $uri.IsLoopback) { return $true }
  return $false
}
function Host-Permitido([string]$u) {
  $uri = [Uri]$u
  $h = $uri.Host.ToLowerInvariant()
  if ($h -eq "github.com" -or $h.EndsWith(".githubusercontent.com")) { return $true }
  if ($script:permitirLocal -and $uri.IsLoopback) { return $true }
  return $false
}

# ---------- rede: roda numa linha de execução separada, com prazo duro ----------
$blocoRede = {
  param([string]$url, [int64]$maxBytes, [int]$limiteMs, [bool]$permitirLocal)
  try {
    $cron = [Diagnostics.Stopwatch]::StartNew()
    $atual = $url
    for ($salto = 0; $salto -le 5; $salto++) {
      $uri = $null
      if (-not [Uri]::TryCreate($atual, [UriKind]::Absolute, [ref]$uri)) { return [pscustomobject]@{ Ok = $false; Erro = "RECUSA: endereco invalido" } }
      $okUrl = ($uri.Scheme -eq "https") -or ($permitirLocal -and $uri.Scheme -eq "http" -and $uri.IsLoopback)
      if (-not $okUrl) { return [pscustomobject]@{ Ok = $false; Erro = "RECUSA: endereco nao permitido (so https)" } }
      $req = [Net.HttpWebRequest]::Create($uri)
      $req.AllowAutoRedirect = $false
      $req.UserAgent = "ModelosEvolucao-Atualizador"
      $req.KeepAlive = $false
      $req.ReadWriteTimeout = 5000
      if ($uri.IsLoopback) { $req.Proxy = $null }
      else {
        $req.Proxy = [Net.WebRequest]::GetSystemWebProxy()
        $req.Proxy.Credentials = [Net.CredentialCache]::DefaultCredentials
      }
      $ar = $req.BeginGetResponse($null, $null)
      while (-not $ar.IsCompleted) {
        if ($cron.ElapsedMilliseconds -ge $limiteMs) { $req.Abort(); return [pscustomobject]@{ Ok = $false; Erro = "REDE: tempo esgotado" } }
        [void]$ar.AsyncWaitHandle.WaitOne(40)
      }
      $resp = $null
      try { $resp = $req.EndGetResponse($ar) }
      catch [Net.WebException] {
        $resp = $_.Exception.Response
        if (-not $resp) { return [pscustomobject]@{ Ok = $false; Erro = ("REDE: " + $_.Exception.Message) } }
      }
      $codigo = [int]$resp.StatusCode
      if ($codigo -ge 300 -and $codigo -lt 400) {
        $loc = $resp.Headers["Location"]
        $resp.Close()
        if (-not $loc) { return [pscustomobject]@{ Ok = $false; Erro = "REDE: redirecionamento sem destino" } }
        $atual = (New-Object Uri -ArgumentList $uri, $loc).AbsoluteUri
        continue
      }
      if ($codigo -ne 200) { $resp.Close(); return [pscustomobject]@{ Ok = $false; Erro = "REDE: servidor respondeu $codigo" } }
      if ($resp.ContentLength -gt $maxBytes) { $resp.Close(); return [pscustomobject]@{ Ok = $false; Erro = "RECUSA: arquivo maior que o limite permitido" } }
      $st = $resp.GetResponseStream()
      $ms = New-Object IO.MemoryStream
      $buf = New-Object byte[] 65536
      while ($true) {
        $ar2 = $st.BeginRead($buf, 0, $buf.Length, $null, $null)
        while (-not $ar2.IsCompleted) {
          if ($cron.ElapsedMilliseconds -ge $limiteMs) { $req.Abort(); return [pscustomobject]@{ Ok = $false; Erro = "REDE: tempo esgotado" } }
          [void]$ar2.AsyncWaitHandle.WaitOne(40)
        }
        $n = $st.EndRead($ar2)
        if ($n -le 0) { break }
        $ms.Write($buf, 0, $n)
        if ($ms.Length -gt $maxBytes) { $req.Abort(); return [pscustomobject]@{ Ok = $false; Erro = "RECUSA: arquivo maior que o limite permitido" } }
      }
      $resp.Close()
      return [pscustomobject]@{ Ok = $true; Bytes = $ms.ToArray() }
    }
    return [pscustomobject]@{ Ok = $false; Erro = "REDE: redirecionamentos demais" }
  } catch {
    return [pscustomobject]@{ Ok = $false; Erro = ("REDE: " + $_.Exception.Message) }
  }
}

function Buscar([string]$url, [int64]$maxBytes, [int]$limiteMs) {
  $ps = [PowerShell]::Create()
  [void]$ps.AddScript($blocoRede.ToString()).AddArgument($url).AddArgument($maxBytes).AddArgument($limiteMs).AddArgument([bool]$script:permitirLocal)
  $ar = $ps.BeginInvoke()
  $cron = [Diagnostics.Stopwatch]::StartNew()
  while (-not $ar.IsCompleted) {
    if ($cron.ElapsedMilliseconds -ge ($limiteMs + 1500)) {
      [void]$ps.BeginStop($null, $null)
      return [pscustomobject]@{ Ok = $false; Erro = "REDE: tempo esgotado" }
    }
    Start-Sleep -Milliseconds 40
    Bombear
  }
  try { $res = $ps.EndInvoke($ar) } catch { return [pscustomobject]@{ Ok = $false; Erro = ("REDE: " + $_.Exception.Message) } }
  try { $ps.Dispose() } catch { }
  if ($res.Count -gt 0 -and $res[0].PSObject.Properties["Ok"]) { return $res[0] }
  return [pscustomobject]@{ Ok = $false; Erro = "REDE: resposta vazia" }
}

# ---------- versões e conferências ----------
function Partes-Versao([string]$v) {
  if ($v -notmatch '^\d{1,6}(\.\d{1,6}){0,3}$') { throw "versao invalida: $v" }
  return @($v.Split(".") | ForEach-Object { [int]$_ })
}
function Comparar-Versao([string]$a, [string]$b) {
  $pa = Partes-Versao $a; $pb = Partes-Versao $b
  $n = [Math]::Max($pa.Count, $pb.Count)
  for ($i = 0; $i -lt $n; $i++) {
    $x = 0; $y = 0
    if ($i -lt $pa.Count) { $x = $pa[$i] }
    if ($i -lt $pb.Count) { $y = $pb[$i] }
    if ($x -gt $y) { return 1 }
    if ($x -lt $y) { return -1 }
  }
  return 0
}
function Versao-De-Arquivo([string]$arq) {
  $m = [regex]::Match((Ler-Texto $arq), 'APP_VERSAO\s*=\s*"([^"]+)"')
  if (-not $m.Success) { throw "nao achei a versao em versao.js" }
  return $m.Groups[1].Value
}
function Motivo-Entrada-Proibida([string]$nome) {
  if ($nome.Contains(":")) { return "dois-pontos" }
  if ($nome.StartsWith("/") -or $nome.StartsWith("\")) { return "caminho absoluto" }
  if ($nome -match '[\x00-\x1F]') { return "caractere de controle" }
  $ehPasta = $nome.EndsWith("/") -or $nome.EndsWith("\")
  $partes = $nome.Replace("\", "/").TrimEnd("/").Split("/")
  foreach ($p in $partes) {
    if ($p -eq "" -or $p -eq "." -or $p -eq "..") { return "caminho com . ou .." }
    if ($p.EndsWith(".") -or $p.EndsWith(" ")) { return "nome terminando em ponto ou espaco" }
  }
  $raiz = $partes[0]
  if ($raiz -ceq "ABRIR.html") { if ($ehPasta -or $partes.Count -ne 1) { return "ABRIR.html invalido" } }
  elseif ($raiz -ceq "app" -or $raiz -ceq "modelos") { if ($partes.Count -lt 2 -and -not $ehPasta) { return "arquivo solto fora das pastas" } }
  else { return "fora de ABRIR.html/app/modelos" }
  if (-not $ehPasta) {
    $ext = [IO.Path]::GetExtension($partes[$partes.Count - 1]).ToLowerInvariant()
    if ($EXT_OK -notcontains $ext) { return "extensao nao permitida ($ext)" }
  }
  return $null
}

function Achar-JanelaAberta([string]$perfil) {
  try {
    $p = $perfil.TrimEnd("\")
    return @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe' OR Name='chrome.exe'" |
      Where-Object { $_.CommandLine -and $_.CommandLine.IndexOf($p, [StringComparison]::OrdinalIgnoreCase) -ge 0 })
  } catch { return @() }
}

# ---------- a troca de arquivos (com volta atrás) ----------
function Trocar-Arquivos([string]$stage) {
  $itens = "ABRIR.html", "app", "modelos"
  $ant = Join-Path $Destino "_anterior"
  if (Test-Path -LiteralPath $ant) { Remove-Item -LiteralPath $ant -Recurse -Force }
  New-Item -ItemType Directory $ant | Out-Null
  $tirados = @(); $postos = @()
  try {
    foreach ($i in $itens) {
      $a = Join-Path $Destino $i
      if (Test-Path -LiteralPath $a) { Move-Item -LiteralPath $a -Destination (Join-Path $ant $i) -ErrorAction Stop; $tirados += $i }
    }
    foreach ($i in $itens) {
      Move-Item -LiteralPath (Join-Path $stage $i) -Destination (Join-Path $Destino $i) -ErrorAction Stop
      $postos += $i
    }
  } catch {
    Log ("Falha na troca de arquivos: " + $_.Exception.Message + " - voltando a versao anterior.")
    foreach ($i in $postos) { try { Remove-Item -LiteralPath (Join-Path $Destino $i) -Recurse -Force } catch { Log "Nao consegui remover o item novo $i." } }
    foreach ($i in $tirados) {
      try {
        if (-not (Test-Path -LiteralPath (Join-Path $Destino $i))) { Move-Item -LiteralPath (Join-Path $ant $i) -Destination (Join-Path $Destino $i) -ErrorAction Stop }
      } catch { Log "ATENCAO: nao consegui restaurar $i de _anterior." }
    }
    throw "RECUSA: a troca falhou; a versao anterior foi mantida."
  }
}

# ---------- o processo de atualização ----------
function Tentar-Atualizar {
  $cfg = Ler-Texto $arqConfig | ConvertFrom-Json
  if (-not ($cfg.ativa -is [bool] -and $cfg.ativa -eq $true)) { return }          # desligada: só abre o app
  if ((Ler-Estado) -eq $hojeTxt) { return }                                        # já consultou hoje
  $perfil = $null
  if ($lancar -and $lancar.argumentos) {
    $mp = [regex]::Match([string]$lancar.argumentos, '--user-data-dir="([^"]+)"')
    if ($mp.Success) { $perfil = $mp.Groups[1].Value }
  }
  if ($perfil -and @(Achar-JanelaAberta $perfil).Count -gt 0) { Log "Janela do app ja aberta: nao atualiza agora."; return }

  $urlM = [string]$cfg.manifesto
  if ($UrlManifesto) { $urlM = $UrlManifesto }
  if (-not (Url-Permitida $urlM)) { Log "RECUSADO: endereco do manifesto nao permitido (so https)."; return }
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

  # 1) manifesto + assinatura (prazo total de ~4 s)
  $cron = [Diagnostics.Stopwatch]::StartNew()
  $rm = Buscar $urlM 65536 4000
  if (-not $rm.Ok) {
    if ($rm.Erro -like "RECUSA*") { Log ("RECUSADO: manifesto - " + $rm.Erro); Gravar-Estado } else { Log ("Sem consulta (" + $rm.Erro + "); tenta na proxima abertura.") }
    return
  }
  $rs = Buscar ($urlM + ".sig") 4096 ([Math]::Max(500, 4000 - [int]$cron.ElapsedMilliseconds))
  if (-not $rs.Ok) {
    if ($rs.Erro -like "RECUSA*") { Log ("RECUSADO: assinatura - " + $rs.Erro); Gravar-Estado } else { Log ("Sem consulta (" + $rs.Erro + "); tenta na proxima abertura.") }
    return
  }
  # a partir daqui a consulta foi feita: qualquer desfecho grava a data (nao repete o dia todo)
  try {
    $bytesM = [byte[]]$rm.Bytes
    $assin = [Convert]::FromBase64String(([Text.Encoding]::ASCII.GetString([byte[]]$rs.Bytes)).Trim())
    $rsa = Carregar-Chave
    if (-not $rsa.VerifyData($bytesM, "SHA256", $assin)) { Log "RECUSADO: assinatura do manifesto invalida."; return }
  } catch { Log ("RECUSADO: nao foi possivel verificar a assinatura (" + $_.Exception.Message + ")."); return }

  # 2) o que o manifesto diz
  $m = [Text.Encoding]::UTF8.GetString($bytesM).TrimStart([char]0xFEFF) | ConvertFrom-Json
  $novaV = [string]$m.versao
  $arquivoUrl = [string]$m.arquivo
  $sha = ([string]$m.sha256).ToLowerInvariant()
  $tam = [int64]$m.tamanho
  [void](Partes-Versao $novaV)
  if ($sha -notmatch '^[0-9a-f]{64}$') { Log "RECUSADO: sha256 do manifesto invalido."; return }
  if ($tam -le 0 -or $tam -gt $MAX_ZIP) { Log "RECUSADO: tamanho do pacote fora do limite (30 MB)."; return }
  $atualV = Versao-De-Arquivo (Join-Path $Destino "app\versao.js")
  if ((Comparar-Versao $novaV $atualV) -le 0) { Log "App em dia (instalada $atualV, publicada $novaV)."; Gravar-Estado; return }
  if (-not (Url-Permitida $arquivoUrl) -or -not (Host-Permitido $arquivoUrl)) { Log "RECUSADO: endereco do pacote nao permitido."; Gravar-Estado; return }

  Log "Versao nova $novaV disponivel (instalada $atualV)."
  Mostrar-Janela "Atualizando o app Modelos de Evolução para a versão $novaV... aguarde"

  # 3) baixa e confere o pacote
  $rz = Buscar $arquivoUrl ($tam + 1) 90000
  if (-not $rz.Ok) { Log ("Falha ao baixar o pacote (" + $rz.Erro + ")."); Gravar-Estado; return }
  $zipBytes = [byte[]]$rz.Bytes
  if ($zipBytes.Length -ne $tam) { Log "RECUSADO: tamanho do pacote diferente do manifesto."; Gravar-Estado; return }
  $h = [Security.Cryptography.SHA256]::Create()
  $hash = (($h.ComputeHash($zipBytes) | ForEach-Object { $_.ToString("x2") }) -join "")
  if ($hash -ne $sha) { Log "RECUSADO: SHA-256 do pacote diferente do manifesto."; Gravar-Estado; return }

  # 4) confere TODAS as entradas e só então extrai
  Add-Type -AssemblyName System.IO.Compression
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $stage = Join-Path $Destino "_atualizacao"
  if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
  $zip = New-Object IO.Compression.ZipArchive((New-Object IO.MemoryStream(, $zipBytes)), [IO.Compression.ZipArchiveMode]::Read)
  try {
    if ($zip.Entries.Count -gt 3000) { Log "RECUSADO: pacote com arquivos demais."; Gravar-Estado; return }
    $total = [int64]0
    foreach ($e in $zip.Entries) {
      $mot = Motivo-Entrada-Proibida $e.FullName
      if ($mot) { Log ("RECUSADO: pacote com entrada proibida (" + $mot + "): " + $e.FullName); Gravar-Estado; return }
      $total += $e.Length
    }
    if ($total -gt 150MB) { Log "RECUSADO: pacote grande demais depois de aberto."; Gravar-Estado; return }
    New-Item -ItemType Directory $stage | Out-Null
    $raizFull = [IO.Path]::GetFullPath($stage).TrimEnd("\") + "\"
    foreach ($e in $zip.Entries) {
      $rel = $e.FullName.Replace("/", "\")
      $dest = [IO.Path]::GetFullPath((Join-Path $stage $rel))
      if (-not $dest.StartsWith($raizFull, [StringComparison]::OrdinalIgnoreCase)) { throw "RECUSA: entrada fora da pasta de extracao" }
      if ($e.FullName.EndsWith("/") -or $e.FullName.EndsWith("\")) { New-Item -ItemType Directory -Force $dest | Out-Null; continue }
      New-Item -ItemType Directory -Force (Split-Path $dest -Parent) | Out-Null
      [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $dest, $true)
    }
  } finally { $zip.Dispose() }

  # 5) o pacote extraído precisa ser um app completo e da versão prometida
  foreach ($req in "ABRIR.html", "app\versao.js") {
    if (-not (Test-Path -LiteralPath (Join-Path $stage $req) -PathType Leaf)) { Log "RECUSADO: pacote sem $req."; Remove-Item -LiteralPath $stage -Recurse -Force; Gravar-Estado; return }
  }
  if (-not (Test-Path -LiteralPath (Join-Path $stage "modelos") -PathType Container)) { Log "RECUSADO: pacote sem a pasta modelos."; Remove-Item -LiteralPath $stage -Recurse -Force; Gravar-Estado; return }
  $vPacote = Versao-De-Arquivo (Join-Path $stage "app\versao.js")
  if ((Comparar-Versao $vPacote $novaV) -ne 0) { Log "RECUSADO: versao dentro do pacote ($vPacote) diferente do manifesto ($novaV)."; Remove-Item -LiteralPath $stage -Recurse -Force; Gravar-Estado; return }

  # 6) troca (volta atrás sozinha se algo falhar)
  Trocar-Arquivos $stage
  try { Remove-Item -LiteralPath $stage -Recurse -Force } catch { }
  Log "ATUALIZADO: $atualV -> $novaV."
  Gravar-Estado
}

function Abrir-App {
  $pagina = Join-Path $Destino "ABRIR.html"
  $nav = $null; $argu = $null
  if ($lancar) {
    if ($lancar.pagina) { $pagina = [string]$lancar.pagina }
    if ($lancar.navegador) { $nav = [string]$lancar.navegador }
    if ($lancar.argumentos) { $argu = [string]$lancar.argumentos }
  }
  if ($NaoAbrir) { Log ("abriria: " + $(if ($nav) { "$nav $argu" } else { $pagina })); return }
  try {
    if ($nav -and (Test-Path -LiteralPath $nav)) { Start-Process -FilePath $nav -ArgumentList $argu }
    else { Start-Process -FilePath $pagina }
  } catch {
    Log ("Nao consegui abrir pelo navegador (" + $_.Exception.Message + "); abrindo a pagina.")
    try { Start-Process -FilePath $pagina } catch { Log "Nao consegui abrir o app." }
  }
}

# ---------- principal: o app SEMPRE abre ----------
$mutex = $null; $temMutex = $false
try {
  try { $lancar = Ler-Texto $arqLancar | ConvertFrom-Json } catch { Log "Nao li lancar.json; abrindo ABRIR.html direto." }
  try {
    $mutex = New-Object Threading.Mutex($false, "Local\ModelosEvolucaoAtualizador")
    try { $temMutex = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $temMutex = $true }
  } catch { $temMutex = $true }
  if ($temMutex) { Tentar-Atualizar } else { Log "Outro atualizador ja esta rodando; so abre o app." }
} catch {
  $msg = $_.Exception.Message
  if ($msg -like "RECUSA*") { Log ("RECUSADO: " + ($msg -replace "^RECUSA:\s*", "")); Gravar-Estado } else { Log ("ERRO: " + $msg) }
} finally {
  Fechar-Janela
  if ($mutex -and $temMutex) { try { $mutex.ReleaseMutex() } catch { } }
  Abrir-App
}
exit 0
