/*
 * Motor — linhas repetidas (peça de motor.js; carregue depois de motor-modelo.js e antes de motor-tela.js).
 * No texto do modelo, {mais#chave:Rótulo} (sozinho numa linha) vira um botão "＋ Rótulo" na tela. Cada clique acrescenta uma cópia da linha
 * modelo.repetir[chave] logo acima do botão, com um ✕ para tirar só aquela linha. Exemplo, no modelo:
 *     repetir: { lab: "- LABORATÓRIO ({campo#@_data:data}): {campo#@_res:resultados}" }
 * "#@" vira "#chave" + número da cópia (lab2_data, lab3_data...): os campos da cópia têm NOME próprio e único, assim os campos sem nome
 * (c0, c1...) continuam com os mesmos números e nada do que já foi preenchido se perde. Use sempre campos com nome dentro de "repetir".
 * As cópias moram no próprio segmento "mais" (s.copias = [{ n, filhos }]); trocar de modelo ou "Nova paciente" refaz os segmentos e zera tudo.
 * Esta peça só mexe nos segmentos e nos valores; quem desenha na tela é motor-tela.js.
 * M.Repetir = { MAX, adicionar(s, modelo, valores), remover(s, copia, valores) }.
 */
(function () {
  "use strict";
  var M = window.MotorPecas = window.MotorPecas || {};
  var MAX = 10;                       // no máximo 10 linhas a mais por botão

  // ids dos campos de uma cópia (para apagar os valores quando ela é tirada)
  function ids(segs, lista) {
    segs.forEach(function (s) { if (s.filhos) ids(s.filhos, lista); else if (s.id) lista.push(s.id); });
    return lista;
  }

  // Cria a próxima cópia (ou devolve null: sem modelo de linha, ou já no máximo). Os valores iniciais da cópia entram em `valores`.
  function adicionar(s, modelo, valores) {
    var texto = modelo && modelo.repetir && modelo.repetir[s.chave];
    if (!texto || s.copias.length >= MAX) return null;
    var n = s.prox++;
    var filhos = M.Modelo.interpretar(texto.replace(/#@/g, "#" + s.chave + n));
    var c = { n: n, filhos: filhos };
    s.copias.push(c);
    M.Modelo.valoresIniciais(filhos, valores);
    return c;
  }

  function remover(s, c, valores) {
    ids(c.filhos, []).forEach(function (id) { delete valores[id]; });
    s.copias.splice(s.copias.indexOf(c), 1);
  }

  M.Repetir = { MAX: MAX, adicionar: adicionar, remover: remover };
})();
