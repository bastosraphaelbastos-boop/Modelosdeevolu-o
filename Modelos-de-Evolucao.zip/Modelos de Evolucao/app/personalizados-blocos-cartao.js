/*
 * Modo "Blocos" do criador — o cartão de um bloco (alça, corpo, botões ↑ ↓ 🗑, título com ▾) e o arrastar e soltar entre cartões
 * (parte de personalizados-blocos.js; carregue depois dele). Registra em B._f: cartao, limparSolta, destinoSolta.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var B = P.Blocos = P.Blocos || {};
  var I = function () { return P._ed; };            // peças do criador (personalizados-editor.js)
  var st = null; B.aoMudarEstado(function (x) { st = x; });
  var Base = P.BlocosBase, Sec = P.BlocosSecoes;
  var tipo = Base.tipo, mostrar = Base.mostrar, TIPOS = Base.TIPOS;
  var fimSecao = Sec.fimSecao, trecho = Sec.trecho, ajustarTitulo = Sec.ajustarTitulo, alternar = Sec.alternar;
  var ativar = function (i, c) { return B._f.ativar(i, c); }, subir = function (i, s) { return B._f.subir(i, s); },
      descer = function (i, s) { return B._f.descer(i, s); }, apagar = function (i, s) { return B._f.apagar(i, s); };

  function el(tag, classe, texto) { return I().el(tag, classe, texto); }

  function cartao(u, i) {
    var tp = tipo(u), secao = tp === "titulo";
    var c = el("div", "bl-cartao bl-" + tp); c.dataset.i = String(i);
    var alca = el("span", "bl-alca", "⋮⋮"); alca.title = secao ? "Arraste para mudar a ordem da seção inteira (com Shift, só o título)" : "Arraste para mudar a ordem";
    alca.setAttribute("aria-hidden", "true");
    alca.addEventListener("mousedown", function () { if (!c.classList.contains("bl-aberto")) c.draggable = true; });
    alca.addEventListener("mouseup", function () { c.draggable = false; });
    var corpo = el("div", "bl-corpo ep-previa");
    corpo.tabIndex = 0;
    corpo.setAttribute("role", "button");
    corpo.setAttribute("aria-label", "Bloco " + (i + 1) + " (" + TIPOS[tp] + "): clique para escrever");
    corpo.title = "Clique para escrever neste bloco";
    mostrar(u, corpo);
    corpo.addEventListener("mousedown", function () { c.draggable = false; });
    corpo.addEventListener("click", function (e) { if (e.target.closest("button")) return; ativar(+c.dataset.i); });
    corpo.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); ativar(+c.dataset.i); } });
    var lado = el("div", "bl-lado");
    lado.appendChild(el("span", "bl-tipo", TIPOS[tp]));
    var acoes = el("div", "bl-acoes");
    if (secao) {
      var tg = el("button", "bl-ac bl-recolher"); tg.type = "button";
      tg.addEventListener("click", function () { alternar(+c.dataset.i); });
      acoes.appendChild(tg);
    }
    var sobe = I().botao("bl-ac", "", "↑", function (e) { subir(+c.dataset.i, e.shiftKey); });
    var desce = I().botao("bl-ac", "", "↓", function (e) { descer(+c.dataset.i, e.shiftKey); });
    var apaga = I().botao("bl-ac bl-apagar", "", "🗑", function (e) { apagar(+c.dataset.i, e.shiftKey); });
    sobe.title = secao ? "Subir esta seção (o título e os blocos dele). Com Shift: só o título" : "Subir este bloco";
    desce.title = secao ? "Descer esta seção (o título e os blocos dele). Com Shift: só o título" : "Descer este bloco";
    apaga.title = secao ? "Apagar esta seção (o título e os blocos dele). Com Shift: só o título" : "Apagar este bloco";
    sobe.setAttribute("aria-label", "Subir " + (secao ? "a seção do bloco " : "o bloco ") + (i + 1));
    desce.setAttribute("aria-label", "Descer " + (secao ? "a seção do bloco " : "o bloco ") + (i + 1));
    apaga.setAttribute("aria-label", "Apagar " + (secao ? "a seção do bloco " : "o bloco ") + (i + 1));
    if (i === 0) sobe.disabled = true;
    if ((secao ? fimSecao(i) : i + 1) >= st.unidades.length) desce.disabled = true;
    acoes.appendChild(sobe); acoes.appendChild(desce); acoes.appendChild(apaga);
    lado.appendChild(acoes);
    c.appendChild(alca); c.appendChild(corpo); c.appendChild(lado);
    if (secao) ajustarTitulo(c, i);

    // arrastar e soltar (num título arrasta a seção inteira; com Shift, só o título)
    c.addEventListener("dragstart", function (e) {
      var t = trecho(+c.dataset.i, e.shiftKey);
      st.arrastando = t[0]; st.arrN = t[1] - t[0];
      try { e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("application/x-bloco", String(st.arrastando)); } catch (x) { /* sem problema */ }
      for (var k = t[0]; k < t[1]; k++) if (st.lista.children[k]) st.lista.children[k].classList.add("bl-arrastando");
    });
    c.addEventListener("dragend", function () {
      c.draggable = false; st.arrastando = null;
      Array.prototype.forEach.call(st.lista.querySelectorAll(".bl-arrastando"), function (x) { x.classList.remove("bl-arrastando"); });
      limparSolta();
    });
    return c;
  }

  function limparSolta() {
    Array.prototype.forEach.call(st.lista.querySelectorAll(".bl-solta-antes, .bl-solta-depois"), function (x) { x.classList.remove("bl-solta-antes", "bl-solta-depois"); });
  }
  function destinoSolta(e) {                         // { cartao, depois } sob o ponteiro (só cartões à vista)
    var c = e.target.closest && e.target.closest(".bl-cartao");
    if (!c || !st.lista.contains(c) || c.classList.contains("bl-oculto")) {
      var todos = st.lista.querySelectorAll(".bl-cartao:not(.bl-oculto)");
      if (!todos.length) return null;
      c = todos[todos.length - 1];
      return { cartao: c, depois: true };
    }
    var r = c.getBoundingClientRect();
    return { cartao: c, depois: e.clientY > r.top + r.height / 2 };
  }

  B._f.cartao = cartao; B._f.limparSolta = limparSolta; B._f.destinoSolta = destinoSolta;
})();
