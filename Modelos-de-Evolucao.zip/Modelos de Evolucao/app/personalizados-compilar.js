/*
 * Evoluções personalizadas — o COMPILADOR das regras simples (parte de personalizados.js; carregue logo depois dele).
 *   P.compilar(texto)      regras simples -> sintaxe nativa do motor { saida, erros, avisos, calculos, estrutura }
 *   P.validar(nome, texto) confere nome + texto do modelo inteiro
 *   P.mensagem(x)          texto de um erro/aviso com o número da linha
 * Os padrões, os escapes e a leitura de ((instruções)) vêm de personalizados.js (P._reg, P.lerInstrucao, P.limpar, P.semPriv).
 * A sintaxe das regras está no comentário de personalizados.js.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var R = P._reg, PALAVRA = R.PALAVRA, TIPOS = R.TIPOS, RE_CAB = R.RE_CAB, RE_TOK = R.RE_TOK, RE_BARRA = R.RE_BARRA, ESCAPAVEIS = R.ESCAPAVEIS, priv = R.priv;

  // ---------- compilar: regras simples -> sintaxe nativa ----------
  // Devolve { saida, erros:[{linha,msg}], avisos:[{linha,msg}], calculos:[...], estrutura:{escolhas,ses,datas} }
  P.compilar = function (texto) {
    var t = P.limpar(texto), erros = [], avisos = [], blocos = [], defs = {}, ids = {}, datas = {}, marcas = 0;
    var cands = [], escInfo = [], seInfo = [], diasUsos = [];
    var erro = function (l, m) { erros.push({ linha: l, msg: P.semPriv(m) }); };
    var aviso = function (l, m) { avisos.push({ linha: l, msg: P.semPriv(m) }); };
    var desescapar = function (s) { return s.replace(/\\([\[\]*{}\\()])/g, function (x, ch) { return priv(ch); }); };
    var contarLinhas = function (s) { return (s.match(/\n/g) || []).length; };

    // opções de [A / B] ou [? P? A / B]: devolve a lista sem repetidas, ou null (e registra o erro)
    function validarOpcoes(s, ops, l) {
      for (var k = 0; k < ops.length; k++) {
        if (!ops[k] || RE_BARRA.test(ops[k]) || /^\/|\/$/.test(ops[k])) { erro(l, "escolha com uma opção vazia: [" + s + "]"); return null; }
        if (ops[k].indexOf("|") !== -1) { erro(l, "não use o símbolo | nas opções: [" + s + "]"); return null; }
        if (ops[k].charAt(0) === "*") { erro(l, "uma opção não pode começar com *: [" + s + "]"); return null; }
      }
      var unicas = ops.filter(function (o, q) { return ops.indexOf(o) === q; });
      if (unicas.length < ops.length) {
        if (unicas.length < 2) { erro(l, "as opções são todas iguais: [" + s + "]"); return null; }
        aviso(l, "havia opções repetidas em [" + s + "]; as repetidas foram juntadas");
      }
      return unicas;
    }

    function novaEscolha(o, cand) {
      o.k = "esc"; o.usada = false;
      if (cand) { o.idx = escInfo.length; cands.push(o); escInfo.push(o); }
      return o;
    }

    // [@NOME], [@NOME: dica], [@NOME: dica=VALOR]  ->  {campo#nome:dica}
    function arroba(s, c, l) {
      var corpoA = s.slice(1), k = corpoA.search(/[:=]/);
      var nome = (k === -1 ? corpoA : corpoA.slice(0, k)).trim(), resto = k === -1 ? "" : corpoA.slice(k);
      var id = P.normalizarNome(nome);
      if (!id) { erro(l, "dê um nome ao espaço ligado, com letras ou números, ex.: [@INTERNAÇÃO]"); return "[" + c + "]"; }
      var arg = resto.charAt(0) === ":" ? resto.slice(1).trim() : resto.charAt(0) === "=" ? resto.trim() : nome;
      if (!datas[id]) datas[id] = { id: id, nome: nome };
      ids[id] = true;
      return "{campo#" + id + ":" + arg + "}";
    }

    // [? Pergunta? A / B]  ->  {controle:Pergunta?A|B}
    function controle(s, c, l, ini, fim, cand) {
      var q = s.slice(1).trim(), k = q.indexOf("?");
      if (k === -1) { erro(l, "a pergunta precisa terminar com ?, ex.: [? Alta hoje? NÃO / SIM]"); return "[" + c + "]"; }
      var rot = q.slice(0, k + 1).trim(), resto = q.slice(k + 1).trim();
      if (!rot.replace(/\?/g, "").trim()) { erro(l, "escreva a pergunta antes do ?, ex.: [? Alta hoje? NÃO / SIM]"); return "[" + c + "]"; }
      if (rot.indexOf("|") !== -1) { erro(l, "não use o símbolo | na pergunta: [" + s + "]"); return "[" + c + "]"; }
      if (!RE_BARRA.test(resto)) { erro(l, "depois da pergunta escreva as opções separadas por barra, ex.: [? Alta hoje? NÃO / SIM]"); return "[" + c + "]"; }
      var ops = resto.split(/\s+\/\s+/);
      if (ops.length < 2) { erro(l, "escolha com só uma opção: [" + s + "]. Use [? Pergunta? A / B]"); return "[" + c + "]"; }
      var unicas = validarOpcoes(s, ops, l);
      if (!unicas) return "[" + c + "]";
      return novaEscolha({ tipo: "controle", nome: "", arg: rot + unicas.join("|"), ops: unicas, rot: rot, ini: ini, fim: fim, linha: l }, cand);
    }

    // [ ... ] simples
    function colchete(c, l, ini, fim, cand) {
      var s = desescapar(c.trim());                        // \[ \] \\ \* dentro de [ ] escrevem o próprio símbolo
      if (!s) { aviso(l, "há um [ ] vazio: escreva uma dica dentro dos colchetes, ex.: [pressão]"); marcas++; return "{campo:}"; }
      if (/[{}]/.test(s)) { erro(l, "não use { } dentro de [ ]: “" + s + "”"); return "[" + c + "]"; }
      marcas++;
      if (s.charAt(0) === "@") return arroba(s, c, l);
      if (/^hoje$/i.test(s)) return "{hoje}";
      if (/^\?\s/.test(s)) return controle(s, c, l, ini, fim, cand);
      if (RE_BARRA.test(s)) {                               // a barra com espaços vale ANTES de "..." (ex.: [...A / B])
        var ops = s.split(/\s+\/\s+/);
        if (ops.length < 2) { erro(l, "escolha com só uma opção: [" + s + "]. Use [A / B]"); return "[" + c + "]"; }
        var unicas = validarOpcoes(s, ops, l);
        if (!unicas) return "[" + c + "]";
        return novaEscolha({ tipo: "opcao", nome: "", arg: unicas.join("|"), ops: unicas, ini: ini, fim: fim, linha: l }, cand);
      }
      if (s.slice(0, 3) === "..." || s.charAt(0) === "…") return "{texto:" + s.replace(/^(\.\.\.|…)\s*/, "") + "}";
      return "{campo:" + s + "}";
    }

    // texto de ((AVISO: ...)) e ((DICA: ...)): só texto comum
    function textoPlano(corpoT, l, nome) {
      var x = corpoT.trim();
      if (/[{}]/.test(x)) { erro(l, "não use { } dentro de ((" + nome + ": …))"); x = x.replace(/[{}]/g, " "); }
      if (/\(\(/.test(x)) erro(l, "não use outro (( dentro de ((" + nome + ": …)). Para escrever parênteses duplos use \\(\\(");
      if (!x) aviso(l, "((" + nome + ": …)) está vazio: escreva o texto do " + (nome === "AVISO" ? "aviso" : "lembrete"));
      return desescapar(x).replace(/[\[\]]/g, function (ch) { return priv(ch); }).replace(/\s*\n\s*/g, " ");
    }

    // ((SE ...)) / ((SE SEM RESPOSTA ...)): acha a escolha mais próxima ANTES que tenha a opção
    function resolver(r, l) {
      var u, k, q;
      if (r.tipo === "sr") {
        u = cands[cands.length - 1];
        if (!u) { erro(l, "«SE SEM RESPOSTA» não achou antes nenhuma escolha. Coloque este trecho depois de uma escolha, como [A / B]"); return null; }
        u.usada = true; return { esc: u, valor: "" };
      }
      var alvo = desescapar(r.opcao).trim().toLowerCase();
      if (!alvo) { erro(l, "«SE» sem opção. Escreva assim: ((SE OPÇÃO: texto))"); return null; }
      for (k = cands.length - 1; k >= 0; k--) {
        for (q = 0; q < cands[k].ops.length; q++) {
          if (cands[k].ops[q].trim().toLowerCase() === alvo) {
            var o = cands[k].ops[q].trim();
            if (/[:\]]/.test(o)) { erro(l, "a opção «" + o + "» tem «:» ou «]», e o programa não consegue ligar um texto a ela. Tire esse sinal do texto da opção"); return null; }
            cands[k].usada = true; return { esc: cands[k], valor: o };
          }
        }
      }
      var cru = desescapar(t.slice(r.ini + 2, r.corpoFim)).replace(/^\s*SE\s+/i, "").toLowerCase();
      for (k = cands.length - 1; k >= 0; k--) for (q = 0; q < cands[k].ops.length; q++) {
        var oo = cands[k].ops[q].trim();
        if (oo.indexOf(":") !== -1 && cru.indexOf(oo.toLowerCase()) === 0) { erro(l, "a opção «" + oo + "» tem dois-pontos (:), e o programa não consegue ligar um texto a ela. Tire o «:» do texto da opção"); return null; }
      }
      erro(l, "«SE " + r.opcao + "» não achou antes nenhuma escolha com a opção " + r.opcao + ". A escolha precisa vir antes, com a opção escrita igual (maiúsculas não importam)");
      return null;
    }

    // Percorre um trecho e devolve a lista de partes (textos e objetos). nivel: 0 = modelo; 1 = dentro de ((SE ...)).
    function corpo(s, base, linha, nivel) {
      var n = s.length, i = 0, partes = [], buf = "", aberto = null;
      var lit = function (x) { buf += x; };
      var put = function (p) { if (buf) { partes.push(buf); buf = ""; } partes.push(p); };
      while (i < n) {
        var c = s.charAt(i), nx = s.charAt(i + 1);
        if (c === "\n") { linha++; lit(c); i++; continue; }
        if (c === "\\" && i + 1 < n && ESCAPAVEIS.indexOf(nx) !== -1) { lit(priv(nx)); i += 2; continue; }

        if (c === "[" && nx === "[") {                       // [[nome=VALOR: ... ]]  (sintaxe nativa)
          if (nivel > 0) { erro(linha, "não use [[ ]] dentro de um ((SE …))"); lit("[["); i += 2; continue; }
          var h = RE_CAB.exec(s.substr(i, 300));
          if (!h) { erro(linha, "“[[” fora do formato [[nome=VALOR: texto]]. Para um espaço para preencher use um colchete só, ex.: [dica]"); lit("[["); i += 2; continue; }
          if (aberto) erro(linha, "um bloco [[ ]] foi aberto dentro de outro (o da linha " + aberto.linha + " não foi fechado com ]])");
          aberto = { linha: linha, chave: h[1], valor: h[2].trim() };
          blocos.push(aberto); ids[h[1]] = true;
          lit(h[0]); i += h[0].length; continue;
        }
        if (c === "]" && nx === "]" && aberto) { lit("]]"); aberto = null; i += 2; continue; }

        if (c === "(" && nx === "(") {                       // ((instrução))
          var r = P.lerInstrucao(s, i), tx = s.slice(i, r.fim || i + 2), nl = contarLinhas(tx);
          if (r.tipo === "desconhecida") { erro(linha, "«((» não começa uma instrução conhecida. As instruções são ((SE …)), ((SE SEM RESPOSTA: …)), ((AVISO: …)), ((DICA: …)) e ((DIAS DESDE @NOME)). Para escrever parênteses duplos use \\(\\("); lit("(("); i += 2; continue; }
          if (r.tipo === "se-mal") { erro(linha, "((SE …)) precisa de dois-pontos depois da opção, assim: ((SE OPÇÃO: texto))"); lit("(("); i += 2; continue; }
          if (r.tipo === "dias-mal") { erro(linha, "((DIAS DESDE …)) precisa do nome da data com @ e fechar com )), ex.: ((DIAS DESDE @INTERNAÇÃO))"); lit("(("); i += 2; continue; }
          if (r.tipo === "aberta") { erro(linha, "um «((» foi aberto e não foi fechado (faltou «))»)"); lit("(("); i += 2; continue; }
          if (r.tipo === "dias") {
            marcas++;
            var d = { k: "dias", de: P.normalizarNome(r.nome), nome: r.nome, linha: linha };
            if (!d.de) erro(linha, "((DIAS DESDE @…)) precisa do nome da data, ex.: ((DIAS DESDE @INTERNAÇÃO))");
            diasUsos.push(d); put(d);
          } else if (r.tipo === "aviso" || r.tipo === "dica") {
            var nomeI = r.tipo === "aviso" ? "AVISO" : "DICA";
            put({ k: r.tipo, texto: textoPlano(s.slice(r.corpoIni, r.corpoFim), linha, nomeI) });
          } else if (nivel > 0) {
            erro(linha, "não dá para usar ((SE …)) dentro do texto de outro ((SE …)). Use um só nível");
          } else if (aberto) {
            erro(linha, "não use ((SE …)) dentro de um bloco [[ ]]");
          } else {
            var res = resolver(r, linha);
            var filho = corpo(s.slice(r.corpoIni, r.corpoFim), base + r.corpoIni, linha, 1);
            if (!s.slice(r.corpoIni, r.corpoFim).trim()) aviso(linha, "o texto de ((SE " + (r.tipo === "sr" ? "SEM RESPOSTA" : r.opcao) + ": …)) está vazio");
            if (res) {
              var se = { k: "se", esc: res.esc, valor: res.valor, corpo: filho };
              seInfo.push({ ini: base + i, fim: base + r.fim, corpoIni: base + r.corpoIni, corpoFim: base + r.corpoFim, tipo: r.tipo, opcao: r.opcao, dono: res.esc.idx });
              put(se);
            }
          }
          linha += nl; i = r.fim; continue;
        }

        if (c === "{") {                                     // marcador nativo
          var f = s.indexOf("}", i), cand = f === -1 ? "" : s.slice(i, f + 1), m = cand ? RE_TOK.exec(cand) : null;
          if (!m) { erro(linha, "um { foi aberto e não foi fechado, ou não forma um marcador. Para escrever o símbolo use \\{"); lit("{"); i++; continue; }
          if (TIPOS.indexOf(m[1]) === -1) { erro(linha, "{" + m[1] + "…} não é um marcador conhecido"); lit(cand); }
          else {
            marcas++;
            if (m[2]) { ids[m[2]] = true; if (m[1] === "campo" && !datas[m[2]]) datas[m[2]] = { id: m[2], nome: m[2], nativo: true }; }
            if (m[1] === "opcao" || m[1] === "controle") {
              var arg = m[3] || "", rot = "";
              if (m[1] === "controle" && arg.indexOf("?") !== -1) { rot = arg.slice(0, arg.indexOf("?") + 1); arg = arg.slice(arg.indexOf("?") + 1); }
              var ops2 = arg.split("|").map(function (o) { return o.trim().replace(/^\*\s*/, ""); });
              if (ops2.length < 2) erro(linha, "escolha com só uma opção: " + cand);
              else if (ops2.some(function (o) { return !o; })) erro(linha, "escolha com uma opção vazia: " + cand);
              if (m[2]) defs[m[2]] = ops2;
              put(novaEscolha({ tipo: m[1], nome: m[2] || "", arg: m[3] || "", ops: ops2, rot: rot, nativo: true, ini: base + i, fim: base + f + 1, linha: linha }, nivel === 0 && !aberto));
            } else lit(cand);
          }
          linha += contarLinhas(cand); i = f + 1; continue;
        }
        if (c === "}") { erro(linha, "um } sem { correspondente. Para escrever o símbolo use \\}"); lit(c); i++; continue; }

        if (c === "[") {                                     // [ ... ] simples
          var j = i + 1, fim = -1;
          while (j < n) {
            var dd = s.charAt(j);
            if (dd === "\n") break;
            if (dd === "\\" && ESCAPAVEIS.indexOf(s.charAt(j + 1)) !== -1 && s.charAt(j + 1) !== "") { j += 2; continue; }
            if (dd === "]") { fim = j; break; }
            if (dd === "[") break;
            j++;
          }
          if (fim === -1) {
            erro(linha, s.charAt(j) === "[" ? "um [ foi aberto dentro de outro [ ainda aberto" : "um [ foi aberto e não foi fechado (faltou ])");
            lit("["); i++; continue;
          }
          var pc = colchete(s.slice(i + 1, fim), linha, base + i, base + fim + 1, nivel === 0 && !aberto);
          if (typeof pc === "string") lit(pc); else put(pc);
          i = fim + 1; continue;
        }
        if (c === "]") { aviso(linha, "um ] sem [ correspondente (vai aparecer no texto). Para escrever o símbolo use \\]"); lit(nivel > 0 ? priv("]") : c); i++; continue; }

        if (c === "*" && (i === 0 || !PALAVRA.test(s.charAt(i - 1)))) {   // *TEXTO* corrigível
          var e = i + 1;
          while (e < n && s.charAt(e) !== "\n" && !(s.charAt(e) === "*" && s.charAt(e - 1) !== "\\")) e++;
          var cont = s.slice(i + 1, e);
          if (s.charAt(e) === "*" && cont && !/^\s|\s$/.test(cont) && !PALAVRA.test(s.charAt(e + 1))) {
            if (/(^|[^\\])[\[\]{}]/.test(cont)) { aviso(linha, "*…* com colchetes ou chaves dentro não vira trecho corrigível: " + "*" + cont + "*"); lit("*"); i++; continue; }
            marcas++; lit("{editavel:" + desescapar(cont) + "}"); i = e + 1; continue;
          }
        }
        lit(c); i++;
      }
      if (aberto) erro(aberto.linha, "um [[ foi aberto e não foi fechado (faltou ]])");
      if (buf) partes.push(buf);
      return partes;
    }

    var topo = corpo(t, 0, 1, 0);

    // ---- depois de ler tudo: nomes automáticos, espaços de início de linha, cálculos ----
    diasUsos.forEach(function (d) {
      if (d.de && !datas[d.de]) erro(d.linha, "((DIAS DESDE @" + d.nome + ")) não achou nenhum espaço [@" + d.nome + "] no modelo. Crie antes o espaço da data, ex.: [@" + d.nome + ": dd/mm/aaaa]");
    });
    Object.keys(datas).forEach(function (id) {
      if (!datas[id].nativo && defs[id]) erro(0, "o nome @" + datas[id].nome + " já é usado por uma escolha do modelo. Escolha outro nome");
    });

    var seq = {};
    function livre(pref) { var nm; seq[pref] = seq[pref] || 0; do { nm = pref + (++seq[pref]); } while (ids[nm]); ids[nm] = true; return nm; }
    cands.forEach(function (e) { if (e.usada && !e.nome) e.nome = livre("e"); });
    var calculos = [];
    diasUsos.forEach(function (d) { d.id = livre("auto"); if (d.de) calculos.push({ tipo: "dias", de: d.de, para: d.id }); });

    // Um texto de ((SE …)) que vem logo no começo de uma linha não leva o espaço que se escreve depois dos dois-pontos
    var inicioLinha = true;
    topo.forEach(function (p) {
      if (typeof p === "string") { if (p && !/^[ \t]*$/.test(p)) inicioLinha = /\n[ \t]*$/.test(p); else if (/\n/.test(p)) inicioLinha = true; return; }
      if (p.k === "esc") { if (p.tipo === "opcao") inicioLinha = false; return; }
      if (p.k === "se") {
        if (inicioLinha && typeof p.corpo[0] === "string") p.corpo[0] = p.corpo[0].replace(/^[ \t]+/, "");
        return;
      }
      if (p.k === "dica") return;
      inicioLinha = false;
    });

    function emitir(ps) {
      return ps.map(function (p) {
        if (typeof p === "string") return p;
        if (p.k === "esc") return "{" + p.tipo + (p.nome ? "#" + p.nome : "") + (p.arg !== "" ? ":" + p.arg : "") + "}";
        if (p.k === "se") return "[[" + p.esc.nome + "=" + p.valor + ":" + emitir(p.corpo) + "]]";
        if (p.k === "aviso") return "{aviso:" + p.texto + "}";
        if (p.k === "dica") return "{dica:" + p.texto + "}";
        if (p.k === "dias") return "{campo#" + p.id + ":dias}";
        return "";
      }).join("");
    }
    var out = emitir(topo);

    blocos.forEach(function (b) {
      if (!defs[b.chave]) aviso(b.linha, "o trecho [[" + b.chave + "=…]] depende de {opcao#" + b.chave + ":…}, que não existe: ele nunca vai aparecer");
      else if (b.valor && defs[b.chave].indexOf(b.valor) === -1) aviso(b.linha, "o trecho [[" + b.chave + "=" + b.valor + "…]] espera uma opção chamada “" + b.valor + "”, que não existe: ele nunca vai aparecer");
    });
    if (!marcas && t.trim()) { aviso(1, "o modelo não tem nenhum espaço para preencher nem escolha: vai sair sempre igual"); avisos[avisos.length - 1].semMarca = true; }
    return {
      saida: out, erros: erros, avisos: avisos, calculos: calculos,
      estrutura: {
        escolhas: escInfo.map(function (e) { return { ini: e.ini, fim: e.fim, ctrl: e.tipo === "controle", ops: e.ops, rot: e.rot || "", nativo: !!e.nativo }; }),
        ses: seInfo,
        datas: Object.keys(datas).map(function (id) { return datas[id]; })
      }
    };
  };

  // Validação do modelo inteiro (nome + texto). Devolve { erros, avisos, nome, saida }.
  // pronto (opcional): P.compilar(texto) já feito (o criador guarda um); ele não é alterado.
  P.validar = function (nome, texto, pronto) {
    var r = pronto || P.compilar(texto), erros = r.erros.slice(), nm = P.nomeLimpo(nome), t = P.limpar(texto), nomeErro = "";
    if (!nm) nomeErro = "Dê um nome ao modelo.";
    if (!t.trim()) erros.push({ linha: 0, msg: "o modelo está vazio", vazio: true });
    if (t.length > P.MAX_MODELO) erros.push({ linha: 0, msg: "o modelo é grande demais (máximo " + P.MAX_MODELO + " caracteres)" });
    t.split("\n").forEach(function (l, k) {
      if (P.RE_INI.test(l) || P.RE_FIM.test(l)) erros.push({ linha: k + 1, msg: "esta linha parece um separador do arquivo de modelos (===== …). Mude o texto" });
    });
    return { erros: erros, avisos: r.avisos, nome: nm, nomeErro: nomeErro, saida: r.saida };
  };

  P.mensagem = function (x) { return x.linha ? "Linha " + x.linha + ": " + x.msg : x.msg.charAt(0).toUpperCase() + x.msg.slice(1); };
})();
