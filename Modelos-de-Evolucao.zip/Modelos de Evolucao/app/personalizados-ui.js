/*
 * Evoluções personalizadas — menu lateral (painéis "clássicas" e "personalizadas") e ligação com o motor.
 * Os modelos clássicos (pasta modelos/) nunca são alterados: só podem ser copiados para as personalizadas.
 * As pastas de "Minhas evoluções" (cabeçalho, menu da pasta, janela de nome) ficam em personalizados-pastas-ui.js.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var $ = function (id) { return document.getElementById(id); };
  var corpoC, corpoP, statusEl, avisoArmazEl, tempoStatus;

  function botao(texto, classe, titulo, aoClicar) {
    var b = document.createElement("button");
    b.type = "button"; b.className = classe; b.textContent = texto;
    if (titulo) { b.title = titulo; b.setAttribute("aria-label", titulo); }
    b.addEventListener("click", aoClicar);
    return b;
  }


  function criarPainel(id, titulo, aberto) {
    var d = document.createElement("details"), s = document.createElement("summary"), c = document.createElement("div");
    d.className = "painel"; d.id = id; d.open = aberto;
    s.textContent = titulo; c.className = "painel-corpo";
    d.appendChild(s); d.appendChild(c);
    d.addEventListener("toggle", function () {
      P.salvarPref({ c: $("painel-classicos").open, p: $("painel-personalizadas").open });
    });
    return d;
  }

  // Objeto no formato que o motor entende (o texto das regras simples é compilado para a sintaxe nativa)
  // (os cálculos de dias vêm das instruções ((DIAS DESDE @NOME)) do texto)
  P.modeloMotor = function (rec) { var r = P.compilar(rec.texto); return { id: "p:" + rec.id, nome: rec.nome, categoria: rec.categoria || "evolucao", texto: r.saida, calculos: r.calculos, personalizado: true }; };

  P.mostrarStatus = function (msg) {
    statusEl.textContent = msg;
    clearTimeout(tempoStatus);
    tempoStatus = setTimeout(function () { statusEl.textContent = ""; }, 8000);
  };

  // Grava a lista no navegador; se não der, avisa que os modelos só duram até fechar a página
  P.gravar = function () {
    var ok = P.salvarLista(P.lista);
    avisoArmazEl.hidden = P.persistente;
    return ok;
  };

  P.nomesUsados = function (ignorarId) {
    return P.lista.filter(function (r) { return r.id !== ignorarId; }).map(function (r) { return r.nome; })
      .concat(P.classicos.map(function (m) { return m.nome; }));
  };

  // Um modelo com erro nas regras NUNCA vai para o motor (sairiam marcadores crus no texto final)
  // (o menu é refeito várias vezes: o resultado fica guardado por texto, para não compilar todos os modelos a cada vez)
  var memoErro = Object.create(null), nMemoErro = 0;
  P.erroDoModelo = function (rec) {
    var t = String(rec.texto == null ? "" : rec.texto);
    if (!(t in memoErro)) {
      if (nMemoErro >= 300) { memoErro = Object.create(null); nMemoErro = 0; }
      memoErro[t] = P.compilar(t).erros.length > 0; nMemoErro++;
    }
    return memoErro[t];
  };

  // Abre o modelo na tela; se tiver erro, abre o criador já mostrando o que ajustar
  P.abrirModelo = function (rec) {
    if (P.erroDoModelo(rec)) { P.abrirEditor({ rec: rec }); return; }
    P.Motor.trocar(P.modeloMotor(rec));
  };

  // Depois de salvar: atualiza o menu e cuida do modelo que estiver aberto na tela
  P.aposGravar = function (rec, usarAgora) {
    P.renderMenu();
    if (P.erroDoModelo(rec)) return;
    var M = P.Motor, m = P.modeloMotor(rec), at = M.ativo();
    if (at && at.id === m.id) {
      if (!M.alterado()) M.selecionar(m);
      else M.perguntar("Este modelo está aberto com dados preenchidos. Para ver as mudanças é preciso recomeçar, o que apaga o que foi preenchido. Recomeçar agora?",
        "Recomeçar agora", "Manter como está").then(function (sim) {
        if (sim) M.selecionar(m);
        else { at.texto = m.texto; at.nome = m.nome; at.desatualizado = true; }   // "Nova paciente" ou novo clique no item já usam a versão nova
      });
    } else if (usarAgora) M.trocar(m);
  };

  // Ordem manual: guarda a posição de cada modelo no campo "ordem" (registros antigos, sem o campo, ficam no fim, na ordem de antes)
  P.numerar = function () { P.lista.forEach(function (r, i) { r.ordem = i; }); };

  // Põe o modelo numa pasta ("" = fora das pastas), no fim dela. Usado pela janela "📁 Mover" e pelo arrastar.
  P.moverParaPasta = function (rec, id) {
    P.colocarNaPasta(rec, id);
    if (id) P.lembrarPasta(id, true);               // a pasta de destino abre, para o modelo aparecer
    P.numerar(); P.gravar(); P.renderMenu();
    var b = corpoP.querySelector('.linha-modelo[data-rid="' + rec.id + '"] .item-modelo'); if (b) b.focus({ preventScroll: true });
    var f = P.pastaPorId(id);
    P.mostrarStatus(f ? "“" + rec.nome + "” agora está na pasta “" + f.nome + "”." : "“" + rec.nome + "” agora está fora das pastas.");
  };

  var semAcento = function (t) { return String(t).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); };

  // Itens que contam para Alt+1..9: os clássicos e os modelos que estão À VISTA (fora de pasta fechada e não escondidos pela busca)
  P.itensAtalho = function () {
    return Array.prototype.filter.call(document.querySelectorAll("#lista-modelos .item-modelo"), function (b) {
      return !b.classList.contains("item-oculto") && !b.closest(".linha-modelo[hidden], .pasta-grupo[hidden]") && (!b.closest(".pasta-grupo.fechada") || !!b.closest(".buscando"));
    });
  };
  P.rotularAtalhos = function () {
    var itens = P.itensAtalho();
    Array.prototype.forEach.call(document.querySelectorAll("#lista-modelos .item-modelo"), function (b) {
      var n = itens.indexOf(b);
      b.title = (b.classList.contains("precisa-ajuste") ? "Este modelo precisa de ajuste: clique para corrigir. " : "") + (n !== -1 && n < 9 ? "Atalho: Alt+" + (n + 1) : "");
    });
  };

  // Uma linha da lista: o modelo e as ações dele. A linha pode ser arrastada (personalizados-arrastar.js), menos se estiver oculta
  function linhaModelo(rec) {
    var f = P.pastaDe(rec), F = P.Favoritos, al = F.alvoMeu(rec), oculto = F.ehOculto(al.chave);
    var linha = document.createElement("div"); linha.className = "linha-modelo"; linha.dataset.rid = rec.id; linha.dataset.nome = rec.nome;
    var b = botao(rec.nome, "item-modelo", "", function () { P.abrirModelo(rec); });
    b.dataset.id = al.chave; if (f) b.dataset.pasta = f.nome;      // (o nome da pasta aparece abaixo do modelo só durante a busca)
    F.marcar(b, al.chave, rec.nome);      // ⭐ se é favorito; "(oculto)" e esmaecido se é oculto (aparece só com "Mostrar modelos ocultos")
    if (P.erroDoModelo(rec)) {
      var aj = document.createElement("span"); aj.className = "badge-ajuste"; aj.textContent = "⚠ precisa de ajuste";
      b.classList.add("precisa-ajuste"); b.appendChild(aj);
    }
    b.addEventListener("keydown", function (e) {      // teclado: Alt+↑ / Alt+↓ mudam a ordem (alternativa ao arrastar)
      if (e.altKey && !e.ctrlKey && (e.key === "ArrowUp" || e.key === "ArrowDown")) { e.preventDefault(); P.Acoes.mover(rec, e.key === "ArrowUp" ? -1 : 1); }
    });
    linha.appendChild(b);
    // As ações ficam no menu do BOTÃO DIREITO (ou tecla Menu / Shift+F10), para a lista ficar limpa
    P.MenuContexto.ligar(linha, b, function () {
      var itens = [{ icone: "▶", texto: "Abrir", aoClicar: function () { P.abrirModelo(rec); } }].concat(F.itensMenu(al), [
        { icone: "✏️", texto: "Editar", titulo: "Mudar o modelo “" + rec.nome + "”", aoClicar: function () { P.abrirEditor({ rec: rec }); } },
        { icone: "⧉", texto: "Duplicar", titulo: "Criar uma cópia de “" + rec.nome + "” para você mudar", aoClicar: function () { P.Acoes.duplicar(rec); } }
      ]);
      if (P.pastas.length) itens.push({ icone: "📁", texto: "Mover para pasta…", titulo: "Escolher a pasta (também dá para arrastar)", aoClicar: function () { P.PastasUI.escolherPasta(rec); } });
      itens.push({ icone: "📤", texto: "Enviar a um colega", titulo: "Salvar “" + rec.nome + "” num arquivo para mandar", aoClicar: function () { P.exportar([rec]); } });
      itens.push({ icone: "🗑", texto: "Apagar", perigo: true, aoClicar: function () { P.Acoes.apagar(rec); } });
      return itens;
    });
    if (P.Arrastar && !oculto) P.Arrastar.linha(linha);
    return linha;
  }

  // De onde um painel com pastas tira os dados. Hoje só "Minhas evoluções" tem pastas. Para os clássicos bastaria outra fonte desta forma
  // (a lista de pastas, os modelos de cada uma, a linha de cada modelo, o menu da pasta) e um campo de pasta em cada modelo: o resto
  // (cabeçalho, recolher, contador, menu, organizar) é o mesmo código.
  var fontePessoal = {
    pastas: function () { return P.pastas; },
    modelos: function (id) { return P.Favoritos.meus(id, P.Favoritos.mostrando("p")); },      // favoritos no alto; ocultos só com o link "Mostrar modelos ocultos"
    ocultos: function (id) { return P.Favoritos.mostrando("p") ? 0 : P.Favoritos.meusOcultos(id).length; },
    linha: function (rec) { return linhaModelo(rec); },
    menu: function (f) { return P.PastasUI.itensMenu(f); },
    mover: function (id, d) { P.moverPasta(id, d); P.salvarPastas(); },
    fechada: function (id) { return P.pastaFechada(id); },
    lembrar: function (id, aberta) { P.lembrarPasta(id, aberta); }
  };

  // Uma pasta da lista, com as linhas dos modelos dentro. Alt+↑ / Alt+↓ no nome da pasta mudam a ordem das pastas.
  function desenharGrupo(caixa, fonte, f) {
    var ms = fonte.modelos(f.id);
    var g = P.PastasUI.grupo({
      id: f.id, nome: f.nome, total: ms.length, aberto: !fonte.fechada(f.id), menu: fonte.menu(f),
      aoAlternar: function (aberta) { fonte.lembrar(f.id, aberta); P.rotularAtalhos(); },
      aoMover: function (d) {
        fonte.mover(f.id, d); P.renderMenu();
        var bt = corpoP.querySelector('.pasta-grupo[data-pid="' + f.id + '"] .pasta-toggle'); if (bt) bt.focus({ preventScroll: true });
      }
    });
    var oc = fonte.ocultos(f.id);
    if (!ms.length && !oc) g.corpo.appendChild(P.PastasUI.vazia()); else ms.forEach(function (rec) { g.corpo.appendChild(fonte.linha(rec)); });
    if (oc) g.corpo.appendChild(P.PastasUI.ocultos(oc));      // pasta com ocultos: linha discreta "N oculto(s)" (a pasta continua aparecendo)
    caixa.appendChild(g.el);
  }

  P.renderMenu = function () {
    var M = P.Motor;
    corpoC.textContent = ""; corpoP.textContent = "";

    if (P.Favoritos) P.Favoritos.desenhar(corpoC);      // modelos prontos: favoritos primeiro, ocultos fora (app/favoritos.js)
    else P.classicos.forEach(function (m) { var l = document.createElement("div"); l.className = "linha-modelo"; var b = botao(m.nome, "item-modelo", "", function () { M.trocar(m); }); b.dataset.id = m.id; l.appendChild(b); corpoC.appendChild(l); });

    // Só dois botões: criar e importar (ficam no alto, para não mudarem de lugar quando a lista cresce)
    var acoes = document.createElement("div"); acoes.className = "pers-acoes";
    acoes.appendChild(botao("＋ Criar modelo", "acao-grande forte", "Criar um modelo novo", function () { P.abrirEditor({}); }));
    acoes.appendChild(botao("📥 Abrir arquivo de modelo", "acao-grande", "Abrir modelos recebidos de um colega (arquivo ou texto colado)", function () { P.abrirImportar(); }));
    corpoP.appendChild(acoes);
    var rec = P.avisoRecuperacao && P.avisoRecuperacao();     // cópia de segurança encontrada e lista vazia
    if (rec) corpoP.appendChild(rec);
    var rasc = P.Rascunho && P.Rascunho.caixaMenu();          // modelo que ficou pela metade
    if (rasc) corpoP.appendChild(rasc);

    if (!P.lista.length) {
      var vazio = document.createElement("p"); vazio.className = "pers-vazio";
      vazio.textContent = "Você ainda não criou modelos. Clique em Criar modelo.";
      corpoP.appendChild(vazio);
    }
    var caixaLista = document.createElement("div"); caixaLista.className = "pers-lista";
    var semAchado = document.createElement("p"); semAchado.className = "pers-vazio"; semAchado.textContent = "Nenhum modelo com esse nome."; semAchado.hidden = true;
    var filtrar = function () {              // filtra no lugar (a caixa de busca não é refeita, para não perder o cursor); procura em todas as pastas
      var q = semAcento(P.filtroLista || "").trim(), n = 0;
      caixaLista.classList.toggle("buscando", !!q);
      Array.prototype.forEach.call(caixaLista.querySelectorAll(".linha-modelo"), function (l) { var ok = !q || semAcento(l.dataset.nome).indexOf(q) !== -1; l.hidden = !ok; if (ok) n++; });
      Array.prototype.forEach.call(caixaLista.querySelectorAll(".pasta-grupo"), function (g) { g.hidden = !!q && !g.querySelector(".linha-modelo:not([hidden])"); });
      semAchado.hidden = !(q && !n);
      P.rotularAtalhos();
    };
    if (P.lista.length >= 6) {               // 🔎 só com 6 ou mais modelos
      var busca = document.createElement("div"); busca.className = "pers-busca";
      var cx = document.createElement("input"); cx.type = "text"; cx.className = "pers-busca-cx"; cx.maxLength = 60;
      cx.placeholder = "🔎 Procurar modelo"; cx.setAttribute("aria-label", "Procurar modelo"); cx.value = P.filtroLista || "";
      cx.addEventListener("input", function () { P.filtroLista = cx.value; filtrar(); });
      busca.appendChild(cx); corpoP.appendChild(busca);
    } else P.filtroLista = "";
    corpoP.appendChild(botao("＋ Nova pasta", "nova-pasta", "Criar uma pasta para agrupar seus modelos", function () { P.PastasUI.nova(); }));
    // As pastas primeiro; os modelos que não estão em pasta ficam soltos logo abaixo (não existe pasta "Sem pasta")
    P.pastas.forEach(function (f) { desenharGrupo(caixaLista, fontePessoal, f); });
    var soltos = document.createElement("div"); soltos.className = "pers-soltos"; soltos.dataset.pid = "";
    P.Favoritos.meus("", P.Favoritos.mostrando("p")).forEach(function (rec) { soltos.appendChild(linhaModelo(rec)); });
    if (P.pastas.length) {               // só aparece enquanto se arrasta um modelo de dentro de uma pasta
      var tirar = document.createElement("p"); tirar.className = "pers-tirar"; tirar.textContent = "Solte aqui para tirar o modelo da pasta";
      soltos.appendChild(tirar);
    }
    caixaLista.appendChild(soltos);
    if (P.lista.length || P.pastas.length) {
      corpoP.appendChild(caixaLista); corpoP.appendChild(semAchado); filtrar();
      if (P.Arrastar) P.Arrastar.lista(caixaLista);
      var lkOc = P.Favoritos.linkOcultos("p"); if (lkOc) corpoP.appendChild(lkOc);      // "👁 Mostrar modelos ocultos (N)" no fim da lista
      if (P.lista.length) {
        var dica = document.createElement("p"); dica.className = "pers-dica-arrastar";
        dica.textContent = "Dica: botão direito = opções (favoritar, ocultar, editar, apagar...). Arraste para organizar.";
        corpoP.appendChild(dica);
      }
    }
    if (P.lista.length >= 2) corpoP.appendChild(botao("📤 Salvar todos em arquivo", "exportar-todos", "Salvar todos os seus modelos (e as pastas) num arquivo", function () { P.exportar(P.lista, { comPastas: true }); }));
    if (P.ajudaCopia) corpoP.appendChild(P.ajudaCopia());
    corpoP.appendChild(avisoArmazEl);
    corpoP.appendChild(statusEl);

    P.rotularAtalhos();
    M.marcarAtivo();
  };

  P.iniciar = function (Motor, classicos) {
    P.Motor = Motor; P.classicos = classicos;
    P.lista = P.carregar();
    P.pastas = P.carregarPastas();
    var nav = $("lista-modelos"), pref = P.lerPref();
    var pc = criarPainel("painel-classicos", "📋 Evoluções clássicas", pref.c !== false);
    var pp = criarPainel("painel-personalizadas", "✏️ Minhas evoluções", pref.p !== false);
    corpoC = pc.lastChild; corpoP = pp.lastChild;
    avisoArmazEl = document.createElement("p"); avisoArmazEl.className = "pers-armaz"; avisoArmazEl.hidden = P.persistente;
    avisoArmazEl.textContent = "⚠ Este computador não deixou guardar. O modelo vale só até fechar. Use 📤 Enviar para não perder.";
    statusEl = document.createElement("p"); statusEl.className = "pers-status"; statusEl.setAttribute("aria-live", "polite");
    nav.appendChild(pc); nav.appendChild(pp);
    P.renderMenu();
  };

  // Outra janela do programa mudou os modelos ou as pastas: atualiza o menu desta
  window.addEventListener("storage", function (e) {
    if (e.key !== null && e.key !== P.CHAVE && e.key !== P.CHAVE_PASTAS) return;
    P.lista = P.carregar();
    P.pastas = P.carregarPastas();
    if (P.renderMenu && corpoP) P.renderMenu();
  });

  // Fechar a página com o criador aberto e alterações não salvas
  window.addEventListener("beforeunload", function (e) {
    if (P.editorSujo && P.editorSujo()) { e.preventDefault(); e.returnValue = ""; }
  });
})();
