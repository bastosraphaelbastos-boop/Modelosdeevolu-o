/*
 * Modo "Blocos" do criador — seções (um título e os blocos até o próximo título, que podem ser escondidos) e erros no próprio cartão
 * (parte de personalizados-blocos.js; carregue antes dele). O estado do modo Blocos é lido de B.est() na hora de usar (nunca guardado);
 * desativar/ativar vêm de B._f, registrado por personalizados-blocos.js. Registra em P.BlocosSecoes e acrescenta B.marcarErros e B.irParaLinha.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var B = P.Blocos = P.Blocos || {};
  var I = function () { return P._ed; };            // peças do criador (personalizados-editor.js)
  var tipo = function (u) { return P.BlocosBase.tipo(u); };
  function el(tag, classe, texto) { return I().el(tag, classe, texto); }
  function ed() { return I().estado(); }
  var desativar = function () { B._f.desativar(); }, ativar = function (i, c) { B._f.ativar(i, c); };

  // ---------- seções (um título e os blocos até o próximo título) ----------
  function ehTitulo(i) { var st = B.est(); return i >= 0 && i < st.unidades.length && tipo(st.unidades[i]) === "titulo"; }
  function fimSecao(i) {                             // 1º bloco depois da seção que começa no título i
    var st = B.est();
    var j = i + 1;
    while (j < st.unidades.length && !ehTitulo(j)) j++;
    return j;
  }
  // título que esconde o bloco j (ou -1 se j está à vista)
  function donoRecolhido(j) {
    var st = B.est();
    if (ehTitulo(j)) return -1;                      // o próprio título nunca fica escondido
    for (var o = j - 1; o >= 0; o--) if (ehTitulo(o)) return st.fecha[o] ? o : -1;
    return -1;
  }
  // Quais blocos uma ação num bloco i atinge: a seção inteira (título e blocos) ou só o bloco (sem título, ou com Shift)
  function trecho(i, soBloco) { return !soBloco && ehTitulo(i) ? [i, fimSecao(i)] : [i, i + 1]; }

  // Mostra o bloco i se ele estava dentro de uma seção escondida. Devolve true se abriu a seção.
  function garantirVisivel(i) {
    var st = B.est();
    var o = donoRecolhido(i);
    if (o < 0) return false;
    st.fecha[o] = false; reaplicarOculto();
    return true;
  }

  function ajustarTitulo(c, i) {                     // botão ▾/▸ e o aviso "N blocos escondidos" do cartão de título
    var st = B.est();
    var tg = c.querySelector(".bl-recolher"), n = fimSecao(i) - i - 1, f = !!st.fecha[i] && n > 0, rs = c.querySelector(".bl-resumo");
    tg.textContent = f ? "▸" : "▾"; tg.disabled = n === 0; tg.setAttribute("aria-expanded", f ? "false" : "true");
    tg.title = n === 0 ? "Esta seção não tem outros blocos" : f ? "Mostrar os blocos desta seção" : "Esconder os blocos desta seção (só nesta sessão)";
    tg.setAttribute("aria-label", tg.title);
    if (f) {
      if (!rs) {
        rs = el("button", "bl-resumo"); rs.type = "button"; rs.title = "Mostrar os blocos desta seção";
        rs.addEventListener("click", function () { alternar(+c.dataset.i); });
        c.appendChild(rs);
      }
      rs.textContent = "▸ " + n + (n === 1 ? " bloco escondido" : " blocos escondidos");
    } else if (rs) rs.remove();
  }
  function reaplicarOculto() {                       // esconde/mostra os cartões sem refazer a lista (a rolagem não muda)
    var st = B.est();
    var cards = st.lista.children, escondendo = false;
    for (var i = 0; i < cards.length; i++) {
      var c = cards[i];
      if (ehTitulo(i)) { escondendo = !!st.fecha[i]; c.classList.remove("bl-oculto"); ajustarTitulo(c, i); }
      else c.classList.toggle("bl-oculto", escondendo);
    }
    aplicarErros();
  }
  function alternar(i) {
    var st = B.est();
    if (st.ativo > i && st.ativo < fimSecao(i)) desativar();
    st.fecha[i] = !st.fecha[i];
    reaplicarOculto();
  }

  // ---------- erros no próprio bloco ----------
  // B.marcarErros(lista de { linha, msg }): cada erro grave com número de linha vai para o bloco que contém a linha.
  // Os blocos podem ter várias linhas; erro dentro de uma seção escondida marca o título da seção.
  function curta(lista) {
    var m = lista[0].msg.charAt(0).toUpperCase() + lista[0].msg.slice(1);
    if (m.length > 120) m = m.slice(0, 117).replace(/\s+\S*$/, "") + "…";
    return m + (lista.length > 1 ? "  (+" + (lista.length - 1) + ")" : "");
  }
  function aplicarErros() {
    var st = B.est();
    if (!st || !st.lista) return;
    var cards = st.lista.children, porBloco = {}, prox = 1, k, i;
    var inicios = st.unidades.map(function (u) { var a = prox; prox += 1 + (u.match(/\n/g) || []).length; return a; });
    (st.erros || []).forEach(function (x) {
      for (k = st.unidades.length - 1; k > 0 && inicios[k] > x.linha; k--) { /* procura o bloco da linha */ }
      (porBloco[k] = porBloco[k] || []).push(x);
    });
    var msgs = {};
    Object.keys(porBloco).forEach(function (kk) {
      var n = +kk, dono = donoRecolhido(n);
      if (dono >= 0) { if (!msgs[dono]) msgs[dono] = "Há um problema num bloco escondido desta seção."; }
      else msgs[n] = curta(porBloco[kk]);
    });
    for (i = 0; i < cards.length; i++) {
      var c = cards[i], m = msgs[i], caixa = c.querySelector(".bl-erro-msg");
      c.classList.toggle("bl-erro", !!m);
      if (m) {
        if (!caixa) { caixa = el("div", "bl-erro-msg"); c.appendChild(caixa); }
        if (caixa.textContent !== m) caixa.textContent = m;
      } else if (caixa) caixa.remove();
    }
  }
  B.marcarErros = function (erros) {
    var st = B.est();
    if (!st) return;
    st.erros = erros;
    if (ed().modo === "blocos") aplicarErros();
  };

  // Clicar num problema da lista: abre o bloco que contém a linha
  B.irParaLinha = function (n) {
    var st = B.est();
    if (!st || ed().modo !== "blocos") return;
    var ini = 1;
    for (var k = 0; k < st.unidades.length; k++) {
      var ls = st.unidades[k].split("\n");
      if (n < ini + ls.length || k === st.unidades.length - 1) {
        var off = 0;
        for (var q = 0; q < n - ini && q < ls.length; q++) off += ls[q].length + 1;
        ativar(k, off);
        var c = st.lista.children[k]; if (c) c.scrollIntoView({ block: "nearest" });
        return;
      }
      ini += ls.length;
    }
  };

  P.BlocosSecoes = { ehTitulo: ehTitulo, fimSecao: fimSecao, donoRecolhido: donoRecolhido, trecho: trecho, garantirVisivel: garantirVisivel,
    ajustarTitulo: ajustarTitulo, reaplicarOculto: reaplicarOculto, alternar: alternar, aplicarErros: aplicarErros };
})();
