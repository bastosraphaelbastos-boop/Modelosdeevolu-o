/*
 * Aba "Alta" — parte lógica (a tela está em alta-painel.js). Não sabe de campos nem de HTML.
 * A alta é um segundo texto AO LADO da evolução (a evolução nunca muda). Só os modelos prontos de evolução que têm o campo `altas`
 * (ids sugeridos do catálogo modelos/alta/*.js) têm alta; ela só se monta quando a evolução tem "Alta hoje?" = SIM.
 * Seis blocos, nesta ordem (CHAVES):
 *   - do CATÁLOGO, pelo tipo de alta escolhido pelo médico: tratamento, recomendacoes, cid (o CID é só uma sugestão, editável);
 *   - da EVOLUÇÃO (lidos do texto final atual, #saida: edições à mão na evolução também vão para a alta): resumo, conduta, labs.
 * Editar um bloco à mão o "trava" (deixa de se atualizar sozinho) até o médico voltar ao automático. Trocar o tipo de alta refaz só os blocos
 * do catálogo (pergunta antes se algum foi editado). Trocar de modelo, "Nova paciente" e voltar às especialidades zeram tudo.
 * Nada vai ao localStorage; o app não calcula nada nem recomenda conduta: só monta o texto que o médico escolhe.
 * window.Alta = { CHAVES, TITULOS, situacao, sugeridas, grupos, porId, escolhida, escolher, auto, valor, dica, editado, editar, voltar,
 *                 textoTudo, geracao, aoMudar }
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var CHAVES = ["tratamento", "conduta", "labs", "resumo", "recomendacoes", "cid"];
  var TITULOS = { tratamento: "TRATAMENTO", conduta: "CONDUTA", labs: "LABORATÓRIOS", resumo: "RESUMO DE ALTA", recomendacoes: "RECOMENDAÇÕES PÓS-ALTA", cid: "CID" };
  var DO_CATALOGO = ["tratamento", "recomendacoes", "cid"];
  var escolha = "", edicoes = {}, ouvintes = [], geracao = 0;      // edicoes[chave] = texto escrito à mão (existir = bloco editado)
  var A = window.Alta = { CHAVES: CHAVES, TITULOS: TITULOS };
  var motor = function () { return window.Motor; };

  // ---------- catálogo e sugestões ----------
  A.catalogo = function () { return motor().modelosDe("alta"); };
  A.porId = function (id) { return A.catalogo().filter(function (a) { return a.id === id; })[0] || null; };
  A.escolhida = function () { return escolha; };
  A.geracao = function () { return geracao; };

  // O que a pessoa pode fazer agora: nada | teste | proprio | semalta | naosim | ok
  A.situacao = function () {
    var m = motor().ativo();
    if (!m) return "semalta";
    if (motor().emTeste()) return "teste";
    if (m.personalizado) return "proprio";
    if (!m.altas) return "semalta";
    return motor().valorDe("alta") === "SIM" ? "ok" : "naosim";
  };

  // Altas sugeridas para o modelo aberto (ids no campo `altas`: lista simples, ou { porOpcao: "via", "PARTO NORMAL": [...], ... });
  // com `porOpcao` sem resposta (ou valor sem lista), vale a união de todas as listas
  A.sugeridas = function () {
    var m = motor().ativo(), a = m && m.altas, ids = [];
    if (!a) return [];
    if (Array.isArray(a)) ids = a;
    else {
      var v = a.porOpcao ? motor().valorDe(a.porOpcao) : "";
      if (v && Array.isArray(a[v])) ids = a[v];
      else Object.keys(a).forEach(function (k) { if (k !== "porOpcao" && Array.isArray(a[k])) ids = ids.concat(a[k]); });
    }
    return ids.map(A.porId).filter(Boolean);
  };

  // Lista completa agrupada pelo campo `grupo`, na ordem em que os grupos aparecem no catálogo: [{ nome, itens }]
  A.grupos = function () {
    var ordem = [], por = {};
    A.catalogo().forEach(function (a) {
      var g = a.grupo || "Outras";
      if (!por[g]) { por[g] = []; ordem.push(g); }
      por[g].push(a);
    });
    return ordem.map(function (g) { return { nome: g, itens: por[g] }; });
  };

  // ---------- leitura da evolução (texto final atual) ----------
  // Os trechos são cortados pelos TÍTULOS DO MODELO (as linhas "#..." do texto do modelo aberto), nunca por qualquer linha que comece com "#" ou seja só ".":
  // o que o médico digita nos campos livres ("#1 HB 10", ".") não corta nada. Um título do modelo vira uma expressão regular com a parte fixa dele
  // ("#EXAME FÍSICO:", "#EVOLUÇÃO ("; "#{hoje}: PACIENTE EVOLUI EM" aceita qualquer data no lugar do {hoje}).
  var cacheTexto = null, cacheRes = null, cacheModelo = null, cacheTitulos = null, cacheChave = null;
  function aparar(linhas) { return linhas.join("\n").replace(/^\s+|\s+$/g, ""); }
  var RE_RESUMO = /^\s*#\s*RESUMO DA INTERNAÇÃO\s*:?[ \t]*(.*)$/i, RE_CONDUTA = /^\s*#\s*CONDUTA/i;
  var RE_ORIENT = /^\s*-?\s*ORIENTAÇ(?:Õ|O)ES\s*\(\s*VIDE DOCUMENTO DE ALTA\s*\)\s*\.?\s*$/i;
  var RE_LAB = /^\s*-\s*LABORATÓRIO\s*\(/i, RE_LAB_VAZIO = /^\s*-\s*LABORATÓRIO\s*\(\s*(?:___)?\s*\)\s*:?\s*(?:___)?\s*$/i;
  var ESC = /[.*+?^${}()|[\]\\/]/g;
  function reTitulo(linha) {         // linha "#..." do modelo -> RegExp do título no texto final (ou null se não tiver parte fixa)
    var t = linha.replace(/^\s*#\s*/, ""), fixo = "", src = "", i = 0;
    while (i < t.length) {
      if (t.substr(i, 6) === "{hoje}") { src += "[^\\n]{0,15}"; i += 6; fixo += "\u0001"; }
      else if (t.charAt(i) === "{" || t.substr(i, 2) === "[[") break;
      else { src += t.charAt(i).replace(ESC, "\\$&").replace(/\s/g, "\\s"); fixo += t.charAt(i); i++; }
    }
    src = src.replace(/(?:\\s)+$/, ""); fixo = fixo.replace(/\s+$/, "");
    if (fixo.replace(/\u0001/g, "").length < 4) {                 // quase nada fixo: só vale o "#" + data de hoje (formato do {hoje})
      if (fixo.indexOf("\u0001") === -1) return null;
      src = "\\d{1,2}\\/\\d{1,2}\\/\\d{4}";
    }
    return new RegExp("^\\s*#\\s*" + src, "i");
  }
  // Os títulos do modelo que vêm DEPOIS da linha que casa com `ancora`
  function titulosDepois(modelo, ancora) {
    var linhas = modelo.split("\n"), i = 0, lista = [];
    while (i < linhas.length && !ancora.test(linhas[i])) i++;
    for (i++; i < linhas.length; i++) if (/^\s*#/.test(linhas[i])) { var r = reTitulo(linhas[i]); if (r) lista.push(r); }
    return lista;
  }
  function titulos(ancora) {
    var m = motor().ativo(), t = (m && m.texto) || "";
    if (!cacheTitulos || m !== cacheModelo || t !== cacheTitulos.t) { cacheModelo = m; cacheTitulos = { t: t, resumo: titulosDepois(t, RE_RESUMO), conduta: titulosDepois(t, RE_CONDUTA) }; }
    return ancora === RE_RESUMO ? cacheTitulos.resumo : cacheTitulos.conduta;
  }
  function acharLinha(linhas, re, de) { for (var i = de; i < linhas.length; i++) if (re.test(linhas[i])) return i; return -1; }
  function fimDoTrecho(linhas, de, lista) {      // primeira linha (a partir de `de`) que é um título do modelo; senão, o fim do texto
    for (var j = de; j < linhas.length; j++) if (lista.some(function (r) { return r.test(linhas[j]); })) return j;
    return linhas.length;
  }
  function extrair(texto) {
    var linhas = texto.split("\n"), r = { resumo: "", conduta: "", labs: "" }, labs = [], i = acharLinha(linhas, RE_RESUMO, 0), fim = 0, m, j;
    if (i !== -1) {          // a linha do título (sem o rótulo) e as seguintes, até o próximo título do modelo
      m = RE_RESUMO.exec(linhas[i]);
      fim = fimDoTrecho(linhas, i + 1, titulos(RE_RESUMO));
      r.resumo = aparar([m[1]].concat(linhas.slice(i + 1, fim)));
    }
    var c = acharLinha(linhas, RE_CONDUTA, fim);                  // (procura depois do resumo: o que o médico digitou no resumo não conta)
    if (c !== -1) r.conduta = aparar(linhas.slice(c + 1, fimDoTrecho(linhas, c + 1, titulos(RE_CONDUTA))).filter(function (l) { return !RE_ORIENT.test(l); }));
    for (j = fim; j < (c === -1 ? linhas.length : c); j++) if (RE_LAB.test(linhas[j]) && !RE_LAB_VAZIO.test(linhas[j])) labs.push(linhas[j].trim());   // laboratórios: entre o resumo e a conduta
    r.labs = labs.join("\n");
    return r;
  }
  function daEvolucao() {
    var t = $("saida").value, m = motor().ativo();
    if (t !== cacheTexto || m !== cacheChave) { cacheTexto = t; cacheChave = m; cacheRes = extrair(t); }
    return cacheRes;
  }

  // ---------- blocos ----------
  A.auto = function (chave) {
    var a = A.porId(escolha);
    if (chave === "tratamento" || chave === "recomendacoes") return a ? a[chave] || "" : "";
    if (chave === "cid") return a ? [].concat(a.cid || []).join("\n") : "";
    return daEvolucao()[chave] || "";
  };
  A.editado = function (chave) { return chave in edicoes; };
  A.valor = function (chave) { return A.editado(chave) ? edicoes[chave] : A.auto(chave); };
  A.editar = function (chave, texto) { edicoes[chave] = texto; };
  A.voltar = function (chave) { delete edicoes[chave]; };
  // Dica (texto cinza) do bloco vazio
  A.dica = function (chave) {
    if (DO_CATALOGO.indexOf(chave) !== -1) return escolha ? "Escreva aqui" : "Escolha o tipo de alta acima";
    return chave === "labs" ? "Nenhum laboratório na evolução" : "Nada encontrado na evolução. Escreva aqui";
  };
  // Tudo, com os títulos: "#TRATAMENTO\n...\n\n#CONDUTA\n..."
  // (bloco vazio, título sem corpo, não entra)
  A.textoTudo = function () {
    return CHAVES.filter(function (c) { return A.valor(c).trim() !== ""; }).map(function (c) { return "#" + TITULOS[c] + "\n" + A.valor(c); }).join("\n\n");
  };

  // Escolher/trocar o tipo de alta. Devolve Promise(true/false). Refaz só tratamento, recomendações e CID (pergunta antes se algum foi editado à mão)
  A.escolher = function (id) {
    if (id === escolha) return Promise.resolve(true);
    var editados = DO_CATALOGO.filter(A.editado);
    var aplicar = function () { escolha = id; DO_CATALOGO.forEach(A.voltar); avisar(); return true; };
    if (!editados.length) return Promise.resolve(aplicar());
    return motor().perguntar("Você alterou " + editados.map(function (c) { return TITULOS[c]; }).join(", ") + ". Trocar o tipo de alta apaga essas alterações. Continuar?",
      "Sim, trocar o tipo de alta", "Não, manter").then(function (sim) { return sim ? aplicar() : false; });
  };

  A.reiniciar = function () { escolha = ""; edicoes = {}; geracao++; cacheTexto = null; cacheChave = null; avisar(); };
  A.aoMudar = function (f) { ouvintes.push(f); };
  function avisar() { ouvintes.forEach(function (f) { f(); }); }

  // ---------- quando algo muda no app ----------
  // (no teste do criador a alta fica parada: nada é zerado nem atualizado até voltar à evolução de verdade)
  var parado = function () { return !motor() || motor().emTeste(); };
  document.addEventListener("modeloselecionado", function () { if (!parado()) A.reiniciar(); });     // outro modelo ou "Nova paciente"
  document.addEventListener("voltouespecialidades", function () { if (!parado()) A.reiniciar(); });
  document.addEventListener("saidamudou", function () { if (!parado()) avisar(); });                  // a evolução mudou pelos campos
  $("saida").addEventListener("input", function () { if (!parado()) avisar(); });                      // ...ou foi editada à mão
})();
