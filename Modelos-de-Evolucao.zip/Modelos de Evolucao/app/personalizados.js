/*
 * Evoluções personalizadas — parte "lógica" (não mexe na tela).
 *  - compilar():   regras simples  ->  sintaxe nativa do motor   (ex.: [pressão] -> {campo:pressão})   [em personalizados-compilar.js]
 * Este arquivo tem as constantes, a limpeza do texto e a leitura das ((instruções)). O compilador (P.compilar, P.validar, P.mensagem) e o resto da
 * parte lógica estão em arquivos irmãos, carregados logo depois:
 *   personalizados-compilar.js     regras simples -> sintaxe nativa (P.compilar) e a validação do modelo
 *   personalizados-descompilar.js  sintaxe nativa -> regras simples (usado ao copiar um modelo clássico)
 *   personalizados-armazem.js      nomes, formato do arquivo .txt de envio/abertura e guarda dos modelos no navegador
 *                                  (localStorage, só os MODELOS — nunca o que é preenchido)
 * A tela fica em personalizados-ui.js, personalizados-editor.js (e os que dependem dele) e personalizados-arquivo.js.
 *
 * REGRAS SIMPLES
 *   # TÍTULO        linha começando com # vira título
 *   [dica]          espaço para preencher            [dica=VALOR] já vem preenchido
 *   [hoje]          data de hoje
 *   [A / B / C]     escolha entre opções (barra COM espaços; sem espaços, ex. [8/9], é espaço para preencher)
 *   [...dica]       caixa de texto livre (opcional)
 *   *TEXTO*         texto já escrito que pode ser corrigido (mesma linha; * solitário fica como está)
 *   \[ \] \* \{ \} \( \) \\   escrevem o próprio símbolo
 *   ((SE OPÇÃO: texto))          texto que só aparece se a OPÇÃO da escolha mais próxima ANTES for marcada  -> [[eN=OPÇÃO: texto]]
 *   ((SE SEM RESPOSTA: texto))   texto que aparece enquanto nada foi escolhido                              -> [[eN=: texto]]
 *   [? Pergunta? A / B]          pergunta só na tela (a resposta não vai para o texto)                       -> {controle:Pergunta?A|B}
 *   ((AVISO: texto)) ((DICA: texto))   aviso (sai ___ no texto) e lembrete, só na tela                       -> {aviso:..} {dica:..}
 *   [@NOME: dica]                espaço com nome (mesmo @NOME = campos ligados)                              -> {campo#nome:dica}
 *   ((DIAS DESDE @NOME))         dias desde a data de [@NOME], contado sozinho (dia da data = 0)             -> {campo#autoN:dias} + calculos
 *   {campo:..} {opcao#nome:..} [[nome=VALOR: ..]] etc. (sintaxe nativa, veja LEIA-ME.txt) continuam valendo.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};

  P.CHAVE = "modelosEvolucao.personalizados.v1";
  P.CHAVE_PREF = "modelosEvolucao.paineis.v1";
  P.CHAVE_PASTAS = "modelosEvolucao.pastas.v1";   // [{id, nome, ordem}]: pastas de "Minhas evoluções" (o modelo guarda o id no campo opcional "pasta")
  P.MAX_PASTAS = 30;
  P.MAX_NOME_PASTA = 40;
  P.MAX_ARQUIVO = 5 * 1024 * 1024; // caracteres/bytes aceitos num arquivo de importação (cabe um "Salvar todos" grande)
  P.MAX_MODELO = 60000;         // caracteres num modelo
  P.MAX_NOME = 80;

  // Cria um elemento (classe e texto opcionais; o texto entra por textContent). É o único "el" das telas de modelos personalizados.
  P.el = function (tag, classe, texto) {
    var e = document.createElement(tag);
    if (classe) e.className = classe;
    if (texto != null) e.textContent = texto;
    return e;
  };

  var PALAVRA = /[\wÀ-ſ]/;
  var TIPOS = ["campo", "opcao", "controle", "texto", "hoje", "editavel", "auxiliar", "dica", "aviso"];
  var RE_CAB = /^\[\[([\wÀ-ſ]+)=([^:\]]*):/;                              // início de bloco [[nome=VALOR:
  var RE_TOK = /^\{(\w+)(?:#([\wÀ-ſ]+))?(?::([^}]*))?\}$/;               // token {tipo#nome:argumento}
  var RE_BARRA = /(^|\s)\/(\s|$)/;                                          // barra com espaços = separador de opções
  var ESCAPAVEIS = "[]*{}\\()";

  // Padrões que o descompilador (personalizados-descompilar.js) também usa
  P._reg = { TIPOS: TIPOS, RE_CAB: RE_CAB, RE_TOK: RE_TOK, RE_BARRA: RE_BARRA, PALAVRA: PALAVRA, ESCAPAVEIS: ESCAPAVEIS };

  // Caracteres especiais montados por código (evita escrever invisíveis no arquivo)
  var C = function (n) { return String.fromCharCode(n); };
  var RE_LIXO = new RegExp("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F" + C(0x200B) + "-" + C(0x200D) + C(0xE000) + "-" + C(0xE003) + "]", "g");
  var RE_LINHA = new RegExp("\\r\\n?|[" + C(0x2028) + C(0x2029) + "]", "g");

  // Tira BOM, quebras de linha do Windows e caracteres de controle (o \x00 é usado internamente pelo motor)
  P.limpar = function (t) {
    return String(t == null ? "" : t).split(C(0xFEFF)).join("").replace(RE_LINHA, "\n").split(C(0xA0)).join(" ").replace(RE_LIXO, "");
  };

  // Símbolos escritos com \ ( \[ \] \{ \} ) viram caracteres privados (U+E000 a U+E003) até o motor, que os devolve ao normal.
  // Assim um "\{campo:x\}" digitado de propósito nunca é confundido com um marcador.
  var PRIV = { "{": C(0xE000), "}": C(0xE001), "[": C(0xE002), "]": C(0xE003) };
  var priv = function (ch) { return PRIV[ch] || ch; };
  P._reg.priv = priv;
  var RE_PRIV = new RegExp("[" + C(0xE000) + "-" + C(0xE003) + "]", "g");
  P.semPriv = function (t) { return String(t).replace(RE_PRIV, function (c) { return "{}[]".charAt(c.charCodeAt(0) - 0xE000); }); };

  // ---------- instruções ((...)) ----------
  //   ((SE OPÇÃO: texto))  ((SE SEM RESPOSTA: texto))  ((AVISO: texto))  ((DICA: texto))  ((DIAS DESDE @NOME))
  var RE_I_SR = /^\s*SE\s+SEM\s+RESPOSTA\s*:/i;
  var RE_I_SE = /^\s*SE\s+([^:\n]*?)\s*:/i;
  var RE_I_AD = /^\s*(AVISO|DICA)\s*:/i;
  var RE_I_DIAS = /^\s*DIAS\s+DESDE\s+@([^()\n]*?)\s*\)\)/i;
  var RE_ABRE = /^\(\(\s*(?:SE\s|AVISO\s*:|DICA\s*:|DIAS\s+DESDE)/i;

  // Nome de um espaço ligado ([@NOME]) -> id usado pelo motor: sem acento, sem espaço, minúsculo
  P.normalizarNome = function (nome) {
    return String(nome).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9_]/g, "");
  };

  // Acha o "))" que fecha a instrução. Dentro do texto pode haver outras instruções ((AVISO: ...)) e parênteses comuns:
  // numa sequência de ")" os dois ÚLTIMOS são o fecho (assim "(vide receita)))" funciona). \) escreve um ")" comum.
  function acharFecha(t, p) {
    var n = t.length, depth = 1, j = p;
    while (j < n) {
      var c = t.charAt(j);
      if (c === "\\" && j + 1 < n) { j += 2; continue; }
      if (c === "(" && t.charAt(j + 1) === "(" && RE_ABRE.test(t.substr(j, 40))) { depth++; j += 2; continue; }
      if (c === ")") {
        var k = j;
        while (k < n && t.charAt(k) === ")") k++;
        var fechos = Math.min(depth, Math.floor((k - j) / 2));
        if (fechos > 0) { depth -= fechos; if (depth === 0) return { corpoFim: k - 2, fim: k }; }
        j = k; continue;
      }
      j++;
    }
    return null;
  }

  // t[i..i+1] é "((". Devolve { tipo, ini, fim, corpoIni, corpoFim, opcao, nome } ou { tipo:"aberta"|"se-mal"|"dias-mal"|"desconhecida" }
  P.lerInstrucao = function (t, i) {
    var resto = t.substr(i + 2, 400), m, r = { ini: i };
    if ((m = RE_I_DIAS.exec(resto))) { r.tipo = "dias"; r.nome = m[1].trim(); r.fim = i + 2 + m[0].length; return r; }
    if (/^\s*DIAS\b/i.test(resto)) { r.tipo = "dias-mal"; return r; }
    if ((m = RE_I_SR.exec(resto))) { r.tipo = "sr"; r.opcao = null; }
    else if (/^\s*SE\s/i.test(resto) && (m = RE_I_SE.exec(resto)) && m[0].indexOf("))") === -1) { r.tipo = "se"; r.opcao = m[1].trim(); }
    else if ((m = RE_I_AD.exec(resto))) { r.tipo = m[1].toLowerCase() === "aviso" ? "aviso" : "dica"; }
    else { r.tipo = /^\s*SE\b/i.test(resto) ? "se-mal" : "desconhecida"; return r; }
    r.corpoIni = i + 2 + m[0].length;
    var f = acharFecha(t, r.corpoIni);
    if (!f) { r.tipo = "aberta"; return r; }
    r.corpoFim = f.corpoFim; r.fim = f.fim;
    return r;
  };

})();
