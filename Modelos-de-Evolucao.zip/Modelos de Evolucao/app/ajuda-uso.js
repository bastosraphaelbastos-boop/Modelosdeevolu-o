/*
 * Ajuda — abas "Como usar" e "Algo deu errado?" (o texto; a janela está em ajuda.js).
 * Linguagem simples, sem jargão e sem nomes de marcas: "por mensagem", "Abrir arquivo de modelo", "Enviar".
 */
(function () {
  "use strict";
  var A = window.Ajuda;

  A.registrar("uso", function (p) {
    A.titulo(p, "Primeiros passos");
    A.lista(p, [
      "Escolha o modelo no menu à esquerda (ou aperte <<Ctrl>>+<<K>> e digite o nome dele).",
      "Preencha os campos amarelos (clique e escreva) e clique nas opções. O texto final vai sendo montado ao lado.",
      "Os trechos com sublinhado pontilhado já vêm escritos, mas podem ser corrigidos: clique neles e edite.",
      "Clique em **📋 Copiar texto** (ou aperte <<Ctrl>>+<<Enter>>) e cole no prontuário com <<Ctrl>>+<<V>>.",
      "Nada do que você preenche é guardado: ao fechar o app, tudo some. O app só guarda os modelos que você mesmo cria."
    ], true);

    A.titulo(p, "Só com o teclado");
    A.lista(p, [
      "<<Enter>> vai para o próximo item que falta preencher.",
      "<<1>> a <<9>> escolhem a opção quando o cursor está numa pergunta com opções.",
      "<<Ctrl>>+<<Enter>> copia o texto.",
      "<<Alt>>+<<1>> até <<Alt>>+<<9>> abrem os modelos da lista, na ordem em que aparecem no menu.",
      "<<Ctrl>>+<<K>> abre a busca rápida de modelos. <<Esc>> fecha qualquer janela."
    ]);

    A.titulo(p, "Atalhos de digitação");
    A.p(p, "O app arruma sozinho alguns números, pela dica do campo (o que aparece escrito dentro dele):");
    A.lista(p, [
      "Datas e horas: `27092026` vira 27/09/2026 · `2709` vira 27/09 · `1430` vira 14:30.",
      "Pressão (PA): `12080` vira 120/80.",
      "Temperatura: `365` vira 36,5.",
      "Apgar: `89` vira 8/9."
    ]);

    A.titulo(p, "Se você mexer no texto final");
    A.p(p, "Dá para escrever e apagar direto no texto final. Assim que você mexe, os campos ficam **pausados** (cinza), para não apagarem o que você escreveu. Para voltar a usar os campos, clique em **“Desfazer minhas alterações e voltar a usar os campos”** (isso apaga o que você escreveu à mão). Dica: preencha primeiro os campos e só depois faça os ajustes finais no texto.");

    A.titulo(p, "Abas Evolução e Alta");
    A.lista(p, [
      "No alto do texto final há duas abas: **📝 Evolução** (o texto de sempre) e **🏠 Alta**.",
      "A aba Alta só tem texto quando, no modelo, você responde **Alta hoje? = SIM**. Ela existe nos modelos prontos de puérpera, curetagem, gestante em tratamento clínico e laqueadura (evolução), e não nos modelos que você criou.",
      "Escolha o **tipo de alta**; aparecem então os blocos (tratamento, conduta, laboratórios, resumo, recomendações e CID). Você pode escrever em cada bloco; “voltar ao automático” desfaz.",
      "Cada bloco tem **📋 Copiar**, e **📋 Copiar tudo** copia todos juntos (também com <<Ctrl>>+<<Enter>> quando a aba Alta está aberta)."
    ]);

    A.titulo(p, "＋ Adicionar laboratório");
    A.p(p, "Nos modelos de puérpera, curetagem, gestante em tratamento clínico e laqueadura (evolução), o botão **＋ Adicionar laboratório** acrescenta uma linha de data e resultado (até 10). O **✕** tira só aquela linha.");

    A.titulo(p, "Ferramentas extras");
    A.p(p, "No alto da tela, **🧰 Ferramentas extras** (clique para abrir): **TUDO MAIÚSCULO** converte qualquer texto colado, e a **Calculadora de DPP e IG** mostra os resultados pela DUM e pelo 1º ultrassom. A escolha da datação é sempre do médico.");

    A.titulo(p, "Deixar o menu do seu jeito");
    A.p(p, "Clique com o **botão direito** num modelo, pronto ou seu (em “Minhas evoluções”): **⭐ Favoritar** põe o modelo no alto da lista (ou da pasta dele), com uma ⭐ antes do nome; **Ocultar** esconde o modelo do menu, da busca e dos atalhos <<Alt>>+número. Para ver os ocultos de novo, use **“👁 Mostrar modelos ocultos”** no fim de cada lista: eles aparecem esmaecidos, marcados “oculto”, e o botão direito neles oferece **Mostrar (deixar de ocultar)**. Os seus modelos você ainda organiza arrastando e com pastas; favoritar não muda a ordem que você escolheu.");

    A.titulo(p, "Busca rápida");
    A.p(p, "Em qualquer lugar da tela de uso, aperte <<Ctrl>>+<<K>>, digite parte do nome (não precisa de acento nem de maiúsculas), escolha com <<↑>> <<↓>> e aperte <<Enter>>. Se já houver algo preenchido, o app pergunta antes de trocar de modelo.");
  });

  A.registrar("erro", function (p) {
    A.p(p, "Clique na pergunta para ver a resposta.", "ajuda-nota");
    A.pergunta(p, "Meus modelos sumiram", [
      "Calma: o app guarda cópias dos seus modelos na pasta **C:\\ModelosEvolucao\\meus-modelos**. Isso pode acontecer quando o app é aberto de outro jeito ou quando os dados do navegador são apagados.",
      "Em **Minhas evoluções**, procure o aviso **“Recuperar meus modelos”** e clique nele. Se o aviso não aparecer, clique em **📥 Abrir arquivo de modelo**, abra a pasta **meus-modelos** e escolha o arquivo mais recente (o de data e hora mais novas)."
    ]);
    A.pergunta(p, "O botão Copiar não funcionou", [
      "Clique dentro do texto final, aperte <<Ctrl>>+<<A>> (seleciona tudo) e depois <<Ctrl>>+<<C>>. Em seguida cole no prontuário com <<Ctrl>>+<<V>>."
    ]);
    A.pergunta(p, "Os campos ficaram cinza (pausados)", [
      "Isso acontece quando você escreve direto no texto final: o app pausa os campos para não apagar o que você escreveu. Para voltar, clique em **“Desfazer minhas alterações e voltar a usar os campos”** (aparece no alto e embaixo do texto). Atenção: isso apaga o que você escreveu à mão."
    ]);
    A.pergunta(p, "Aparece ___ ou “A / B” no texto", [
      "**___** é um espaço que ficou sem preencher, e **“A / B”** é uma pergunta que ficou sem resposta. O contador amarelo mostra quantos faltam: clique nele para ir ao próximo. Se você copiar com itens faltando, o app pergunta antes."
    ]);
    A.pergunta(p, "Quero usar em outro computador", [
      "Os modelos que você criou ficam só no computador onde foram criados. Para levar: clique com o botão direito no modelo e escolha **Enviar a um colega** (para vários, use **📤 Salvar todos em arquivo**). Leve o arquivo num pendrive ou mande por e-mail ou por mensagem.",
      "No outro computador, com o app instalado, clique em **📥 Abrir arquivo de modelo** e escolha o arquivo."
    ]);
    A.pergunta(p, "Recebi um modelo de um colega", [
      "Clique em **📥 Abrir arquivo de modelo** (em Minhas evoluções) e escolha o arquivo, ou cole o texto recebido por mensagem. Se você já tem um modelo igual e o texto é diferente, o app pergunta: **Atualizar o meu**, **Ficar com os dois** ou **Pular**."
    ]);
    A.pergunta(p, "O app ficou lento ou estranho", [
      "Feche a janela e abra de novo pelo atalho **Modelos de Evolução** na área de trabalho. Como nada do que foi preenchido é guardado, copie antes o que precisar. Seus modelos continuam guardados."
    ]);
    A.pergunta(p, "A alta não aparece", [
      "Confira: (1) o modelo é um dos prontos que têm alta (puérpera, curetagem, gestante em tratamento clínico ou laqueadura, evolução); (2) a pergunta **Alta hoje?** foi respondida com **SIM**; (3) você escolheu o **tipo de alta**. Nos modelos que você criou, a alta automática ainda não existe."
    ]);
  });
})();
