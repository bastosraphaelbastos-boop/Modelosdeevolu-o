/*
 * Evoluções personalizadas — exportar e importar modelos (arquivo .txt legível, para pendrive ou mensagem).
 * O conteúdo do arquivo vem de terceiros: tudo entra na tela por textContent, nunca por innerHTML.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var el = P.el;

  // ---------- Exportar ----------
  function nomeDeArquivo(n) {
    return P.nomeLimpo(n).replace(/[\\/:*?"<>|]/g, " ").replace(/\s+/g, " ").trim().slice(0, 60) || "modelo";
  }

  // Baixa um .txt com o texto dado (o download cai na pasta configurada pelo instalador, ou em Downloads)
  function baixar(nome, conteudo) {
    var blob = new Blob([conteudo], { type: "text/plain;charset=utf-8" });
    var url = URL.createObjectURL(blob), a = document.createElement("a");
    a.href = url; a.download = nome; a.style.display = "none";
    document.body.appendChild(a); a.click();
    setTimeout(function () { a.remove(); URL.revokeObjectURL(url); }, 1500);
  }

  // lista = modelos a exportar; um só vira "modelo - Nome.txt", vários viram "meus modelos de evolucao.txt"
  // op (opcional): { pasta: "Nome" } = "Enviar pasta" ("pasta - Nome.txt"); { comPastas: true } = guarda a pasta de cada modelo ("Salvar todos")
  P.exportar = function (lista, op) {
    if (!lista || !lista.length) return;
    op = op || {};
    var nome = op.pasta ? "pasta - " + nomeDeArquivo(op.pasta) + ".txt" : lista.length === 1 ? "modelo - " + nomeDeArquivo(lista[0].nome) + ".txt" : "meus modelos de evolucao.txt";
    try {
      baixar(nome, P.exportarTexto(lista, op));
      P.mostrarStatus("Arquivo salvo no computador, na pasta meus-modelos (ou em Downloads, se o app não foi instalado). Mande esse arquivo para o colega (pendrive ou mensagem). Ele abre em “Abrir arquivo de modelo”.");
    } catch (e) {
      P.mostrarStatus("Não consegui gerar o arquivo neste navegador.");
    }
  };

  // ---------- Cópia de segurança automática ----------
  // Baixa um .txt com TODOS os modelos pessoais (mesmo formato de "Salvar todos em arquivo").
  // Chamada logo depois de salvar, editar, apagar ou receber modelos, ainda dentro do clique do usuário.
  // Com a lista vazia também baixa (o arquivo registra que ficou vazia). Nunca mostra janela nem lança erro.
  var dois = function (n) { return (n < 10 ? "0" : "") + n; };
  P.copiaSeguranca = function () {
    try {
      var d = new Date();
      var nome = "copia-seguranca-modelos " + d.getFullYear() + "-" + dois(d.getMonth() + 1) + "-" + dois(d.getDate()) +
        " " + dois(d.getHours()) + "h" + dois(d.getMinutes()) + "m" + dois(d.getSeconds()) + ".txt";
      baixar(nome, P.exportarTexto(P.lista, { comPastas: true }));      // a pasta de cada modelo vai junto (versões antigas do app leem o arquivo do mesmo jeito)
      return true;
    } catch (e) { return false; }
  };

  // ---------- Recuperação automática (meus-modelos/recuperar.js, gerado pelo instalador) ----------
  // Só aparece se a lista do navegador estiver vazia e a cópia tiver modelos (nunca ressuscita modelos apagados).
  P.avisoRecuperacao = function () {
    var bruto = window.COPIA_MODELOS;
    if (typeof bruto !== "string" || P.lista.length) return null;
    var modelos;
    try { modelos = P.lerArquivo(bruto).modelos.filter(function (m) { return P.normTexto(m.texto).trim(); }); } catch (e) { return null; }
    if (!modelos.length) return null;
    var nomes = modelos.map(function (m) { return P.nomeLimpo(m.nome) || "Modelo recebido"; });
    var lista = nomes.slice(0, 5).join(", ") + (nomes.length > 5 ? " e mais " + (nomes.length - 5) : "");
    var caixa = el("div", "pers-recuperar");
    caixa.setAttribute("role", "status");
    caixa.appendChild(el("p", "", "Encontramos uma cópia de segurança com " + modelos.length + (modelos.length === 1 ? " modelo: " : " modelos: ") + lista + "."));
    var b = el("button", "acao-grande forte", "Recuperar meus modelos"); b.type = "button";
    b.addEventListener("click", function () {
      var r = P.importarTexto(bruto, undefined, "manter");      // recuperação: volta cada modelo à pasta que tinha
      if (r.novos) P.copiaSeguranca();      // ainda dentro do clique
      var pl = document.getElementById("painel-personalizadas"); if (pl) pl.open = true;
      P.mostrarStatus(r.msg || r.erro || "");
    });
    caixa.appendChild(b);
    return caixa;
  };

  // Explicação curta sobre cópia de segurança e outros computadores (os textos também são usados pela janela de Ajuda: app/ajuda-criar.js)
  P.TEXTOS_COPIA = [
    "O app guarda sozinho uma cópia dos seus modelos a cada mudança, na pasta C:\\ModelosEvolucao\\meus-modelos.",
    "Para levar seus modelos a outro computador: clique com o botão direito no modelo e escolha “Enviar a um colega” (se tiver vários, use “📤 Salvar todos em arquivo”). Depois leve o arquivo num pendrive, mande para você mesmo por e-mail ou por mensagem, ou guarde numa pasta de armazenamento na nuvem (serviço de arquivos on-line). No outro computador, use “📥 Abrir arquivo de modelo”.",
    "Pastas: clique com o botão direito na pasta e escolha “Enviar pasta” para salvar todos os modelos dela num arquivo. Ao abrir um arquivo com pasta, o app pergunta em qual pasta colocar os modelos.",
    "Se os modelos sumirem: “📥 Abrir arquivo de modelo” e escolha o arquivo mais recente em C:\\ModelosEvolucao\\meus-modelos."
  ];
  P.ajudaCopia = function () {
    var d = el("details", "pers-ajuda"), s = el("summary", "", "❓ Cópia de segurança e outros computadores"), c = el("div");
    P.TEXTOS_COPIA.forEach(function (t) { c.appendChild(el("p", "", t)); });
    d.appendChild(s); d.appendChild(c);
    return d;
  };

  // ---------- Janela de importação ----------
  P.abrirImportar = function () {
    if (document.querySelector(".imp-pers")) return;
    var anterior = document.activeElement;
    var fundo = el("div", "modal-pers dlg-pers imp-pers"), caixa = el("div", "dlg-caixa");
    fundo.setAttribute("role", "dialog"); fundo.setAttribute("aria-modal", "true"); fundo.setAttribute("aria-labelledby", "imp-titulo");
    var h = el("h2", "", "Abrir arquivo de modelo"); h.id = "imp-titulo";
    caixa.appendChild(h);
    var corpo = el("div", "imp-corpo"); caixa.appendChild(corpo);
    var msg = el("p", "dlg-erro"); msg.setAttribute("aria-live", "polite");

    var fechado = false;       // depois de fechada, a janela ignora o que o leitor de arquivo ainda devolver
    var copiaPendente = false; // modelos recebidos: a cópia de segurança sai no clique em OK (o arquivo escolhido não conta como clique)
    var depois = null;         // o que fazer depois de fechar (modelo atualizado que está aberto na tela: recomeçar ou perguntar)
    function fazerCopia() { if (copiaPendente) { copiaPendente = false; P.copiaSeguranca(); } }
    function fechar() {
      fazerCopia();
      fechado = true;
      document.removeEventListener("keydown", tecla, true);
      fundo.remove();
      if (!P.editorAberto()) P.travarFundo(false);      // se o criador estiver aberto, o fundo continua travado
      if (anterior && anterior.isConnected && anterior.focus) anterior.focus({ preventScroll: true });
      if (depois) { var d = depois; depois = null; setTimeout(d, 0); }
    }
    function tecla(e) { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); fechar(); } }

    var lido = null;           // o último texto lido { txt, nome }: se o arquivo tem pastas, a janela pergunta onde colocar e lê de novo com a resposta
    function perguntarPasta(leit) {
      corpo.textContent = "";
      var rot = el("label", "dlg-ajuda", "Colocar em qual pasta?"); rot.htmlFor = "imp-pasta";
      var sel = el("select", "dlg-campo"); sel.id = "imp-pasta";
      var opcao = function (valor, texto) { var o = el("option", "", texto); o.value = valor; sel.appendChild(o); };
      var np = leit.pastas || [];
      if (np.length === 1) opcao("manter", "Pasta do arquivo: " + np[0] + (P.pastaPorNome(np[0]) ? "" : " (será criada)"));
      else if (np.length) opcao("manter", "Manter as pastas do arquivo (" + np.join(", ") + ")");
      opcao("", "Fora das pastas");
      P.pastas.forEach(function (f) { opcao(f.id, f.nome); });
      sel.value = np.length ? "manter" : "";
      var ok = el("button", "dlg-ok", "Abrir"); ok.type = "button";
      ok.addEventListener("click", function () { resultado(P.importarTexto(lido.txt, lido.nome, sel.value)); });
      var ac = el("div", "dlg-acoes"); ac.appendChild(ok);
      corpo.appendChild(rot); corpo.appendChild(sel); corpo.appendChild(ac); corpo.appendChild(msg);
      sel.focus();
    }

    function resultado(r) {
      if (fechado) return;
      if (r.erro) { msg.textContent = r.erro; return; }
      if (r.escolher) { perguntarPasta(r.leitura); return; }
      if (r.perguntar) { P.Recebidos.perguntar(corpo, r.conflitos, function (dec) { resultado(r.concluir(dec)); }); return; }      // modelo que já existe e é diferente
      if (r.editor) { fechar(); P.abrirEditor({ nome: "", texto: r.texto }); return; }
      copiaPendente = !!r.novos; depois = r.depois || null;
      fundo.querySelector(".dlg-caixa").classList.add("pronto");
      var pl = document.getElementById("painel-personalizadas"); if (pl) pl.open = true;
      P.mostrarStatus(r.msg);
      corpo.textContent = "";
      var p = el("p", "imp-resumo", r.msg); p.setAttribute("role", "status");
      var ok = el("button", "dlg-ok", "OK"); ok.type = "button"; ok.addEventListener("click", fechar);
      var ac = el("div", "dlg-acoes"); ac.appendChild(ok);
      corpo.appendChild(p); corpo.appendChild(ac); ok.focus();
      if (bCanc.parentNode) bCanc.parentNode.remove();      // no resultado só fica o botão OK
    }

    // opção 1: arquivo
    var arq = el("input"); arq.type = "file"; arq.accept = ".txt,text/plain"; arq.className = "imp-arquivo"; arq.tabIndex = -1;
    arq.setAttribute("aria-hidden", "true");
    arq.addEventListener("change", function () {
      var f = arq.files && arq.files[0]; arq.value = "";
      if (!f) return;
      if (f.size > P.MAX_ARQUIVO) { msg.textContent = "Este arquivo é grande demais (máximo 5 MB). Confira se é mesmo um arquivo de modelos."; return; }
      // Lê como UTF-8; se aparecer o caractere "�" (arquivo em ANSI), tenta de novo como windows-1252
      function ler(codificacao, depois) {
        var leitor = new FileReader();
        leitor.onload = function () { if (!fechado) depois(String(leitor.result)); };
        leitor.onerror = function () { if (!fechado) msg.textContent = "Não consegui ler o arquivo."; };
        leitor.readAsText(f, codificacao);
      }
      var RUIM = String.fromCharCode(0xFFFD), CONTROLES = /[\x00-\x08\x0E-\x1F]/g;
      var conferir = function (t) {
        if (t.indexOf(RUIM) !== -1 || (t.match(CONTROLES) || []).length > 3) { resultado({ erro: P.MSG_NAO_MODELO }); return; }
        lido = { txt: t, nome: f.name };
        resultado(P.importarTexto(t, f.name));
      };
      ler("UTF-8", function (t) { if (t.indexOf(RUIM) !== -1) ler("windows-1252", conferir); else conferir(t); });
    });
    var bArq = el("button", "acao-grande forte", "📂 Escolher arquivo no computador"); bArq.type = "button";
    bArq.addEventListener("click", function () { msg.textContent = ""; arq.click(); });

    // opção 2: colar
    var colar = el("div", "imp-colar"); colar.hidden = true;
    var ta = el("textarea", "imp-texto"); ta.rows = 7; ta.setAttribute("aria-label", "Texto recebido"); ta.placeholder = "Cole aqui o texto que você recebeu";
    var bImp = el("button", "dlg-ok", "Abrir"); bImp.type = "button";
    bImp.addEventListener("click", function () { lido = { txt: ta.value, nome: undefined }; resultado(P.importarTexto(ta.value)); });
    colar.appendChild(ta); colar.appendChild(bImp);
    var bCol = el("button", "acao-grande", "📋 Colar texto recebido por mensagem"); bCol.type = "button";
    bCol.addEventListener("click", function () { msg.textContent = ""; colar.hidden = false; ta.focus(); });

    corpo.appendChild(bArq); corpo.appendChild(bCol); corpo.appendChild(colar); corpo.appendChild(arq); corpo.appendChild(msg);
    var ac2 = el("div", "dlg-acoes");
    var bCanc = el("button", "dlg-cancelar", "Cancelar"); bCanc.type = "button"; bCanc.addEventListener("click", fechar);
    ac2.appendChild(bCanc); caixa.appendChild(ac2);
    fundo.appendChild(caixa);
    fundo.addEventListener("keydown", function (e) {
      if (e.key !== "Tab") return;
      var foc = Array.prototype.filter.call(fundo.querySelectorAll("button, textarea, select, input"), function (x) { return !x.disabled && x.offsetParent !== null && x.tabIndex !== -1; });
      var p = foc.indexOf(document.activeElement);
      if (!foc.length) return;
      if (e.shiftKey && p <= 0) { e.preventDefault(); foc[foc.length - 1].focus(); }
      else if (!e.shiftKey && p === foc.length - 1) { e.preventDefault(); foc[0].focus(); }
    });
    P.travarFundo(true);
    document.body.appendChild(fundo);
    document.addEventListener("keydown", tecla, true);
    bArq.focus();
  };
})();
