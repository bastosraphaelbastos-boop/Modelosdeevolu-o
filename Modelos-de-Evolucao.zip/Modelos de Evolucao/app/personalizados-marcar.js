/*
 * Evoluções personalizadas — o criador: marcar o texto (parte de personalizados-editor.js).
 * Acha as marcações que já existem no texto e tem os botões que escrevem as regras simples nele
 * (espaço, corrigível, título, data de hoje, lembrete, desfazer marcação). Tudo é registrado em P._ed.
 * Carregue depois de personalizados-editor.js.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var PE = P._ed;          // peças compartilhadas do criador (registradas em personalizados-editor.js)
  var PALAVRA = P._reg.PALAVRA, RE_CAB = P._reg.RE_CAB;      // os mesmos padrões do compilador (personalizados.js)
  var dica = PE.dica, substituir = PE.substituir;

  // ---------- localizar marcadores já existentes no texto (para não marcar duas vezes) ----------
  // Devolve [{s, e, k, ins?}] : k = "colchete" [..] | "nativo" {..} | "corrigivel" *..* | "se-ini" / "se-fim" (início e fim de ((SE …)))
  //                                | "aviso" | "dica" | "dias"  (instruções ((...)) inteiras)
  function deslocar(ins, d) {
    var o = {}; Object.keys(ins).forEach(function (k) { o[k] = typeof ins[k] === "number" ? ins[k] + d : ins[k]; });
    return o;
  }
  function marcadores(t) {
    var out = [], n = t.length, i = 0, aberto = false;
    while (i < n) {
      var c = t.charAt(i), nx = t.charAt(i + 1);
      if (c === "\\" && i + 1 < n) { i += 2; continue; }
      if (c === "[" && nx === "[") {
        var h = RE_CAB.exec(t.substr(i, 300));
        if (h) { aberto = true; i += h[0].length; } else i += 2;
        continue;
      }
      if (c === "]" && nx === "]" && aberto) { aberto = false; i += 2; continue; }
      if (c === "(" && nx === "(") {
        var r = P.lerInstrucao(t, i);
        if (r.fim) {
          if (r.tipo === "se" || r.tipo === "sr") {
            out.push({ s: i, e: r.corpoIni, k: "se-ini", ins: r });
            marcadores(t.slice(r.corpoIni, r.corpoFim)).forEach(function (m) { out.push({ s: m.s + r.corpoIni, e: m.e + r.corpoIni, k: m.k, ins: m.ins && deslocar(m.ins, r.corpoIni) }); });
            out.push({ s: r.corpoFim, e: r.fim, k: "se-fim", ins: r });
          } else out.push({ s: i, e: r.fim, k: r.tipo, ins: r });
          i = r.fim; continue;
        }
        i += 2; continue;
      }
      if (c === "{") {
        var f = t.indexOf("}", i);
        if (f !== -1) { out.push({ s: i, e: f + 1, k: "nativo" }); i = f + 1; } else i++;
        continue;
      }
      if (c === "[") {
        var j = i + 1, fim = -1;
        while (j < n) {
          var d = t.charAt(j);
          if (d === "\n" || d === "[") break;
          if (d === "\\" && j + 1 < n && t.charAt(j + 1) !== "\n") { j += 2; continue; }
          if (d === "]") { fim = j; break; }
          j++;
        }
        if (fim !== -1) { out.push({ s: i, e: fim + 1, k: "colchete" }); i = fim + 1; } else i++;
        continue;
      }
      if (c === "*" && (i === 0 || !PALAVRA.test(t.charAt(i - 1)))) {
        var e = i + 1;
        while (e < n && t.charAt(e) !== "\n" && t.charAt(e) !== "*") e++;
        var cont = t.slice(i + 1, e);
        if (t.charAt(e) === "*" && cont && !/^\s|\s$/.test(cont) && !PALAVRA.test(t.charAt(e + 1)) && !/[\[\]{}]/.test(cont)) {
          out.push({ s: i, e: e + 1, k: "corrigivel" }); i = e + 1; continue;
        }
      }
      i++;
    }
    return out;
  }

  // Seleção atual, sem espaços nas pontas. Devolve null (e mostra a dica) se não servir.
  function selecao(opcoes) {
    var ed = PE.estado();
    var ta = ed.ta, t = ta.value, a = ta.selectionStart, b = ta.selectionEnd;
    if (a === b) { dica("Primeiro selecione com o mouse o trecho."); return null; }
    while (a < b && /\s/.test(t.charAt(a))) a++;
    while (b > a && /\s/.test(t.charAt(b - 1))) b--;
    if (a === b) { dica("Primeiro selecione com o mouse o trecho."); return null; }
    var s = t.slice(a, b);
    if (s.indexOf("\n") !== -1) { dica("Selecione um trecho de uma linha só."); return null; }
    if (/[\[\]{}]/.test(s)) { dica("Esse trecho já tem marcação. Selecione outro trecho ou use ↺ Desfazer marcação."); return null; }
    var m = marcadores(t);
    for (var k = 0; k < m.length; k++) if (m[k].s < b && m[k].e > a) { dica("Esse trecho já está marcado. Use ↺ Desfazer marcação antes."); return null; }
    if (opcoes && opcoes.palavraInteira && (PALAVRA.test(t.charAt(a - 1)) || PALAVRA.test(t.charAt(b)))) {
      dica("Selecione a palavra ou a frase inteira, sem cortar uma palavra no meio."); return null;
    }
    return { a: a, b: b, s: s };
  }

  function textoDica(s) {          // o trecho vira a dica cinza do espaço
    var d = s.replace(/\s+/g, " ").replace(/\s+\/\s+/g, "/").replace(/=/g, ":").replace(/^(\.\.\.|…)\s*/, "");
    d = d.replace(/^[\s\/*]+|[\s\/*]+$/g, "");   // "/" ou "*" soltos nas pontas não viram marcação
    d = d.replace(/^[@?]+\s*/, "");              // "@" ou "?" no começo teriam outro significado
    if (!d) d = "campo";
    if (/^hoje$/i.test(d)) return "ex. " + d;
    return /\d/.test(d) ? "ex. " + d : d;
  }

  // ---------- os botões ----------
  // Com o cursor dentro de um espaço [ ... ] que já existe, o botão muda esse espaço (veja personalizados-espaco.js)
  function acaoEspaco() {
    var ed = PE.estado();
    var sp = P.Espaco ? P.Espaco.achar(ed.ta.value, ed.ta.selectionStart, ed.ta.selectionEnd) : null;
    if (sp) { if (sp.ok) P.Espaco.dialogo(sp); else dica(sp.dica); return; }
    var x = selecao(); if (!x) return;
    dica(""); substituir(x.a, x.b, "[" + P.escapar(textoDica(x.s)) + "]");
  }

  function acaoCorrigivel() {
    var x = selecao({ palavraInteira: true }); if (!x) return;
    if (x.s.indexOf("*") !== -1) { dica("Esse trecho já tem um asterisco (*). Selecione outro trecho."); return; }
    if (x.s.indexOf("\\") !== -1) { dica("Esse trecho tem uma barra invertida (\\). Selecione outro trecho."); return; }
    dica(""); substituir(x.a, x.b, "*" + x.s + "*");
  }

  function acaoTitulo() {
    var ed = PE.estado();
    var ta = ed.ta, t = ta.value, a = ta.selectionStart, b = ta.selectionEnd;
    var ini = t.lastIndexOf("\n", a - 1) + 1;
    if (b > a && t.charAt(b - 1) === "\n") b--;
    var fim = t.indexOf("\n", b); if (fim === -1) fim = t.length;
    var linhas = t.slice(ini, fim).split("\n");
    var cheias = linhas.filter(function (l) { return l.trim() !== ""; });
    if (!cheias.length) { dica("Clique numa linha com texto para virar título."); return; }
    var todas = cheias.every(function (l) { return l.charAt(0) === "#"; });
    var novas = linhas.map(function (l) {
      if (!l.trim()) return l;
      return todas ? l.replace(/^#+\s*/, "") : (l.charAt(0) === "#" ? l : "#" + l);
    });
    dica(""); substituir(ini, fim, novas.join("\n"));
  }

  function acaoHoje() {
    var ed = PE.estado();
    var ta = ed.ta, t = ta.value, a = ta.selectionStart, b = ta.selectionEnd, m = marcadores(t);
    for (var k = 0; k < m.length; k++) if (m[k].s < b && m[k].e > a || (a === b && m[k].s < a && a < m[k].e)) { dica("Aqui já há uma marcação. Clique em outro lugar do texto."); return; }
    dica(""); substituir(a, b, "[hoje]");
  }

  // 💡 Lembrete (só na tela): o trecho selecionado vira ((DICA: ...)); sem seleção, abre um ((DICA: )) para escrever
  function acaoLembrete() {
    var ed = PE.estado();
    var ta = ed.ta, a = ta.selectionStart, b = ta.selectionEnd;
    if (a === b) {
      var m = marcadores(ta.value);
      for (var k = 0; k < m.length; k++) if (m[k].s < a && a < m[k].e) { dica("Aqui já há uma marcação. Clique em outro lugar do texto."); return; }
      substituir(a, b, "((DICA: ))", -2);
      dica("Escreva o lembrete entre os parênteses. Ele aparece só na tela e não vai para o texto.");
      return;
    }
    var x = selecao(); if (!x) return;
    if (/\(\(|\)\)/.test(x.s)) { dica("Esse trecho tem parênteses duplos. Selecione outro trecho."); return; }
    substituir(x.a, x.b, "((DICA: " + x.s + "))");
    dica("O trecho virou um lembrete: aparece só na tela e não vai para o texto. ↺ Desfazer marcação devolve o texto.");
  }

  function acaoDesfazer() {
    var ed = PE.estado();
    var ta = ed.ta, t = ta.value, a = ta.selectionStart, b = ta.selectionEnd, m = marcadores(t), alvo = null;
    var menor = function (cond) { var best = null; m.forEach(function (x) { if (cond(x) && (!best || x.e - x.s < best.e - best.s)) best = x; }); return best; };
    alvo = menor(function (x) { return x.s <= a && b <= x.e && a < x.e; }) || menor(function (x) { return x.s <= a && b <= x.e; });
    if (!alvo) { dica("Clique dentro do trecho marcado que você quer desfazer."); return; }
    var bruto = t.slice(alvo.s, alvo.e), novo = bruto, mm, ini = alvo.s, fim = alvo.e, msg = "";
    if (alvo.k === "corrigivel") novo = bruto.slice(1, -1);
    else if (alvo.k === "se-ini" || alvo.k === "se-fim") {      // tira só a instrução: o texto de dentro continua, mas passa a aparecer sempre
      var r = alvo.ins;
      ini = r.ini; fim = r.fim; novo = t.slice(r.corpoIni, r.corpoFim);
      msg = "Tirei a condição: o texto que estava dentro agora aparece sempre. Ctrl+Z desfaz.";
    } else if (alvo.k === "aviso" || alvo.k === "dica") {       // volta ao texto comum
      novo = t.slice(alvo.ins.corpoIni, alvo.ins.corpoFim).trim();
    } else if (alvo.k === "dias") novo = "";
    else if (alvo.k === "colchete") {
      var c = bruto.slice(1, -1).trim();
      if (/^hoje$/i.test(c)) novo = "hoje";
      else if (/^@/.test(c)) {
        var k0 = c.search(/[:=]/), nm = (k0 === -1 ? c.slice(1) : c.slice(1, k0)).trim();
        novo = k0 !== -1 && c.charAt(k0) === ":" ? c.slice(k0 + 1).replace(/=.*$/, "").trim().replace(/^ex\.\s+/i, "") : nm;
        if (!novo) novo = nm;
      }
      else if (/^\?\s/.test(c)) { novo = ""; msg = "Tirei a pergunta. Se havia textos ((SE …)) ligados a ela, veja os avisos abaixo do texto."; }
      else if (/^(\.\.\.|…)/.test(c)) novo = c.replace(/^(\.\.\.|…)\s*/, "");
      else if (/(^|\s)\/(\s|$)/.test(c)) novo = c.split(/\s+\/\s+/)[0];
      else novo = c.replace(/^ex\.\s+/i, "");
    } else {
      mm = /^\{(\w+)(?:#[^:}]*)?(?::([^}]*))?\}$/.exec(bruto);
      var tp = mm ? mm[1] : "", arg = mm && mm[2] ? mm[2] : "";
      if (tp === "campo" || tp === "texto") novo = arg.replace(/=.*$/, "").replace(/^ex\.\s+/i, "");
      else if (tp === "editavel") novo = arg;
      else if (tp === "opcao") novo = arg.split("|")[0].replace(/^\*/, "").trim();
      else if (tp === "controle" || tp === "auxiliar" || tp === "dica" || tp === "aviso") novo = "";
      else if (tp === "hoje") novo = "hoje";
    }
    dica(msg); substituir(ini, fim, novo);
    if (msg) dica(msg);
  }

  PE.marcadores = marcadores; PE.selecao = selecao; PE.textoDica = textoDica;
  PE.acaoEspaco = acaoEspaco; PE.acaoCorrigivel = acaoCorrigivel; PE.acaoTitulo = acaoTitulo; PE.acaoHoje = acaoHoje;
  PE.acaoLembrete = acaoLembrete; PE.acaoDesfazer = acaoDesfazer;
})();
