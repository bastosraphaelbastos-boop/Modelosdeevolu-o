/*
 * Evoluções personalizadas — o criador: janelinha "Escolha entre opções" (cria uma escolha nova ou muda uma que já existe, com texto a mais,
 * pergunta só na tela e aviso). Parte de personalizados-editor.js; carregue depois de personalizados-marcar.js. A janelinha "Contar dias" está em
 * personalizados-dialogos.js.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var PE = P._ed;          // peças compartilhadas do criador (registradas em personalizados-editor.js)
  var el = PE.el, botao = PE.botao, dica = PE.dica, substituir = PE.substituir, janelinha = PE.janelinha,
      limparTextarea = PE.limparTextarea, compilarCache = PE.compilarCache, acharAlvo = PE.acharAlvo, semBarras = PE.semBarras,
      selecao = PE.selecao;
  var seqId = 0;

  function textoOpcao(s) {
    return s.replace(/[\[\]{}|]/g, " ").replace(/\s+\/\s+/g, "/").replace(/\s+/g, " ").trim().replace(/^[\s\/*]+|[\s\/*]+$/g, "");   // "/" ou "*" soltos nas pontas
  }

  var HINT_EXTRA = "Dica: escreva ___ (3 sublinhados) para deixar um espaço a preencher. Também vale [dica], *texto corrigível* e ((AVISO: …)).";
  var paraMarcas = function (s) { return s.replace(/_{3,}/g, "[complete]"); };       // ___ vira espaço para preencher
  var deMarcas = function (s) { return s.replace(/\[complete\]/g, "___"); };

  // ---------- diálogo "Escolha entre opções": cria uma escolha nova ou muda uma que já existe ----------
  // opcoes (opcional): { nova: true, pergunta: true|false, aoCancelar: fn }. "nova" = escolha nova num ponto do texto, sem seleção
  // (usado pela paleta de blocos prontos); se a pessoa cancelar, aoCancelar desfaz o bloco vazio que a paleta criou.
  function dialogoOpcoes(opcoes) {
    var ed = PE.estado();
    opcoes = opcoes || {};
    var nova = !!opcoes.nova;
    // No modo Blocos o diálogo trabalha sobre o texto inteiro (os ((SE ...)) podem estar em outro bloco) e depois reabre o bloco
    var volta = P.Blocos && P.Blocos.paraMestre ? P.Blocos.paraMestre() : null;
    var sair = function () { if (volta) { var v = volta; volta = null; v.voltar(); } };
    var ta = ed.ta;
    limparTextarea();
    var a = ta.selectionStart, b = ta.selectionEnd, t0 = ta.value;
    var r0 = compilarCache(t0), E = r0.estrutura, alvo = nova ? null : acharAlvo(E, a, b), x = null, esc = null;
    if (alvo && alvo.nativo) { sair(); dica("Esta escolha usa marcações avançadas ({ }) e não abre aqui. Use ↺ Desfazer marcação para voltar ao texto simples e marque de novo."); return; }
    if (alvo) {
      esc = E.escolhas[alvo.idx];
      if (esc.ops.some(function (o) { return /[\[\]{}|]/.test(P.semPriv(o)); })) {      // o diálogo não consegue reescrever esses símbolos
        sair(); dica("Esta escolha tem colchetes, chaves ou barra | dentro de uma opção, e não abre aqui. Mude-a direto no texto.");
        return;
      }
    } else if (!nova) {
      if (a === b) { sair(); dica("Selecione com o mouse o trecho que será a 1ª opção. (Para mudar uma escolha que já existe, clique dentro dela.)"); return; }
      x = selecao(); if (!x) { var msgSel = ed.dica.textContent; sair(); dica(msgSel); return; }
    }
    dica("");
    var j = janelinha("dlg-op-titulo", esc ? "Mudar escolha" : nova ? (opcoes.pergunta ? "Nova pergunta" : "Nova escolha") : "Escolha entre opções", true), caixa = j.corpo;
    var fecharJ = j.fechar;
    j.fechar = function () { fecharJ(); sair(); if (nova && opcoes.aoCancelar) opcoes.aoCancelar(); };    // cancelar: o bloco vazio criado pela paleta some
    caixa.appendChild(el("p", "dlg-ajuda", nova && opcoes.pergunta
      ? "A pergunta aparece só na tela. Escreva a pergunta, as respostas e, em cada resposta, o texto que entra no modelo."
      : "Escreva as opções. O médico vai clicar numa delas ao preencher."));
    var lista = el("div", "dlg-lista"), msg = el("p", "dlg-erro"), linhas = [];

    // o que já existe junto desta escolha (textos extras, aviso de «sem resposta»)
    var seDono = esc ? E.ses.filter(function (s) { return s.dono === alvo.idx; }).map(function (s) { var o = {}; for (var k in s) o[k] = s[k]; return o; }) : [];
    var achaSE = function (op) {
      var alvoOp = semBarras(P.semPriv(op)).trim().toLowerCase();
      for (var k = 0; k < seDono.length; k++) if (seDono[k].tipo === "se" && !seDono[k].usado && semBarras(P.semPriv(seDono[k].opcao)).trim().toLowerCase() === alvoOp) { seDono[k].usado = true; return seDono[k]; }
      return null;
    };
    var corpoDe = function (s) { return t0.slice(s.corpoIni, s.corpoFim); };

    function novaLinha(valor, se) {
      var L = { se: se || null, orig: valor }, id = ++seqId;
      var bloco = el("div", "dlg-op");
      var i = el("input", "dlg-campo"); i.type = "text"; i.value = valor || ""; i.maxLength = 120; i.id = "dlg-op-i" + id;
      var rot = "Opção " + (linhas.length + 1);
      i.setAttribute("aria-label", rot); i.placeholder = rot;
      var link = el("button", "dlg-extra-link"); link.type = "button"; link.setAttribute("aria-expanded", "false");
      var caixaExtra = el("div", "dlg-extra"); caixaExtra.hidden = true;
      var lb = el("label", "dlg-extra-rot"); lb.htmlFor = "dlg-op-t" + id;
      var tx = el("textarea", "dlg-extra-ta"); tx.id = "dlg-op-t" + id; tx.rows = 2; tx.maxLength = 3000;
      var hint = el("p", "dlg-hint", HINT_EXTRA);
      caixaExtra.appendChild(lb); caixaExtra.appendChild(tx); caixaExtra.appendChild(hint);
      var rotulo = function () { var o = textoOpcao(i.value); lb.textContent = "Texto que aparece logo depois, se escolher " + (o ? "«" + o + "»" : "esta opção") + ":"; };
      var abrirExtra = function (sim) {
        caixaExtra.hidden = !sim; link.setAttribute("aria-expanded", sim ? "true" : "false");
        link.textContent = sim ? "✕ tirar o texto a mais" : "＋ escrever algo a mais se escolher esta";
        if (!sim) tx.value = "";
      };
      link.addEventListener("click", function () { var abrir = caixaExtra.hidden; abrirExtra(abrir); if (abrir) tx.focus(); });
      i.addEventListener("input", function () { rotulo(); avisoPadrao(); });
      i.addEventListener("keydown", function (e) {
        if (e.key === "Enter") { e.preventDefault(); var p = linhas.indexOf(L); if (linhas[p + 1]) linhas[p + 1].inp.focus(); else inserir(); }
      });
      var altura = function () { tx.rows = Math.min(7, Math.max(2, tx.value.split("\n").length)); };
      tx.addEventListener("input", altura);
      tx.addEventListener("keydown", function (e) { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); inserir(); } });
      bloco.appendChild(i); bloco.appendChild(link); bloco.appendChild(caixaExtra);
      L.inp = i; L.ta = tx; L.bloco = bloco; L.abrirExtra = abrirExtra;
      rotulo(); abrirExtra(false);
      if (se) {                                  // texto extra que já existia: abre já preenchido
        var cru = corpoDe(se);
        L.espaco0 = /^[ \t]/.test(cru);
        L.uiOrig = deMarcas(cru.replace(/^[ \t]/, ""));
        abrirExtra(true); tx.value = L.uiOrig; altura();
      }
      linhas.push(L); lista.appendChild(bloco);
      return L;
    }

    if (esc) esc.ops.forEach(function (op) { novaLinha(semBarras(P.semPriv(op)), achaSE(op)); });
    else if (nova) { novaLinha(""); novaLinha(""); }
    else { novaLinha(x.s); novaLinha(""); }
    caixa.appendChild(lista);
    var mais = botao("dlg-mais", "", "＋ outra opção", function () {
      if (linhas.length >= 12) return;
      novaLinha("").inp.focus();
    });
    caixa.appendChild(mais);

    // ----- Mais ajustes -----
    var det = el("details", "dlg-ajustes"); det.appendChild(el("summary", "", "Mais ajustes"));
    var ckC = el("input"); ckC.type = "checkbox"; ckC.id = "dlg-ck-ctrl";
    var lbC = el("label", "dlg-ck"); lbC.htmlFor = "dlg-ck-ctrl";
    lbC.appendChild(ckC); lbC.appendChild(el("span", "", " É só uma pergunta na tela (a resposta não vai para o texto; só o que você escreveu a mais)"));
    var subC = el("div", "dlg-sub"); subC.hidden = true;
    var lbP = el("label", "", "Pergunta:"); lbP.htmlFor = "dlg-perg";
    var perg = el("input", "dlg-campo"); perg.type = "text"; perg.id = "dlg-perg"; perg.maxLength = 120; perg.placeholder = "Ex.: Alta hoje?";
    subC.appendChild(lbP); subC.appendChild(perg);
    var ckA = el("input"); ckA.type = "checkbox"; ckA.id = "dlg-ck-aviso";
    var lbA = el("label", "dlg-ck"); lbA.htmlFor = "dlg-ck-aviso";
    lbA.appendChild(ckA); lbA.appendChild(el("span", "", " ⚠ Aviso se ficar sem resposta (some quando responder)"));
    var subA = el("div", "dlg-sub"); subA.hidden = true;
    var lbT = el("label", "", "Texto do aviso (aparece só na tela até alguém responder; no texto final fica ___):"); lbT.htmlFor = "dlg-aviso";
    var aviso = el("input", "dlg-campo"); aviso.type = "text"; aviso.id = "dlg-aviso"; aviso.maxLength = 200;
    subA.appendChild(lbT); subA.appendChild(aviso);
    det.appendChild(lbC); det.appendChild(subC); det.appendChild(lbA); det.appendChild(subA);
    caixa.appendChild(det);

    var avisoSujo = false;
    function opsAtuais() { return linhas.map(function (L) { return textoOpcao(L.inp.value); }).filter(Boolean); }
    function avisoPadrao() {
      if (avisoSujo) return;
      var q = ckC.checked ? textoOpcao(perg.value) : "";
      var base = q || opsAtuais().join("/");
      aviso.value = "responda «" + base + "»";
    }
    aviso.addEventListener("input", function () { avisoSujo = true; });
    perg.addEventListener("input", avisoPadrao);
    ckC.addEventListener("change", function () { subC.hidden = !ckC.checked; avisoPadrao(); if (ckC.checked) perg.focus(); });
    ckA.addEventListener("change", function () { subA.hidden = !ckA.checked; avisoPadrao(); });

    // estado inicial (ao mudar uma escolha que já existe)
    var srAtual = null;      // aviso «sem resposta» que já existe e pode ser editado aqui
    var srOutro = null;      // «sem resposta» com outro conteúdo: fica como está
    if (esc) {
      if (esc.ctrl) { ckC.checked = true; subC.hidden = false; perg.value = P.semPriv(esc.rot).replace(/\?\s*$/, ""); }
      seDono.forEach(function (s) {
        if (s.tipo !== "sr") return;
        var corpoSR = corpoDe(s).trim(), li = corpoSR.indexOf("((") === 0 ? P.lerInstrucao(corpoSR, 0) : null;
        if (li && li.tipo === "aviso" && li.fim === corpoSR.length) { if (!srAtual) { srAtual = s; srAtual.texto = corpoSR.slice(li.corpoIni, li.corpoFim).trim(); } else if (!srOutro) srOutro = s; }
        else if (!srOutro) srOutro = s;
      });
      if (srAtual) { ckA.checked = true; subA.hidden = false; aviso.value = srAtual.texto; avisoSujo = true; }
      else avisoPadrao();
      if (srOutro) { var nota = el("p", "dlg-hint", "Já existe um texto «enquanto ninguém responder» que não aparece aqui; ele será mantido."); det.appendChild(nota); }
      if (esc.ctrl || srAtual) det.open = true;
    } else avisoPadrao();
    if (nova && opcoes.pergunta) {            // pergunta nova: já com a pergunta marcada e o 1º texto a mais aberto
      ckC.checked = true; subC.hidden = false; det.open = true; linhas[0].abrirExtra(true); avisoPadrao();
    }

    caixa.appendChild(msg);
    var acoes = el("div", "dlg-acoes");

    function inserir() {
      msg.textContent = "";
      var vistas = {}, itens = [], remover = [];
      for (var k = 0; k < linhas.length; k++) {
        var L = linhas[k], op = textoOpcao(L.inp.value), tx = L.ta.value.trim();
        if (!op) {
          if (tx && !L.se) { msg.textContent = "A " + (k + 1) + "ª opção está vazia, mas tem texto a mais. Escreva a opção ou apague o texto."; L.inp.focus(); return; }
          if (L.se) remover.push(L.se);              // opção apagada: some junto com o texto que dependia dela
          continue;
        }
        var chave = op.toLowerCase();
        if (vistas[chave] !== undefined) {
          if (tx) { msg.textContent = "A opção «" + op + "» aparece duas vezes e uma delas tem texto a mais. Deixe cada opção diferente."; L.inp.focus(); return; }
          if (L.se) remover.push(L.se);
          continue;
        }
        vistas[chave] = true;
        if (tx && /[:]/.test(op)) { msg.textContent = "Para escrever algo a mais, a opção «" + op + "» não pode ter dois-pontos (:). Tire o sinal da opção."; L.inp.focus(); return; }
        itens.push({ op: op, tx: tx, L: L });
      }
      if (itens.length < 2) { msg.textContent = "Escreva pelo menos duas opções diferentes."; return; }
      var digitadas = linhas.filter(function (L) { return textoOpcao(L.inp.value); }).length;

      var q = "";
      if (ckC.checked) {
        q = textoOpcao(perg.value).replace(/\?+\s*$/, "").trim();
        if (!q) { msg.textContent = "Escreva a pergunta, por exemplo: Alta hoje?"; if (det) det.open = true; perg.focus(); return; }
        if (q.indexOf("?") !== -1) { msg.textContent = "A pergunta deve ter um único «?», no fim."; det.open = true; perg.focus(); return; }
        q += "?";
        if (!itens.some(function (i) { return i.tx; })) { msg.textContent = "Uma pergunta só na tela precisa de um texto a mais em pelo menos uma opção (senão ela não muda nada)."; return; }
      }
      var avTxt = "";
      if (ckA.checked) {
        avTxt = aviso.value.trim();
        if (!avTxt) { msg.textContent = "Escreva o texto do aviso ou desmarque “Aviso se ficar sem resposta”."; det.open = true; aviso.focus(); return; }
      }

      var novaEsc = (ckC.checked ? "[? " + P.escapar(q) + " " : "[") + itens.map(function (i) { return P.escapar(i.op); }).join(" / ") + "]";
      var edicoes = [], novos = "";
      var seTexto = function (op, tx, espaco) { return "((SE " + P.escapar(op) + ":" + (espaco ? " " : "") + paraMarcas(tx) + "))"; };
      itens.forEach(function (i) {
        var s = i.L.se;
        if (s) {
          var mudouTx = i.L.ta.value !== i.L.uiOrig, mudouOp = semBarras(P.semPriv(s.opcao)).trim() !== i.op;
          if (!i.tx) { remover.push(s); return; }
          if (!mudouTx && !mudouOp) return;
          var corpoNovo = mudouTx ? (i.L.espaco0 ? " " : "") + paraMarcas(i.tx) : corpoDe(s);
          edicoes.push({ ini: s.ini, fim: s.fim, novo: "((SE " + P.escapar(i.op) + ":" + corpoNovo + "))" });
        } else if (i.tx) novos += seTexto(i.op, i.tx, true);
      });
      remover.forEach(function (s) { edicoes.push({ ini: s.ini, fim: s.fim, novo: "" }); });
      if (srAtual) {
        if (!ckA.checked) edicoes.push({ ini: srAtual.ini, fim: srAtual.fim, novo: "" });
        else if (avTxt !== srAtual.texto) edicoes.push({ ini: srAtual.ini, fim: srAtual.fim, novo: "((SE SEM RESPOSTA:" + (/^[ 	]/.test(corpoDe(srAtual)) ? " " : "") + "((AVISO: " + avTxt + "))))" });
      } else if (ckA.checked) novos += "((SE SEM RESPOSTA: ((AVISO: " + avTxt + "))))";

      var ini0 = esc ? esc.ini : nova ? a : x.a, fim0 = esc ? esc.fim : nova ? a : x.b;
      edicoes.push({ ini: ini0, fim: fim0, novo: novaEsc + novos });
      var ini = Math.min.apply(null, edicoes.map(function (e) { return e.ini; })), fim = Math.max.apply(null, edicoes.map(function (e) { return e.fim; }));
      var fatia = t0.slice(ini, fim);
      edicoes.sort(function (p, q2) { return q2.ini - p.ini; }).forEach(function (e) { fatia = fatia.slice(0, e.ini - ini) + e.novo + fatia.slice(e.fim - ini); });
      var novoTexto = t0.slice(0, ini) + fatia + t0.slice(fim);

      // Confere se o resultado não criou problemas novos (ex.: um "))" no meio do texto a mais)
      var antes = {}; r0.erros.forEach(function (e) { antes[e.msg] = true; });
      var rn = P.compilar(novoTexto), novoErro = null;
      rn.erros.forEach(function (e) { if (!antes[e.msg] && !novoErro) novoErro = e; });
      if (novoErro) { msg.textContent = "Não deu certo: " + novoErro.msg.charAt(0).toUpperCase() + novoErro.msg.slice(1) + "."; return; }

      fecharJ();
      substituir(ini, fim, fatia);
      sair();
      if (digitadas > itens.length) dica("Havia opções repetidas; juntei as iguais.");
      else if (esc) dica("Escolha atualizada.");
    }
    acoes.appendChild(botao("dlg-cancelar", "", "Cancelar", j.fechar));
    acoes.appendChild(botao("dlg-ok", "", esc ? "✓ Salvar mudanças" : "✓ Inserir", inserir));
    j.caixa.appendChild(acoes);
    j.abrir();
    (nova ? (opcoes.pergunta ? perg : linhas[0].inp) : esc ? linhas[0].inp : linhas[1].inp).focus();
  }

  PE.dialogoOpcoes = dialogoOpcoes;
})();
