/*
 * Evoluções personalizadas — ações de um modelo de "Minhas evoluções" no menu do botão direito: apagar, duplicar e mudar a ordem (Alt+↑/↓).
 * (Estavam em personalizados-ui.js; foram para cá para o arquivo não crescer demais.) Carregue antes de personalizados-ui.js.
 * Favoritos e ocultos (app/favoritos.js): ao apagar, o id sai da preferência; Duplicar NÃO copia favorito nem oculto (o id da cópia é outro).
 * Alt+↑/↓ anda na ordem que está NA TELA dentro do mesmo tipo (favorito com favorito, comum com comum): a ordem manual guardada continua
 * sendo a de P.lista e não se perde ao tirar dos favoritos. Modelo oculto (mostrado pelo link) não muda de lugar.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var A = P.Acoes = {};
  var idPasta = function (r) { var f = P.pastaDe(r); return f ? f.id : ""; };
  var botaoDe = function (rec) { return document.querySelector('#painel-personalizadas .linha-modelo[data-rid="' + rec.id + '"] .item-modelo'); };

  A.apagar = function (rec) {
    var M = P.Motor, aberto = M.ativo() && M.ativo().id === "p:" + rec.id;
    M.perguntar("Apagar o modelo “" + rec.nome + "”?\n\nIsso não pode ser desfeito. Uma cópia de segurança de todos os outros modelos é guardada no computador." +
      (aberto && M.alterado() ? "\n\nEle está aberto na tela: o que foi preenchido também será perdido." : ""), "Sim, apagar", "Cancelar", true).then(function (sim) {
      if (!sim) return;
      P.apagados[rec.id] = true;
      P.lista = P.lista.filter(function (r) { return r.id !== rec.id; });
      P.gravar();
      if (P.Favoritos) P.Favoritos.limpar();            // o id do modelo apagado sai de favoritos/ocultos
      P.renderMenu();
      if (aberto && P.classicos.length) M.selecionar(P.classicos[0]);
      P.copiaSeguranca();
      P.mostrarStatus("Modelo apagado. Uma cópia de segurança foi guardada no computador.");
    });
  };

  // ⧉ Duplicar: cria “Nome (cópia)” logo depois do original (na mesma pasta), grava e faz a cópia de segurança como os outros
  A.duplicar = function (rec) {
    var nome = P.nomeLivre(rec.nome.slice(0, P.MAX_NOME - 8) + " (cópia)", P.nomesUsados()), agora = Date.now();
    var nova = { id: P.novoId(), nome: nome, texto: rec.texto, criado: agora, alterado: agora };
    nova.origem = nova.id;       // a cópia é outro modelo: origem nova (não se confunde com o original ao receber atualizações)
    if (P.pastaDe(rec)) nova.pasta = rec.pasta;
    if (rec.categoria) nova.categoria = rec.categoria;
    P.lista.splice(P.lista.indexOf(rec) + 1, 0, nova);
    P.numerar();
    P.gravar();
    P.renderMenu();
    P.copiaSeguranca();              // ainda dentro do clique
    P.mostrarStatus("Modelo duplicado como “" + nome + "”. Uma cópia de segurança foi guardada no computador.");
  };

  // Alt+↑ / Alt+↓ no nome do modelo: muda a ordem dentro da pasta dele (e a numeração dos atalhos Alt+1..9)
  A.mover = function (rec, d) {
    var F = P.Favoritos, ver = F.meus(idPasta(rec), F.mostrando("p"));      // a ordem da tela (favoritos no alto; ocultos no lugar, se à vista)
    if (F.ehOculto(F.chave(rec))) return;
    var alvo = ver[ver.indexOf(rec) + d];
    if (!alvo || F.ehFavorito(F.chave(alvo)) !== F.ehFavorito(F.chave(rec))) return;
    var i = P.lista.indexOf(rec), j = P.lista.indexOf(alvo);
    P.lista.splice(i, 1); P.lista.splice(j, 0, rec);
    P.numerar();
    P.gravar();
    P.renderMenu();
    var bt = botaoDe(rec); if (bt) bt.focus({ preventScroll: true });      // o foco acompanha o modelo (repetir Alt+↑/↓)
  };
})();
