/*
 * Evoluções personalizadas — nomes dos modelos, formato do arquivo .txt (enviar / abrir) e guarda dos modelos no navegador
 * (localStorage, só os MODELOS — nunca o que é preenchido). Parte lógica, não mexe na tela.
 * Carregue depois de personalizados.js (o compilador). A tela do arquivo está em personalizados-arquivo.js.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var C = function (n) { return String.fromCharCode(n); };

  P.nomeLimpo = function (n) { return P.limpar(n).replace(/\s+/g, " ").replace(/={3,}/g, "=").trim().slice(0, P.MAX_NOME).trim(); };
  P.chaveNome = function (n) { return P.nomeLimpo(n).toLowerCase(); };
  P.nomeLivre = function (nome, usados) {     // "Nome" -> "Nome (2)" se já existir
    var chaves = usados.map(P.chaveNome), base = P.nomeLimpo(nome), k = 2, cand = base;
    while (chaves.indexOf(P.chaveNome(cand)) !== -1) cand = P.nomeLimpo(base.slice(0, P.MAX_NOME - 5) + " (" + (k++) + ")");
    return cand;
  };

  // ---------- Arquivo .txt de exportação/importação ----------
  var CAB = "MODELOS DE EVOLUÇÃO: ARQUIVO DE MODELOS PERSONALIZADOS";
  var INSTR = "(Para usar: abra o app, vá em \"Minhas evoluções\" e clique em \"Abrir arquivo de modelo\".)";

  // Linhas que separam modelos no arquivo. A leitura e a validação usam EXATAMENTE estas duas regras.
  // Toleram * ou _ nas pontas (negrito/itálico de aplicativos de mensagem).
  P.RE_INI = /^[\s*_]*=+\s*MODELO\s*:\s*(.*?)\s*=*[\s*_]*$/i;
  P.RE_FIM = /^[\s*_]*=+\s*FIM\s+DO\s+MODELO\s*=*[\s*_]*$/i;

  // Texto do modelo sem linhas vazias no começo/fim e com quebras normais (usado ao salvar e ao comparar)
  P.normTexto = function (t) { return P.limpar(t).replace(/^(?:[ \t]*\n)+/, "").replace(/\s+$/, ""); };

  // Coloca \ na frente dos símbolos que as regras usariam (para gerar marcadores com texto qualquer)
  P.escapar = function (s) { return String(s).replace(/[\\\[\]{}]/g, function (ch) { return "\\" + ch; }); };

  // A linha "PASTA: nome" fica FORA dos modelos (antes do 1º separador ou entre um "FIM DO MODELO" e o próximo separador):
  // versões antigas do app ignoram tudo o que está fora dos separadores, então ainda leem o arquivo sem problema.
  P.RE_PASTA = /^[\s*_]*PASTA\s*:\s*(.*?)[\s*_]*$/i;

  // A linha "ORIGEM: id" também fica FORA dos modelos, logo antes do separador do modelo a que se refere (versões antigas ignoram, como a PASTA).
  // O id é o do modelo no computador de quem o criou: assim, ao receber de novo, o app reconhece que é o mesmo modelo (personalizados-recebidos.js).
  P.RE_ORIGEM = /^[\s*_]*ORIGEM\s*:\s*([\w-]{1,40})[\s*_]*$/i;
  P.origemValida = function (o) { return typeof o === "string" && /^[\w-]{1,40}$/.test(o); };
  P.origemDe = function (m) { return P.origemValida(m.origem) ? m.origem : (m.id || ""); };      // modelo sem o campo = ele mesmo é a origem

  // op (opcional): { pasta: "Nome" } = todos os modelos numa pasta só ("Enviar pasta");
  //                { comPastas: true } = cada modelo na sua pasta (cópia de segurança e "Salvar todos"): os sem pasta primeiro, depois um bloco por pasta
  P.exportarTexto = function (lista, op) {
    var L = [CAB, INSTR], bloco = function (m) {
      if (P.origemDe(m)) L.push("ORIGEM: " + P.origemDe(m));
      L.push("===== MODELO: " + P.nomeLimpo(m.nome) + " =====");
      L.push(P.normTexto(m.texto).replace(/\n/g, "\r\n"));
      L.push("===== FIM DO MODELO =====", "");
    };
    op = op || {};
    if (op.pasta) { L.push("PASTA: " + op.pasta, ""); lista.forEach(bloco); }
    else if (op.comPastas && P.pastas && P.pastas.length && lista.length) {      // (sem nenhum modelo, uma pasta sozinha não vai: versões antigas leriam a linha PASTA como se fosse um modelo)
      var dona = function (m) { var f = P.pastaDe(m); return f ? f.id : ""; };
      L.push("");
      lista.filter(function (m) { return !dona(m); }).forEach(bloco);
      P.pastas.forEach(function (f) { L.push("PASTA: " + f.nome, ""); lista.filter(function (m) { return dona(m) === f.id; }).forEach(bloco); });
    }
    else { L.push(""); lista.forEach(bloco); }
    return C(0xFEFF) + L.join("\r\n");
  };

  // Mensagens coladas de aplicativos de conversa começam com data/hora/nome; tira isso só das linhas que são separadores de modelo
  var RE_MSG1 = /^\[\d{1,2}:\d{2}(?::\d{2})?,\s*\d{1,2}\/\d{1,2}\/\d{2,4}\]\s*[^:]{1,60}:\s*/;
  var RE_MSG2 = /^\d{1,2}\/\d{1,2}\/\d{2,4},?\s+\d{1,2}:\d{2}(?::\d{2})?\s*[-–]\s*[^:]{1,60}:\s*/;
  function semPrefixoMensagem(l) {
    var s = l.replace(RE_MSG1, "").replace(RE_MSG2, "");
    return s !== l && (P.RE_INI.test(s) || P.RE_FIM.test(s)) ? s : l;
  }

  // Devolve { modelos:[{nome,texto,pasta,origem?}], pastas:[nomes], semCabecalho:bool, avisos:[] }
  // pasta = nome da pasta (linha "PASTA: ..." fora dos modelos, vale para os modelos seguintes) ou null; pastas = todas as nomeadas no arquivo
  // origem (só se o arquivo tem a linha "ORIGEM: id" logo antes do modelo) = id do modelo no computador de quem o criou
  P.lerArquivo = function (conteudo) {
    var linhas = P.limpar(conteudo).split("\n").map(semPrefixoMensagem), modelos = [], avisos = [], atual = null, pastaAtual = null, pastas = [], origemPendente = null;
    var fechar = function () {
      if (!atual) return;
      atual.texto = P.normTexto(atual.linhas.join("\n"));
      delete atual.linhas; modelos.push(atual); atual = null;
    };
    var linhaPasta = function (l) {
      var pm = P.RE_PASTA.exec(l);
      if (!pm) return false;
      var n = P.nomePastaLimpo(pm[1]);
      pastaAtual = !n || P.chavePasta(n) === "sem pasta" ? null : n;
      if (pastaAtual && !pastas.some(function (x) { return P.chavePasta(x) === P.chavePasta(pastaAtual); })) pastas.push(pastaAtual);
      return true;
    };
    var linhaOrigem = function (l) { var om = P.RE_ORIGEM.exec(l); if (om) origemPendente = om[1]; return !!om; };
    linhas.forEach(function (l) {
      var m = P.RE_INI.exec(l);
      if (m) {
        if (atual) { avisos.push("Faltou a linha “FIM DO MODELO” em “" + atual.nome + "”."); fechar(); }
        atual = { nome: m[1], linhas: [], pasta: pastaAtual };
        if (origemPendente) atual.origem = origemPendente;
        origemPendente = null;
      } else if (P.RE_FIM.test(l)) { if (atual) fechar(); }
      else if (atual) atual.linhas.push(l);
      else if (!linhaPasta(l)) linhaOrigem(l);
    });
    if (atual) { avisos.push("Faltou a linha “FIM DO MODELO” no último modelo."); fechar(); }
    if (modelos.length) return { modelos: modelos, pastas: pastas, semCabecalho: false, avisos: avisos };
    var RE_CAB = /^MODELOS DE EVOLU[ÇC][ÃA]O\s*[:—-]\s*ARQUIVO/i, nosso = linhas.some(function (l) { return RE_CAB.test(l.trim()); });      // "nosso" = arquivo do app (só então a linha PASTA é do app)
    var solto = P.normTexto(linhas.filter(function (l) { return !RE_CAB.test(l.trim()) && l.trim().indexOf("(Para usar:") !== 0 && !(nosso && (P.RE_PASTA.test(l) || P.RE_ORIGEM.test(l))); }).join("\n"));
    return { modelos: solto ? [{ nome: "", texto: solto, pasta: null }] : [], pastas: solto || !nosso ? [] : pastas, semCabecalho: !!solto, avisos: [] };
  };

  // ---------- Guarda no navegador (só os modelos) ----------
  P.persistente = true;   // false se o navegador bloqueou o armazenamento: modelos só duram até fechar a página
  P.apagados = {};        // ids apagados nesta janela (para não voltarem ao mesclar com o que outra janela gravou)

  function armazem() { try { return window.localStorage; } catch (e) { return null; } }

  // Lê e limpa a lista guardada. Se o conteúdo estiver corrompido, guarda uma cópia antes que seja sobrescrito.
  P.carregar = function () {
    var lista = [], vistos = {}, st = armazem();
    if (!st) { P.persistente = false; return lista; }
    var bruto = null;
    try {
      bruto = st.getItem(P.CHAVE);
      var dados = bruto ? JSON.parse(bruto) : [];
      if (!Array.isArray(dados)) throw new Error("formato");
      dados.forEach(function (r) {
        if (r && typeof r.id === "string" && typeof r.nome === "string" && typeof r.texto === "string") {
          var id = r.id.replace(/[^\w-]/g, "").slice(0, 40);
          if (!id || vistos[id]) { var base = id || "m", n = 2; while (vistos[base + "-" + n]) n++; id = base + "-" + n; } // repetido: id novo, sempre o mesmo a cada leitura
          vistos[id] = true;
          var item = { id: id, nome: P.nomeLimpo(r.nome) || "Sem nome", texto: P.limpar(r.texto).slice(0, P.MAX_MODELO), criado: +r.criado || 0, alterado: +r.alterado || 0 };
          if (typeof r.ordem === "number" && isFinite(r.ordem)) item.ordem = r.ordem;     // ordem manual (registros antigos não têm o campo)
          if (typeof r.pasta === "string" && r.pasta) item.pasta = r.pasta.replace(/[^\w-]/g, "").slice(0, 40) || undefined;     // id da pasta (sem o campo = "Sem pasta")
          if (item.pasta === undefined) delete item.pasta;
          if (P.origemValida(r.origem)) item.origem = r.origem;     // id do modelo no computador de quem o criou (sem o campo = o próprio id)
          if (typeof r.categoria === "string" && /^[a-z]{1,20}$/.test(r.categoria)) item.categoria = r.categoria;     // categoria (app/categorias.js); sem o campo = evolução
          lista.push(item);
        }
      });
      if (lista.some(function (r) { return r.ordem !== undefined; })) {       // com ordem manual: quem tem "ordem" vem primeiro; o resto fica no fim, como estava
        lista.forEach(function (r, k) { r.pos0 = k; });
        lista.sort(function (a, b) { return (a.ordem === undefined ? 1e12 : a.ordem) - (b.ordem === undefined ? 1e12 : b.ordem) || a.pos0 - b.pos0; });
        lista.forEach(function (r) { delete r.pos0; });
      }
    } catch (e) {
      if (bruto) { try { st.setItem(P.CHAVE + ".corrompido", bruto); } catch (e2) { /* sem problema */ } }
    }
    return lista;
  };

  // Grava a lista. Antes, junta (por id) os modelos que OUTRA janela tenha gravado, para não apagá-los.
  P.salvarLista = function (lista) {
    var st = armazem();
    if (!st) { P.persistente = false; return false; }
    try {
      var meus = {};
      lista.forEach(function (r) { meus[r.id] = true; });
      P.carregar().forEach(function (r) { if (!meus[r.id] && !P.apagados[r.id]) lista.push(r); });
      st.setItem(P.CHAVE, JSON.stringify(lista)); P.persistente = true; return true;
    } catch (e) { P.persistente = false; return false; }
  };

  P.novoId = function () { return "m" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); };

  // Preferência: painéis abertos/fechados
  P.lerPref = function () { try { return JSON.parse(armazem().getItem(P.CHAVE_PREF)) || {}; } catch (e) { return {}; } };
  P.salvarPref = function (p) {        // junta com o que já está guardado (painéis do menu, modo do criador)
    var a = P.lerPref(); if (typeof a !== "object" || Array.isArray(a)) a = {};
    Object.keys(p).forEach(function (k) { a[k] = p[k]; });
    try { armazem().setItem(P.CHAVE_PREF, JSON.stringify(a)); } catch (e) { /* sem problema */ }
  };
})();
