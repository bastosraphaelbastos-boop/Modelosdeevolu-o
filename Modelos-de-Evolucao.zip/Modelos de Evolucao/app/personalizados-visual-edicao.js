/*
 * Editor visual do modo Texto — mudar o texto: histórico (Ctrl+Z/Y), digitar, apagar (pedaço inteiro, \x, palavra), colar e acertar a composição
 * (teclas mortas). Parte de personalizados-visual.js; carregue depois dele. Registra em V._f: trocar, desfazer, aoBeforeInput, acertarComposicao.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var V = P.Visual;
  var I = function () { return P._ed; };
  var ed = function () { return I().estado(); };
  var ESC = V.ESC;
  var st = null; V.aoMudarEstado(function (x) { st = x; });
  var desenhar = function () { return V._f.desenhar(); }, colocarCursor = function (a, b) { return V._f.colocarCursor(a, b); },
      selecaoModelo = function () { return V._f.selecaoModelo(); }, paraModelo = function (n, o) { return V._f.paraModelo(n, o); };

  // ---------- mudar o texto ----------
  function guardarHistorico(tipo) {
    var agora = Date.now();
    if (tipo === "digitar" && st.ultTipo === "digitar" && agora - st.ultHora < 900) { st.ultHora = agora; return; }
    var m = ed().master;
    st.hist.push({ t: m.value, a: m.selectionStart, b: m.selectionEnd });
    if (st.hist.length > 200) st.hist.shift();
    st.refazer = []; st.ultTipo = tipo; st.ultHora = agora;
  }
  // Troca [a, b) do texto do modelo por "novo" e redesenha, com o cursor em cursorA..cursorB
  function trocar(a, b, novo, tipo, cursorA, cursorB) {
    var m = ed().master, t = m.value;
    if (t.length - (b - a) + novo.length > P.MAX_MODELO) { I().dica("O modelo chegou ao tamanho máximo (" + P.MAX_MODELO + " caracteres)."); return; }
    guardarHistorico(tipo);
    m.value = t.slice(0, a) + novo + t.slice(b);
    var ca = cursorA != null ? cursorA : a + novo.length, cb = cursorB != null ? cursorB : ca;
    m.setSelectionRange(ca, cb);
    desenhar(); colocarCursor(ca, cb);
    I().agendar();
    if (st.busca) st.busca.depoisDeMudar();
  }
  function desfazer(volta) {
    var de = volta ? st.refazer : st.hist, para = volta ? st.hist : st.refazer;
    if (!de.length) return;
    var m = ed().master, x = de.pop();
    para.push({ t: m.value, a: m.selectionStart, b: m.selectionEnd });
    m.value = x.t; m.setSelectionRange(x.a, x.b);
    st.ultTipo = "";
    desenhar(); colocarCursor(x.a, x.b); I().agendar();
  }

  // Posição de apagar para trás / para a frente a partir de "pos" (um pedaço inteiro, um \x ou um caractere)
  function passo(pos, dir) {
    var t = ed().master.value, i = 0, n = st.unidades.length;
    while (i < n - 1 && pos > st.bases[i] + st.unidades[i].length) i++;
    var base = st.bases[i], L = st.linhas[i], ini = base + L._pref, fim = base + st.unidades[i].length;
    if (dir < 0) {
      if (pos <= ini) return L._pref ? { a: base, b: ini } : (i > 0 ? { a: base - 1, b: base } : null);   // começo do título: tira o título
      var achou = null;
      Array.prototype.forEach.call(L.childNodes, function (c) { if (c._cru && ini + c._rf === pos) achou = { a: ini + c._ri, b: pos }; });
      if (achou) return achou;
      var k = pos - 1;
      if (k - 1 >= ini && t.charAt(k - 1) === "\\" && ESC.indexOf(t.charAt(k)) !== -1) k--;
      else if (/[\uDC00-\uDFFF]/.test(t.charAt(k)) && k - 1 >= ini) k--;
      return { a: k, b: pos };
    }
    if (pos >= fim) return i < n - 1 ? { a: pos, b: pos + 1 } : null;
    var ach = null;
    Array.prototype.forEach.call(L.childNodes, function (c) { if (c._cru && ini + c._ri === pos) ach = { a: pos, b: ini + c._rf }; });
    if (ach) return ach;
    var j = pos + 1;
    if (t.charAt(pos) === "\\" && ESC.indexOf(t.charAt(pos + 1)) !== -1) j++;
    else if (/[\uD800-\uDBFF]/.test(t.charAt(pos))) j++;
    return { a: pos, b: Math.min(j, fim) };
  }
  function palavra(pos, dir) {
    var t = ed().master.value, i = pos;
    if (dir < 0) { while (i > 0 && /\s/.test(t.charAt(i - 1)) && t.charAt(i - 1) !== "\n") i--; while (i > 0 && !/\s/.test(t.charAt(i - 1))) i--; return { a: i, b: pos }; }
    while (i < t.length && /\s/.test(t.charAt(i)) && t.charAt(i) !== "\n") i++; while (i < t.length && !/\s/.test(t.charAt(i))) i++; return { a: pos, b: i };
  }

  function aoBeforeInput(e) {
    var tipo = e.inputType;
    if (tipo === "insertCompositionText") return;          // composição (acentos em alguns teclados): o navegador escreve; acertamos no fim
    e.preventDefault();
    var x = selecaoModelo(); if (!x) return;
    var a = x.a, b = x.b, alvo = e.getTargetRanges ? e.getTargetRanges()[0] : null;
    if (alvo && (tipo === "insertReplacementText" || (tipo.indexOf("delete") === 0 && !alvo.collapsed && a === b && tipo !== "deleteContentBackward" && tipo !== "deleteContentForward"))) {
      a = paraModelo(alvo.startContainer, alvo.startOffset); b = paraModelo(alvo.endContainer, alvo.endOffset);
    }
    if (tipo === "insertText" || tipo === "insertReplacementText") {
      var dado = e.data != null ? e.data : (e.dataTransfer ? e.dataTransfer.getData("text/plain") : "");
      dado = P.limpar(dado).replace(/\n/g, " ");
      if (dado) trocar(a, b, dado, "digitar");
      if (dado === "!" && st.busca) P.Comandos.bangVisual(st.busca, st.ponte);
    } else if (tipo === "insertParagraph" || tipo === "insertLineBreak") trocar(a, b, "\n", "linha");
    else if (tipo === "insertFromPaste" || tipo === "insertFromDrop") colar(e.dataTransfer ? e.dataTransfer.getData("text/plain") : "", a, b);
    else if (tipo === "historyUndo") desfazer(false);
    else if (tipo === "historyRedo") desfazer(true);
    else if (tipo.indexOf("delete") === 0) {
      var r = { a: a, b: b };
      if (a === b) {
        if (tipo === "deleteWordBackward") r = palavra(a, -1);
        else if (tipo === "deleteWordForward") r = palavra(a, 1);
        else if (/Backward/.test(tipo)) r = passo(a, -1);
        else if (/Forward/.test(tipo)) r = passo(a, 1);
        else r = null;
      }
      if (r && r.b > r.a) trocar(r.a, r.b, "", "apagar");
    }
  }
  function colar(texto, a, b) {
    var cru = String(texto || "").replace(/\r\n?/g, "\n"), limpo = P.limparColado(cru);
    limpo = P.limpar(limpo);
    if (!limpo) return;
    var cabe = P.MAX_MODELO - (ed().master.value.length - (b - a)), corte = limpo.length > cabe;
    if (corte) limpo = limpo.slice(0, Math.max(0, cabe));
    trocar(a, b, limpo, "colar");
    if (corte) I().dica("O texto colado é grande demais: só coube parte dele (máximo " + P.MAX_MODELO + " caracteres).");
    else if (limpo !== cru) I().dica("Ajustei o texto colado (tirei marcas de formatação).");
  }
  // Depois de uma composição (o navegador escreveu sozinho): lê o texto das linhas mexidas e acerta o modelo
  function acertarComposicao() {
    var partes = [];
    Array.prototype.forEach.call(st.raiz.childNodes, function (L) {
      if (!L.classList || !L.classList.contains("wy-linha")) { partes.push((L.textContent || "").replace(/​/g, "")); return; }
      var i = st.linhas.indexOf(L), u = i >= 0 ? st.unidades[i] : "", s = i >= 0 ? u.slice(0, L._pref) : "";
      Array.prototype.forEach.call(L.childNodes, function (c) {
        if (c._cru) s += c._cru;
        else if (c.nodeType === 3) s += c.data.replace(/​/g, "").replace(/ /g, " ");
        else if (c.nodeName !== "BR") s += (c.textContent || "").replace(/​/g, "");
      });
      partes.push(s);
    });
    var m = ed().master, novo = partes.join("\n");
    if (novo === m.value) return;
    var x = selecaoModelo();
    guardarHistorico("digitar");
    m.value = novo; st.unidades = []; st.linhas = [];
    desenhar(); I().agendar();
    if (x) colocarCursor(x.a, x.b);
  }

  V._f.trocar = trocar; V._f.desfazer = desfazer; V._f.aoBeforeInput = aoBeforeInput; V._f.acertarComposicao = acertarComposicao;
})();
