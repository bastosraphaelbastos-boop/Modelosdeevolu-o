/*
 * Evoluções personalizadas — descompilar: sintaxe nativa -> regras simples (parte lógica, não mexe na tela).
 * Usado ao copiar um modelo clássico para "Minhas evoluções". Carregue depois de personalizados.js (o compilador).
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var K = P._reg, PALAVRA = K.PALAVRA, TIPOS = K.TIPOS, RE_CAB = K.RE_CAB, RE_TOK = K.RE_TOK, RE_BARRA = K.RE_BARRA;

  // ---------- descompilar: sintaxe nativa -> regras simples ----------
  // Usado ao copiar um modelo clássico para "Minhas evoluções". Só converte o que dá para converter sem mudar o texto gerado;
  // o resto fica na sintaxe nativa (que continua valendo). Três níveis, do mais completo ao mais seguro:
  //   2 = tudo (escolhas, ((SE)), [? ], ((AVISO)), ((DICA)), [@nome], ((DIAS DESDE)));  1 = só o formato antigo;  0 = só escapa o texto.
  var ESC_TXT = "[]*{}\\";
  var RE_ESPECIAL = /^(@|\?\s)/;                       // um [@...] ou [? ...] teria outro significado
  var semAspas = function (s) { return s === s.trim() && s && !/[\[\]{}\\]/.test(s) && s.indexOf("\n") === -1; };

  // Varre o texto nativo e decide o que pode virar ((SE)) / [A / B] / ((DIAS DESDE))
  function decidir(t, calculos) {
    var n = t.length, i = 0, aberto = null, esc = [], blocos = [], campos = {}, total = {};
    while (i < n) {
      var c = t.charAt(i), nx = t.charAt(i + 1);
      if (c === "[" && nx === "[") {
        var h = RE_CAB.exec(t.substr(i, 300));
        if (h) { aberto = { pos: i, chave: h[1], valor: h[2].trim(), corpoIni: i + h[0].length, antes: esc.length }; i += h[0].length; continue; }
      }
      if (c === "]" && nx === "]" && aberto) {
        aberto.fim = i + 2; aberto.corpo = t.slice(aberto.corpoIni, i); blocos.push(aberto);
        total[aberto.chave] = (total[aberto.chave] || 0) + 1; aberto = null; i += 2; continue;
      }
      if (c === "{") {
        var f = t.indexOf("}", i), cand = f === -1 ? "" : t.slice(i, f + 1), m = cand ? RE_TOK.exec(cand) : null;
        if (m && TIPOS.indexOf(m[1]) !== -1) {
          if ((m[1] === "opcao" || m[1] === "controle") && !aberto) {
            var a = m[3] || "";
            if (m[1] === "controle" && a.indexOf("?") !== -1) a = a.slice(a.indexOf("?") + 1);
            esc.push({ pos: i, nome: m[2] || "", ops: a.split("|").map(function (o) { return o.trim().replace(/^\*\s*/, ""); }) });
          }
          if (m[1] === "campo" && m[2]) (campos[m[2]] = campos[m[2]] || []).push({ pos: i, arg: m[3], aberto: !!aberto });
          i = f + 1; continue;
        }
      }
      i++;
    }
    var nomeCont = {};
    esc.forEach(function (e) { if (e.nome) nomeCont[e.nome] = (nomeCont[e.nome] || 0) + 1; });
    var dec = { blocos: {}, escSimples: {}, dias: {}, restantes: [] }, vazio = { blocos: {}, escSimples: {}, dias: {} }, conv = {};
    blocos.forEach(function (b) {
      var k, idx = -1, sr = b.valor === "";
      for (k = b.antes - 1; k >= 0; k--) if (esc[k].nome === b.chave) { idx = k; break; }
      if (idx === -1 || nomeCont[b.chave] !== 1) return;
      if (sr) { if (idx !== b.antes - 1) return; }                      // «sem resposta» vale para a escolha mais próxima
      else {
        if (esc[idx].ops.indexOf(b.valor) === -1 || /[\[\]{}\\:|]|^\*|\(\(|\)\)/.test(b.valor)) return;
        var alvo = b.valor.toLowerCase(), prim = -1;
        for (k = b.antes - 1; k >= 0 && prim === -1; k--) if (esc[k].ops.some(function (o) { return o.toLowerCase() === alvo; })) prim = k;
        if (prim !== idx) return;                                       // outra escolha mais próxima também tem essa opção: ambíguo
      }
      var corpoS = converter(b.corpo, 2, vazio, true), teste = "((SE " + (sr ? "SEM RESPOSTA" : b.valor) + ":" + corpoS + "))";
      var li = P.lerInstrucao(teste, 0);
      if (!li || li.fim !== teste.length || li.corpoFim !== teste.length - 2 || li.tipo !== (sr ? "sr" : "se")) return;
      dec.blocos[b.pos] = { sr: sr, valor: b.valor, corpo: corpoS, fim: b.fim };
      conv[b.chave] = (conv[b.chave] || 0) + 1;
    });
    esc.forEach(function (e) { if (!e.nome || (nomeCont[e.nome] === 1 && (conv[e.nome] || 0) === (total[e.nome] || 0))) dec.escSimples[e.pos] = true; });
    (calculos || []).forEach(function (c) {
      var arr = campos[c.para], de = campos[c.de];
      var ok = c.tipo === "dias" && arr && arr.length === 1 && !arr[0].aberto && arr[0].arg !== undefined && arr[0].arg.indexOf("=") === -1 &&
        de && de.length && c.de === P.normalizarNome(c.de) && c.para !== c.de &&
        !calculos.some(function (o) { return o !== c && Object.keys(o).some(function (k) { return k !== "tipo" && o[k] === c.para; }); });
      if (ok) dec.dias[arr[0].pos] = c.de; else dec.restantes.push(c);
    });
    return dec;
  }

  function converter(t, nivel, dec, dentro) {
    var n = t.length, i = 0, out = "", aberto = false;
    var escChar = function (c, nx) {
      if (ESC_TXT.indexOf(c) !== -1) return "\\" + c;
      if (c === "(" && nx === "(") return "\\(";
      if (c === ")" && nx === ")" && dentro) return "\\)";
      return c;
    };
    while (i < n) {
      var c = t.charAt(i), nx = t.charAt(i + 1);
      if (!dentro && c === "[" && nx === "[") {
        var h = RE_CAB.exec(t.substr(i, 300));
        if (h) {
          var db = dec && dec.blocos[i];
          if (db) { out += "((SE " + (db.sr ? "SEM RESPOSTA" : db.valor) + ":" + db.corpo + "))"; i = db.fim; continue; }
          aberto = true; out += h[0]; i += h[0].length; continue;
        }
      }
      if (!dentro && c === "]" && nx === "]" && aberto) { aberto = false; out += "]]"; i += 2; continue; }
      if (c === "{") {
        var f = t.indexOf("}", i), cand = f === -1 ? "" : t.slice(i, f + 1), m = cand ? RE_TOK.exec(cand) : null;
        if (m && TIPOS.indexOf(m[1]) !== -1) {
          var tp = m[1], nome = m[2], arg = m[3], novo = null, prox = t.charAt(f + 1);
          if (nivel >= 1 && !nome) {
            if (tp === "hoje" && arg === undefined) novo = "[hoje]";
            else if (tp === "campo" && arg !== undefined && semAspas(arg) && arg.indexOf("=") === -1 && !/^hoje$/i.test(arg) && arg.slice(0, 3) !== "..." && arg.charAt(0) !== "…" && !RE_BARRA.test(arg) && !RE_ESPECIAL.test(arg)) novo = "[" + arg + "]";
            else if (tp === "texto" && arg !== undefined && semAspas(arg) && arg.indexOf("=") === -1 && arg.slice(0, 3) !== "..." && arg.charAt(0) !== "…" && !RE_BARRA.test(arg)) novo = "[..." + arg + "]";
            else if (tp === "opcao" && arg !== undefined) {
              var ops = arg.split("|");
              if (ops.length > 1 && !RE_ESPECIAL.test(ops[0]) && ops.every(function (o) { return semAspas(o) && o.charAt(0) !== "*" && !RE_BARRA.test(o); })) novo = "[" + ops.join(" / ") + "]";
            } else if (tp === "editavel" && arg !== undefined && semAspas(arg) && arg.indexOf("*") === -1 && arg.indexOf("\\") === -1
              && !PALAVRA.test(out.charAt(out.length - 1)) && !PALAVRA.test(prox)) novo = "*" + arg + "*";
          }
          if (nivel === 2 && novo === null) {
            if (tp === "campo" && nome && arg !== undefined) {
              if (dec && dec.dias[i] !== undefined) novo = "((DIAS DESDE @" + dec.dias[i] + "))";
              else if (nome === P.normalizarNome(nome) && arg !== "" && semAspas(arg)) novo = "[@" + nome + ": " + arg + "]";
            } else if ((tp === "opcao" || tp === "controle") && arg !== undefined && (!nome || (dec && dec.escSimples[i]))) {
              var rot = "", resto = arg;
              if (tp === "controle") { var q = arg.indexOf("?"); if (q !== -1) { rot = arg.slice(0, q + 1); resto = arg.slice(q + 1); } else rot = null; }
              var os = resto.split("|").map(function (o) { return o.trim(); });
              var bom = rot !== null && os.length > 1 && os.every(function (o) { return semAspas(o) && o.charAt(0) !== "*" && !RE_BARRA.test(o); });
              if (bom && tp === "controle") bom = semAspas(rot.trim()) && rot.trim().replace(/\?/g, "").trim() !== "" && rot.indexOf("|") === -1;
              if (bom && tp === "opcao" && RE_ESPECIAL.test(os[0])) bom = false;
              if (bom) novo = tp === "opcao" ? "[" + os.join(" / ") + "]" : "[? " + rot.trim() + " " + os.join(" / ") + "]";
            } else if ((tp === "aviso" || tp === "dica") && arg !== undefined && arg.trim() && !/\(\(|\)\)|\\/.test(arg) && arg.indexOf("\n") === -1) {
              novo = "((" + (tp === "aviso" ? "AVISO" : "DICA") + ": " + arg.trim() + "))";
            }
          }
          out += novo !== null ? novo : cand; i = f + 1; continue;
        }
        out += "\\{"; i++; continue;     // { solto ou marcador desconhecido: texto literal
      }
      out += escChar(c, nx); i++;
    }
    return out;
  }

  // ---------- conferência: o texto gerado tem de ser o mesmo, em todas as escolhas ----------
  var RE_BLOCO_N = /\[\[([\wÀ-ſ]+)=([^:\]]*):([\s\S]*?)\]\]/g;
  var RE_TOKEN_N = /\{(\w+)(?:#([\wÀ-ſ]+))?(?::([^}]*))?\}/g;

  // Lê o texto nativo como o motor: devolve { partes, vals, esc }
  function lerComoMotor(nat) {
    var partes = [], ult = 0, m, re = new RegExp(RE_BLOCO_N.source, "g"), vals = {}, esc = [], cont = 0;
    while ((m = re.exec(nat))) {
      if (m.index > ult) partes.push({ t: nat.slice(ult, m.index) });
      partes.push({ chave: m[1], valor: m[2].trim(), t: m[3] });
      ult = re.lastIndex;
    }
    partes.push({ t: nat.slice(ult) });
    partes.forEach(function (p) {
      var last = 0, mt, rt = new RegExp(RE_TOKEN_N.source, "g"), segs = [];
      while ((mt = rt.exec(p.t))) {
        if (mt.index > last) segs.push({ lit: p.t.slice(last, mt.index) });
        var tp = mt[1], arg = mt[3] || "", id = mt[2] || ("~" + (cont++)), tk = { tp: tp, id: id };
        if (tp === "opcao" || tp === "controle") {
          var a = arg, pad = "";
          if (tp === "controle" && a.indexOf("?") !== -1) a = a.slice(a.indexOf("?") + 1);
          tk.ops = a.split("|").map(function (o) { o = o.trim(); if (o.charAt(0) === "*") { o = o.slice(1).trim(); pad = o; } return o; });
          vals[id] = pad;
          if (p.chave === undefined) esc.push(tk);
        } else if (tp === "campo" || tp === "texto") { var q = arg.indexOf("="); vals[id] = q === -1 ? "" : arg.slice(q + 1); }
        else if (tp === "editavel") vals[id] = arg.trim();
        else if (tp === "auxiliar") vals[id] = "";
        segs.push(tk); last = rt.lastIndex;
      }
      if (last < p.t.length) segs.push({ lit: p.t.slice(last) });
      p.segs = segs;
    });
    return { partes: partes, vals: vals, esc: esc };
  }

  // Texto que o motor geraria com (no máximo) uma escolha feita: sel = { k: nº da escolha, o: nº da opção }
  function textoComEscolha(an, sel) {
    var vals = {}, k;
    for (k in an.vals) vals[k] = an.vals[k];
    if (sel) vals[an.esc[sel.k].id] = an.esc[sel.k].ops[sel.o];
    var VAZ = "\u0000";
    var s = an.partes.map(function (p) {
      if (p.chave !== undefined && vals[p.chave] !== p.valor) return "";
      return p.segs.map(function (g) {
        if (g.lit !== undefined) return g.lit;
        var v = (vals[g.id] || "").trim();
        switch (g.tp) {
          case "campo": case "editavel": return v || "___";
          case "aviso": return "___";
          case "hoje": return "(hoje)";
          case "opcao": return v || g.ops.join(" / ");
          default: return VAZ;                        // controle, auxiliar, dica, texto
        }
      }).join("");
    }).join("");
    return P.semPriv(s.replace(/^[\u0000 \t]*\u0000[\u0000 \t]*\n/gm, "").replace(/\u0000/g, "").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim());
  }

  function equivalentes(orig, simples) {
    var r = P.compilar(simples);
    if (r.erros.length) return false;
    var A = lerComoMotor(orig), B = lerComoMotor(r.saida);
    if (A.esc.length !== B.esc.length || textoComEscolha(A) !== textoComEscolha(B)) return false;
    for (var k = 0; k < A.esc.length; k++) {
      if (A.esc[k].ops.join("|") !== B.esc[k].ops.join("|")) return false;
      for (var o = 0; o < A.esc[k].ops.length; o++) if (textoComEscolha(A, { k: k, o: o }) !== textoComEscolha(B, { k: k, o: o })) return false;
    }
    return true;
  }

  // Devolve { texto, restantes, semMais }: restantes = cálculos automáticos do clássico que NÃO foram para o texto simples; semMais = o clássico tinha botão {mais#...}
  P.descompilarModelo = function (nat, calculos) {
    var orig = P.limpar(nat), calcs = calculos || [];
    // {mais#...} (botão "＋ Adicionar laboratório" dos clássicos) não existe nas regras simples: a linha do botão é tirada e o criador avisa (semMais)
    var puro = orig.replace(/^\{mais#[^}\n]*\}\n/gm, ""), semMais = puro !== orig;
    orig = puro;
    var dec = decidir(orig, calcs), a = converter(orig, 2, dec, false);
    if (equivalentes(orig, a)) return { texto: a, restantes: dec.restantes, semMais: semMais };
    var b = converter(orig, 1, null, false);                               // formato antigo: tem de voltar exatamente igual
    if (P.semPriv(P.compilar(b).saida) === orig) return { texto: b, restantes: calcs.slice(), semMais: semMais };
    return { texto: converter(orig, 0, null, false), restantes: calcs.slice(), semMais: semMais };
  };
  P.descompilar = function (nat, calculos) { return P.descompilarModelo(nat, calculos).texto; };
})();
