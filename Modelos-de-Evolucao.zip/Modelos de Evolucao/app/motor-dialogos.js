/*
 * Motor — pergunta Sim/Não dentro da página e o copiar para a área de transferência (parte do motor.js; carregue antes dele).
 * Peças compartilhadas em window.MotorPecas (M); esta fica em M.Dialogos.
 */
(function () {
  "use strict";
  var M = window.MotorPecas = window.MotorPecas || {};
  var $ = function (id) { return document.getElementById(id); };

  // Pergunta Sim/Não dentro da própria página. Não usa confirm() do navegador, que pode ser
  // bloqueado ("impedir esta página de criar caixas de diálogo") e responder "não" sozinho.
  function perguntar(msg, textoSim, textoNao, focoNao) {   // focoNao (opcional): o foco começa em "Não" (perguntas perigosas)
    return new Promise(function (resolver) {
      var tela = $("pergunta-tela"), sim = $("pergunta-sim"), nao = $("pergunta-nao");
      var anterior = document.activeElement;
      $("pergunta-texto").textContent = msg;
      sim.textContent = textoSim || "Sim"; nao.textContent = textoNao || "Não";
      tela.hidden = false;
      var fim = function (resposta) {
        tela.hidden = true;
        sim.onclick = nao.onclick = tela.onkeydown = null;
        if (anterior && anterior.focus && !resposta) anterior.focus({ preventScroll: true });
        resolver(resposta);
      };
      sim.onclick = function () { fim(true); };
      nao.onclick = function () { fim(false); };
      tela.onkeydown = function (e) {
        if (e.key === "Escape") { e.preventDefault(); fim(false); }
        else if (e.key === "Tab") { e.preventDefault(); (document.activeElement === sim ? nao : sim).focus(); }
      };
      (focoNao ? nao : sim).focus();
    });
  }

  // Copia `texto` para a área de transferência e avisa o resultado (aoOk / aoFalhar). Usado pelo "Copiar texto" e pelos botões Copiar da aba Alta.
  // Se o caminho moderno falhar, usa uma caixa temporária fora da tela, para NUNCA deixar o cursor dentro do texto final com tudo selecionado
  // (a próxima tecla apagaria o texto e pausaria os campos)
  function copiarTexto(texto, aoOk, aoFalhar) {
    var reserva = function () {
      var anterior = document.activeElement, t = document.createElement("textarea");
      t.value = texto; t.setAttribute("readonly", ""); t.style.position = "fixed"; t.style.left = "-9999px";
      document.body.appendChild(t); t.select();
      var deu = false;
      try { deu = document.execCommand("copy"); } catch (e) { deu = false; }
      document.body.removeChild(t);
      if (anterior && anterior.focus) anterior.focus({ preventScroll: true });
      deu ? aoOk() : aoFalhar();
    };
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(texto).then(aoOk, reserva);
    else reserva();
  }

  // Copia o texto final (pergunta antes se ainda há pendências). irParaPendente: o que fazer se a pessoa escolher "Voltar e preencher"
  function copiar(irParaPendente) {
    var texto = $("saida").value;
    var ok = function () {
      $("status-copia").textContent = "✔ Copiado! Agora cole no prontuário (Ctrl+V).";
      setTimeout(function () { $("status-copia").textContent = ""; }, 6000);
    };
    var falhou = function () {
      $("status-copia").textContent = "Não consegui copiar sozinho: clique no texto final, aperte Ctrl+A e depois Ctrl+C.";
    };
    var executar = function () { copiarTexto(texto, ok, falhou); };
    var n = Number($("pendentes").dataset.n);
    if (n > 0) {
      perguntar("Ainda há " + n + (n === 1 ? " item sem preencher, que sairá" : " itens sem preencher, que sairão") + " como ___ ou A / B.\n\nCopiar mesmo assim?",
        "Copiar mesmo assim", "Voltar e preencher").then(function (sim) { if (sim) executar(); else irParaPendente(); });
    } else executar();
  }

  M.Dialogos = { perguntar: perguntar, copiar: copiar, copiarTexto: copiarTexto };
})();
