/*
 * Motor — interpretação do texto do modelo (parte do motor.js; carregue antes dele).
 * Transforma o texto com {campo:dica}, {opcao:A|B}, [[nome=VALOR: ...]] etc. numa lista de "segmentos" que o motor desenha na tela.
 * Não mexe na tela e não sabe de obstetrícia. Peças compartilhadas em window.MotorPecas (M); esta fica em M.Modelo.
 */
(function () {
  "use strict";
  var M = window.MotorPecas = window.MotorPecas || {};
  var contador = 0;        // numera os campos sem #nome (c0, c1...); o motor zera a cada modelo aberto

  function hoje() {
    var d = new Date();
    return String(d.getDate()).padStart(2, "0") + "/" + String(d.getMonth() + 1).padStart(2, "0") + "/" + d.getFullYear();
  }

  var RE_BLOCO = /\[\[([\wÀ-ſ]+)=([^:\]]*):([\s\S]*?)\]\]/g;
  var RE_TOKEN = /\{(\w+)(?:#([\wÀ-ſ]+))?(?::([^}]*))?\}/g;

  // Modelos personalizados usam 4 caracteres privados (U+E000 a U+E003) no lugar de { } [ ] escritos de propósito
  // pelo usuário. Aqui eles voltam a ser os símbolos normais, já depois de o texto ter sido interpretado.
  var RE_ESC = new RegExp("[" + String.fromCharCode(0xE000) + "-" + String.fromCharCode(0xE003) + "]", "g");
  function desfazerEscapes(s) { return typeof s === "string" ? s.replace(RE_ESC, function (c) { return "{}[]".charAt(c.charCodeAt(0) - 0xE000); }) : s; }
  function limparEscapes(segs) {
    segs.forEach(function (s) {
      ["texto", "rotulo", "padrao", "valor"].forEach(function (k) { if (k in s) s[k] = desfazerEscapes(s[k]); });
      if (s.opcoes) s.opcoes = s.opcoes.map(desfazerEscapes);
      if (s.filhos) limparEscapes(s.filhos);
    });
    return segs;
  }

  function interpretar(texto) { return limparEscapes(interpretarBruto(texto)); }

  function interpretarBruto(texto) {
    var segs = [], ultimo = 0, m;
    RE_BLOCO.lastIndex = 0;
    while ((m = RE_BLOCO.exec(texto))) {
      if (m.index > ultimo) segs = segs.concat(tokens(texto.slice(ultimo, m.index)));
      segs.push({ tipo: "bloco", chave: m[1], valor: m[2].trim(), filhos: tokens(m[3]) });
      ultimo = RE_BLOCO.lastIndex;
    }
    return segs.concat(tokens(texto.slice(ultimo)));
  }

  function tokens(texto) {
    var segs = [], ultimo = 0, m, re = new RegExp(RE_TOKEN.source, "g");
    while ((m = re.exec(texto))) {
      if (m.index > ultimo) segs.push({ tipo: "texto_fixo", texto: texto.slice(ultimo, m.index) });
      segs.push(criarToken(m[1], m[2], m[3] || ""));
      ultimo = re.lastIndex;
    }
    if (ultimo < texto.length) segs.push({ tipo: "texto_fixo", texto: texto.slice(ultimo) });
    return segs;
  }

  function criarToken(tipo, nome, arg) {
    // {mais#chave:Rótulo}: botão que acrescenta uma cópia de uma linha do modelo (modelo.repetir[chave]); não é campo e não gasta número (motor-repetir.js)
    if (tipo === "mais") return { tipo: "mais", chave: nome || "", rotulo: arg.trim(), copias: [], prox: 2 };
    var id = nome || ("c" + (contador++));
    if (tipo === "opcao" || tipo === "controle") {
      var rotulo = "";
      if (tipo === "controle" && arg.indexOf("?") !== -1) { rotulo = arg.slice(0, arg.indexOf("?") + 1); arg = arg.slice(arg.indexOf("?") + 1); }
      var padrao = "";
      var ops = arg.split("|").map(function (o) {
        o = o.trim();
        if (o.charAt(0) === "*") { o = o.slice(1).trim(); padrao = o; }
        return o;
      });
      return { tipo: tipo, id: id, opcoes: ops, padrao: padrao, rotulo: rotulo };
    }
    if (tipo === "campo" || tipo === "texto") {
      var i = arg.indexOf("="), rot = arg, pad = "";
      if (i !== -1) { rot = arg.slice(0, i); pad = arg.slice(i + 1); }
      return { tipo: tipo, id: id, rotulo: rot.trim(), padrao: pad };
    }
    if (tipo === "hoje") return { tipo: "campo", id: id, rotulo: "data", padrao: hoje() };
    if (tipo === "editavel") return { tipo: "editavel", id: id, rotulo: "", padrao: arg.trim() };
    if (tipo === "auxiliar") return { tipo: "auxiliar", id: id, rotulo: arg.trim(), padrao: "" };
    if (tipo === "dica") return { tipo: "dica", texto: arg };
    if (tipo === "aviso") return { tipo: "aviso", texto: arg };
    return { tipo: "texto_fixo", texto: "{" + tipo + (arg ? ":" + arg : "") + "}" };
  }

  // Preenche "valores" com o que cada item já traz escrito ([dica=VALOR], {hoje}, trecho corrigível)
  function valoresIniciais(segs, valores) {
    segs.forEach(function (s) {
      if (s.filhos) valoresIniciais(s.filhos, valores);
      else if (s.id && !(s.id in valores)) valores[s.id] = s.padrao || "";
    });
  }

  M.Modelo = {
    interpretar: interpretar, valoresIniciais: valoresIniciais,
    contador: function (n) { if (n !== undefined) contador = n; return contador; }      // o motor zera, guarda e devolve (teste do criador)
  };
})();
