/*
 * Evoluções personalizadas — receber modelos de um arquivo ou de um texto colado (parte lógica) e a pergunta "este modelo já existe".
 * Carregue antes de personalizados-arquivo.js (que tem a janela "Abrir arquivo de modelo" e usa P.importarTexto / P.Recebidos).
 *
 * Cada modelo recebido é comparado com os que o computador já tem:
 *  - mesma ORIGEM (campo opcional `origem` = id do modelo no computador de quem o criou; vem na linha "ORIGEM: id" do arquivo) ou, se ela
 *    não bater com nada, o MESMO NOME;
 *  - texto idêntico: pula em silêncio (conta "iguais");
 *  - texto diferente: pergunta (uma janela, com "fazer o mesmo para os próximos"): "Atualizar o meu" (troca só o texto; id, nome, pasta e
 *    ordem continuam), "Ficar com os dois" (entra como modelo novo, com outro nome) ou "Pular";
 *  - sem correspondência: modelo novo.
 * P.importarTexto devolve { fim, msg, novos, depois? }, { escolher, leitura } (perguntar a pasta), { editor, texto } ou { erro }; quando há
 * modelos que já existem e são diferentes devolve { perguntar:true, conflitos, concluir(decisoes) }: a janela pergunta e chama concluir.
 * Todo texto de terceiros entra por textContent.
 */
(function () {
  "use strict";
  var P = window.Personalizados = window.Personalizados || {};
  var el = P.el;

  P.MSG_NAO_MODELO = "Este arquivo não é um modelo. Escolha o arquivo .txt que você recebeu.";
  var mesmoTexto = function (a, b) { return P.normTexto(a) === P.normTexto(b); };
  var mesmoNome = function (r, nome) { return P.chaveNome(r.nome) === P.chaveNome(nome); };
  var plural = function (n, um, varios) { return n + " " + (n === 1 ? um : varios); };

  // Decide, SEM mexer em nada, o que fazer com cada modelo do arquivo: "grande", "igual", "conflito" (com `alvo` = o modelo daqui) ou "novo"
  function planejar(modelos) {
    var itens = [], planejados = [];
    modelos.forEach(function (m, n) {
      var nome = P.nomeLimpo(m.nome) || "Modelo recebido", texto = P.normTexto(m.texto), item = { m: m, n: n, nome: nome, texto: texto, tipo: "novo" };
      if (!texto.trim()) return;
      if (texto.length > P.MAX_MODELO) { item.tipo = "grande"; itens.push(item); return; }
      var origem = P.origemValida(m.origem) ? m.origem : "";
      var parecido = function (q) { return (origem && q.origem === origem) || P.chaveNome(q.nome) === P.chaveNome(nome); };
      var daLista = P.lista.map(function (r) { return { origem: P.origemDe(r), nome: r.nome, texto: r.texto, rec: r }; });
      var iguais = daLista.concat(planejados).some(function (q) { return parecido(q) && mesmoTexto(q.texto, texto); });
      if (iguais) item.tipo = "igual";
      else {
        var cands = origem ? daLista.filter(function (q) { return q.origem === origem; }) : [];
        if (!cands.length) cands = daLista.filter(function (q) { return P.chaveNome(q.nome) === P.chaveNome(nome); });
        if (cands.length) { item.tipo = "conflito"; item.alvo = cands[0].rec; }
        planejados.push({ origem: origem, nome: nome, texto: texto });      // (o mesmo modelo duas vezes no arquivo: o segundo conta como igual)
      }
      itens.push(item);
    });
    return itens;
  }

  // Faz o que foi decidido. destino: "" = Sem pasta · "manter" = cada modelo na pasta que o arquivo diz (criada se não existir) · id de uma pasta existente.
  // decisoes: uma por conflito, na ordem ("atualizar" | "ambos" | "pular"; faltando = pular)
  function concluir(itens, leitura, avisosLeitura, destino, decisoes) {
    var novos = [], atualizados = [], iguais = 0, pulados = [], grandes = [], comProblema = [], agora = Date.now(), criadas = [], semEspaco = [], usadas = {}, k = 0;
    var alvo = function (nomePasta) {            // id da pasta onde vai (criando se preciso); "" = Sem pasta
      if (destino !== "manter") return destino && P.pastaPorId(destino) ? destino : "";
      if (!nomePasta) return "";
      var f = P.pastaPorNome(nomePasta);
      if (!f) { f = P.criarPasta(nomePasta).pasta || null; if (f) criadas.push(f.nome); else if (semEspaco.indexOf(nomePasta) === -1) semEspaco.push(nomePasta); }
      return f ? f.id : "";
    };
    if (destino === "manter") (leitura.pastas || []).forEach(alvo);      // pastas do arquivo, mesmo as vazias, na ordem dele
    itens.forEach(function (it) {
      if (it.tipo === "grande") { grandes.push(it.nome); return; }
      if (it.tipo === "igual") { iguais++; return; }
      var dec = it.tipo === "conflito" ? decisoes[k++] || "pular" : "novo";
      if (dec === "pular") { pulados.push(it.nome); return; }
      if (dec === "atualizar") {                // só o texto muda: id, nome, pasta e ordem do modelo daqui ficam como estão
        var rec0 = it.alvo;
        rec0.texto = it.texto; rec0.alterado = agora + it.n;
        if (!P.origemValida(rec0.origem) && P.origemValida(it.m.origem)) rec0.origem = it.m.origem;      // passa a reconhecer o modelo pela origem
        atualizados.push(rec0);
        if (P.compilar(it.texto).erros.length) comProblema.push(rec0.nome);
        return;
      }
      var usados = P.nomesUsados(), final = it.nome;
      if (usados.some(function (u) { return P.chaveNome(u) === P.chaveNome(it.nome); })) final = P.nomeLivre(it.nome + " (recebido)", usados);
      var rec = { id: P.novoId(), nome: final, texto: it.texto, criado: agora + it.n, alterado: agora + it.n }, pid = alvo(it.m.pasta);
      if (P.origemValida(it.m.origem)) rec.origem = it.m.origem;
      if (pid) { rec.pasta = pid; usadas[pid] = true; }
      P.lista.push(rec); novos.push(rec);
      if (P.compilar(it.texto).erros.length) comProblema.push(final);
    });
    var mudou = novos.length + atualizados.length + criadas.length;
    if (mudou) {
      if (P.pastas.length) P.salvarPastas();
      Object.keys(usadas).forEach(function (id) { P.lembrarPasta(id, true); });      // a pasta que recebeu modelos aparece aberta
      P.gravar(); P.renderMenu();
    }
    var frases = [], nomesUsadas = Object.keys(usadas).map(function (id) { return P.pastaPorId(id).nome; }), nomes = function (l) { return l.map(function (r) { return r.nome; }).join(", "); };
    if (novos.length + atualizados.length + iguais + pulados.length)
      frases.push(plural(novos.length, "novo", "novos") + ", " + plural(atualizados.length, "atualizado", "atualizados") + ", " + plural(iguais, "igual (pulado)", "iguais (pulados)") + ".");
    if (novos.length) frases.push("Novos: " + nomes(novos) + ".");
    if (atualizados.length) frases.push("Atualizados: " + nomes(atualizados) + ".");
    if (pulados.length) frases.push("Você pulou: " + pulados.join(", ") + ".");
    if (novos.length && nomesUsadas.length) frases.push((nomesUsadas.length === 1 ? "Pasta: “" : "Pastas: “") + nomesUsadas.join("”, “") + "”.");
    if (criadas.length) frases.push((criadas.length === 1 ? "Pasta criada: “" : "Pastas criadas: “") + criadas.join("”, “") + "”.");
    if (semEspaco.length) frases.push("Não consegui criar a pasta “" + semEspaco.join("”, “") + "” (o máximo é " + P.MAX_PASTAS + " pastas): os modelos dela ficaram em “Sem pasta”.");
    if (grandes.length) frases.push("Grande demais para abrir: " + grandes.join(", ") + ".");
    if (comProblema.length) frases.push("Atenção: " + comProblema.join(", ") + (comProblema.length === 1 ? " tem" : " têm") + " trechos com problema. Abra ✏️ Editar para ver.");
    if (mudou) frases.push("Uma cópia de segurança foi guardada no computador.");
    if (avisosLeitura && avisosLeitura.length) frases.push(avisosLeitura.length === 1 ? avisosLeitura[0] : "Atenção: faltou “FIM DO MODELO” em " + avisosLeitura.length + " modelos.");
    if (!frases.length) frases.push("Nenhum modelo foi aberto.");
    return {
      fim: true, msg: frases.join(" "), novos: mudou,
      depois: atualizados.length ? function () { atualizados.forEach(function (r) { P.aposGravar(r, false); }); } : null      // modelo aberto na tela que foi atualizado: recomeça (ou pergunta)
    };
  }

  P.receber = function (leitura, avisosLeitura, destino) {
    var itens = planejar(leitura.modelos), conflitos = itens.filter(function (it) { return it.tipo === "conflito"; });
    if (!conflitos.length) return concluir(itens, leitura, avisosLeitura, destino, []);
    return {
      perguntar: true,
      conflitos: conflitos.map(function (it) { return { nome: it.nome, atualNome: it.alvo.nome }; }),
      concluir: function (decisoes) { return concluir(itens, leitura, avisosLeitura, destino, decisoes); }
    };
  };

  // destino (opcional): veja concluir(). Sem destino, e havendo pastas (no arquivo ou no app), devolve { escolher:true, leitura } para a janela perguntar.
  // nomeArquivo (opcional): quando o texto veio de um arquivo, recusa o que não parece um .txt de modelos
  P.importarTexto = function (txt, nomeArquivo, destino) {
    if (String(txt).length > P.MAX_ARQUIVO) return { erro: "Este texto é grande demais (máximo 5 MB). Confira se é mesmo um arquivo de modelos." };
    if (!String(txt).trim()) return { erro: "Não há nada para abrir." };
    var r = P.lerArquivo(txt);
    if (!r.modelos.length && !(r.pastas && r.pastas.length)) return { erro: "Não encontrei nenhum modelo nesse texto." };
    if (r.semCabecalho) {
      if (nomeArquivo != null && (!/\.txt$/i.test(nomeArquivo) || /^\s*<(!doctype|html|\?xml|svg|head|body)/i.test(txt))) return { erro: P.MSG_NAO_MODELO };
      if (r.modelos[0].texto.length > P.MAX_MODELO) return { erro: "Este texto é grande demais para ser um modelo." };
      return { editor: true, texto: r.modelos[0].texto };
    }
    if (destino === undefined && ((r.pastas && r.pastas.length) || P.pastas.length)) return { escolher: true, leitura: r };
    return P.receber(r, r.avisos, destino || "");
  };

  // ---------- A pergunta (dentro da janela "Abrir arquivo de modelo": `corpo` é o miolo dela) ----------
  // Pergunta um conflito de cada vez; "fazer o mesmo para os próximos" vale só para os que ainda faltam. aoTerminar(decisoes) recebe uma decisão por conflito.
  // A cópia de segurança do estado de ANTES vem no clique da primeira atualização (o download precisa de um clique).
  P.Recebidos = {
    perguntar: function (corpo, conflitos, aoTerminar) {
      var dec = [], i = 0, todos = "", fezCopia = false;
      function decidir(escolha, repetir) {
        if (escolha === "atualizar" && !fezCopia) { fezCopia = true; P.copiaSeguranca(); }
        dec.push(escolha); i++;
        if (repetir) todos = escolha;
        while (todos && i < conflitos.length) { dec.push(todos); i++; }
        if (i >= conflitos.length) aoTerminar(dec); else desenhar();
      }
      function desenhar() {
        var c = conflitos[i], restam = conflitos.length - i - 1, chk = null;
        corpo.textContent = "";
        if (conflitos.length > 1) { var cont = el("p", "dlg-ajuda", "Modelo " + (i + 1) + " de " + conflitos.length); cont.setAttribute("role", "status"); corpo.appendChild(cont); }
        corpo.appendChild(el("p", "rec-pergunta", c.nome === c.atualNome
          ? "Você já tem o modelo “" + c.atualNome + "”, mas o que chegou tem o texto diferente. O que fazer?"
          : "O modelo “" + c.nome + "” que chegou parece ser uma versão do seu “" + c.atualNome + "”, mas o texto é diferente. O que fazer?"));
        var op = function (titulo, desc, escolha, forte) {
          var b = el("button", "rec-op" + (forte ? " forte" : "")); b.type = "button";
          b.appendChild(el("strong", "", titulo)); b.appendChild(el("span", "", desc));
          b.addEventListener("click", function () { decidir(escolha, !!(chk && chk.checked)); });
          corpo.appendChild(b); return b;
        };
        var primeiro = op("Atualizar o meu", "Troca o texto do seu modelo pelo que chegou. O nome e a pasta continuam como estão. Uma cópia de segurança é guardada antes.", "atualizar", true);
        op("Ficar com os dois", "O que chegou entra como um modelo novo, com outro nome. O seu não muda.", "ambos");
        op("Pular", "Não mexe em nada neste modelo.", "pular");
        if (restam > 0) {
          var rot = el("label", "rec-repetir"); chk = el("input"); chk.type = "checkbox";
          rot.appendChild(chk); rot.appendChild(document.createTextNode(" Fazer o mesmo para os próximos que já existem (faltam " + restam + ")"));
          corpo.appendChild(rot);
        }
        corpo.appendChild(el("p", "dlg-ajuda", "Esc ou Cancelar: não abre nenhum modelo."));
        primeiro.focus();
      }
      desenhar();
    }
  };
})();
