@echo off
chcp 65001 >nul
echo Instalando ou atualizando o app Modelos de Evolucao...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\instalar-atalho.ps1"
if errorlevel 1 (
  echo.
  echo Nao foi possivel instalar ou atualizar automaticamente neste computador.
  echo Faca manualmente: clique com o botao direito em ABRIR.html ^> Enviar para ^> Area de trabalho.
)
echo.
pause
